<?php
declare(strict_types=1);
require __DIR__.'/config.php';
require __DIR__.'/iyzico.php';

// Eski/özelleştirilmiş config.php sürümleri için geriye dönük uyumluluk.
// sa_log_event mevcutsa config.php'deki sürüm kullanılır; yoksa API kendi güvenli fallback'ini kullanır.
if (!function_exists('sa_log_event')) {
    function sa_log_event(string $olay, string $detay = '', ?int $userId = null): void {
        try {
            $detay = substr($detay, 0, 10000);
            if (function_exists('sa_db')) {
                $pdo = sa_db();
                $st = $pdo->prepare('INSERT INTO sistem_loglari(kullanici_id,olay,detay,ip_adresi) VALUES(?,?,?,?)');
                $st->execute([$userId, $olay, $detay, substr($_SERVER['REMOTE_ADDR'] ?? '', 0, 45)]);
                return;
            }
        } catch (Throwable $ignore) {
            // Hata kaydı, ana API cevabını bozmasın.
        }
        error_log('[StickArena]['.$olay.'] '.$detay);
    }
}

// API cevaplarını temiz JSON olarak tut: PHP warning/notice çıktıları istemci JSON parser'ını bozmasın.
ob_start();
register_shutdown_function(function(): void {
    $e=error_get_last();
    if($e && in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR],true)){
        while(ob_get_level()>0) @ob_end_clean();
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false,'mesaj'=>'Sunucu PHP hatası: '.substr((string)$e['message'],0,500)],JSON_UNESCAPED_UNICODE);
    }
});

function sa_role_is_admin($role): bool {
    $v=strtolower(trim((string)$role));
    return in_array($v,['admin','1','yonetici','yönetici','administrator','superadmin','root'],true);
}
function sa_require_admin(): array {
    $a=sa_auth(); if(!$a) sa_json(['ok'=>false,'mesaj'=>'Giriş gerekli.'],401);
    $st=sa_db()->prepare("SELECT * FROM kullanicilar WHERE id=?");$st->execute([$a['sub']]);$u=$st->fetch();
    if(!$u || !sa_role_is_admin($u['yetki']??'')) sa_json(['ok'=>false,'mesaj'=>'Yetkisiz işlem.'],403); return $u;
}
function sa_current(): array {
    $a=sa_auth(); if(!$a) sa_json(['ok'=>false,'mesaj'=>'Giriş gerekli.'],401);
    $st=sa_db()->prepare("SELECT * FROM kullanicilar WHERE id=?");$st->execute([$a['sub']]);$u=$st->fetch(); if(!$u) sa_json(['ok'=>false],401); return $u;
}



function sa_column_exists(PDO $pdo,string $table,string $column): bool {
    $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
    $q->execute([$table,$column]);
    return (int)$q->fetchColumn()>0;
}
function sa_add_column_if_missing(PDO $pdo,string $table,string $column,string $definition): void {
    if(sa_column_exists($pdo,$table,$column)) return;
    $allowedTables=['web_lobiler','web_aktif_maclar','kullanicilar','duyurular'];
    $allowedColumns=['rakip_turu','davet_kodu','skor_rev','sonuclar_islendi','chat_mute_until','ban_until','xp','seviye','oda_id'];
    if(!in_array($table,$allowedTables,true)||!in_array($column,$allowedColumns,true)) return;
    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
}

/**
 * 5.8 çalışma zamanı şeması.
 * Eski kurulumlarda migration uygulanmamış olsa bile destek/puan/ses özelliklerinin
 * ilk istek sırasında gerekli tabloları güvenli biçimde oluşturmasını sağlar.
 */
function sa_ensure_56_runtime_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try { sa_add_column_if_missing($pdo,'web_lobiler','rakip_turu',"ENUM('real','bot') NOT NULL DEFAULT 'real' AFTER harita_id"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'web_lobiler','davet_kodu',"CHAR(8) NULL AFTER rakip_turu"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'web_aktif_maclar','rakip_turu',"ENUM('real','bot') NOT NULL DEFAULT 'real' AFTER harita_id"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'web_aktif_maclar','skor_rev',"INT UNSIGNED NOT NULL DEFAULT 0 AFTER skor_b"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'web_aktif_maclar','sonuclar_islendi',"TINYINT(1) NOT NULL DEFAULT 0 AFTER durum"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'kullanicilar','chat_mute_until',"BIGINT NOT NULL DEFAULT 0"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'kullanicilar','ban_until',"BIGINT NOT NULL DEFAULT 0"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'kullanicilar','xp',"BIGINT UNSIGNED NOT NULL DEFAULT 0"); } catch (Throwable $ignore) {}
    try { sa_add_column_if_missing($pdo,'kullanicilar','seviye',"TINYINT UNSIGNED NOT NULL DEFAULT 1"); } catch (Throwable $ignore) {}
    $pdo->exec("CREATE TABLE IF NOT EXISTS destek_talepleri (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        kullanici_id INT UNSIGNED NOT NULL,
        konu VARCHAR(150) NOT NULL,
        kategori VARCHAR(40) NOT NULL DEFAULT 'Genel',
        oncelik ENUM('dusuk','normal','yuksek','acil') NOT NULL DEFAULT 'normal',
        durum ENUM('acik','beklemede','cozuldu') NOT NULL DEFAULT 'acik',
        atanan_admin_id INT UNSIGNED NULL,
        son_mesaj_tarihi DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        olusturulma DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        guncellenme DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_destek_kullanici (kullanici_id,durum),
        INDEX idx_destek_durum (durum,oncelik,son_mesaj_tarihi)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS destek_mesajlari (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        talep_id BIGINT UNSIGNED NOT NULL,
        gonderen_tipi ENUM('oyuncu','admin','sistem') NOT NULL,
        gonderen_id INT UNSIGNED NULL,
        mesaj TEXT NOT NULL,
        okundu TINYINT(1) NOT NULL DEFAULT 0,
        tarih DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_destek_mesaj (talep_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS web_mac_sohbet (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        oda_id VARCHAR(64) NOT NULL,
        kullanici_id INT UNSIGNED NOT NULL,
        mesaj VARCHAR(180) NOT NULL,
        tarih DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_chat_room_id (oda_id,id),
        INDEX idx_chat_user (kullanici_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS duyurular (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        baslik VARCHAR(160) NOT NULL,
        icerik TEXT NOT NULL,
        tur VARCHAR(30) NOT NULL DEFAULT 'bilgi',
        aktif TINYINT(1) NOT NULL DEFAULT 1,
        sabit TINYINT(1) NOT NULL DEFAULT 0,
        yayin_tarihi DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        guncellenme DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_duyuru_aktif (aktif,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    try { sa_add_column_if_missing($pdo,'duyurular','oda_id',"VARCHAR(64) NULL AFTER id"); } catch (Throwable $ignore) {}

    $pdo->exec("CREATE TABLE IF NOT EXISTS web_mac_kill_log (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        oda_id VARCHAR(64) NOT NULL,
        killer_id BIGINT UNSIGNED NOT NULL,
        target_id BIGINT UNSIGNED NOT NULL,
        killer_team ENUM('A','B') NOT NULL,
        weapon VARCHAR(64) NOT NULL,
        death_seq INT UNSIGNED NOT NULL DEFAULT 1,
        tarih DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_match_kill (oda_id,killer_id,target_id,death_seq),
        INDEX idx_match_kill_room (oda_id,id),
        INDEX idx_match_kill_killer (oda_id,killer_id),
        INDEX idx_match_kill_target (oda_id,target_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS web_mac_sonuclari (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        oda_id VARCHAR(64) NOT NULL UNIQUE,
        mod VARCHAR(20) NOT NULL DEFAULT 'normal',
        harita_id VARCHAR(64) NOT NULL,
        skor_a INT NOT NULL DEFAULT 0,
        skor_b INT NOT NULL DEFAULT 0,
        kazanan_takim VARCHAR(12) NOT NULL DEFAULT 'berabere',
        oyuncular_json MEDIUMTEXT NULL,
        tamamlanma_tarihi DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_sonuclar_tarih (tamamlanma_tarihi)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS web_voice_signals (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        oda_id VARCHAR(64) NOT NULL,
        gonderen_id INT UNSIGNED NOT NULL,
        alan_id INT UNSIGNED NOT NULL,
        tur ENUM('offer','answer','candidate','leave') NOT NULL,
        payload MEDIUMTEXT NOT NULL,
        tarih DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_voice_recipient (oda_id,alan_id,id),
        INDEX idx_voice_room (oda_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS oyun_kurallari (
        id TINYINT UNSIGNED PRIMARY KEY,
        baslik VARCHAR(150) NOT NULL,
        ozet VARCHAR(500) NOT NULL DEFAULT '',
        icerik MEDIUMTEXT NOT NULL,
        aktif TINYINT(1) NOT NULL DEFAULT 1,
        guncellenme DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("INSERT INTO oyun_kurallari(id,baslik,ozet,icerik,aktif) VALUES
        (1,'Stick Arena Oyun Kuralları','Adil oyun, saygılı iletişim ve weapon-only arena.','1. Maçlarda yalnızca silah sistemi kullanılır. Yumruk, tekme, kılıç ve diğer yakın dövüş saldırıları kapalıdır.\n2. Hile, açık istismarı, sahte paket gönderimi ve oyun güvenliğini bozmaya yönelik girişimler yasaktır.\n3. Sohbet ve sesli kanalda diğer oyunculara saygılı davranılmalıdır. Spam, tehdit ve taciz yasaktır.\n4. Hesap ve ödeme bilgilerinizi paylaşmayın.\n5. Yönetim işlemleri güvenlik ve moderasyon amacıyla loglanabilir.',1)
        ON DUPLICATE KEY UPDATE id=id");
    // İlişki kısıtlarını eklemek zorunlu değil; mevcut/eski şemalarla uyumluluk önceliklidir.
    $done = true;
}

function sa_item_catalog(): array {
    // Live sunucuda data/items.json varsa onu kullan; eksik/eski şemalarda
    // combat sisteminin çalışması için güvenli dahili katalogla birleştir.
    $fallback=[
        'pistol'=>['kategori'=>'silah','hasar'=>28,'bekleme'=>260,'menzil'=>1250,'mühimmat'=>15],
        'm4a1'=>['kategori'=>'silah','hasar'=>34,'bekleme'=>155,'menzil'=>1850,'mühimmat'=>30],
        'awp'=>['kategori'=>'silah','hasar'=>90,'bekleme'=>1000,'menzil'=>2600,'mühimmat'=>8],
        'rpg'=>['kategori'=>'silah','hasar'=>100,'bekleme'=>1150,'menzil'=>1900,'mühimmat'=>5],
        'uzi'=>['kategori'=>'silah','hasar'=>22,'bekleme'=>90,'menzil'=>1250,'mühimmat'=>32],
        'mp5'=>['kategori'=>'silah','hasar'=>24,'bekleme'=>105,'menzil'=>1450,'mühimmat'=>30],
        'ak47'=>['kategori'=>'silah','hasar'=>36,'bekleme'=>165,'menzil'=>1750,'mühimmat'=>30],
        'shotgun'=>['kategori'=>'silah','hasar'=>65,'bekleme'=>650,'menzil'=>850,'mühimmat'=>8],
        'deagle'=>['kategori'=>'silah','hasar'=>55,'bekleme'=>420,'menzil'=>1450,'mühimmat'=>7],
        'vector'=>['kategori'=>'silah','hasar'=>20,'bekleme'=>80,'menzil'=>1200,'mühimmat'=>30],
        'p90'=>['kategori'=>'silah','hasar'=>21,'bekleme'=>92,'menzil'=>1350,'mühimmat'=>30],
    ];
    $file=__DIR__.'/data/items.json';
    $json=is_file($file)?json_decode(file_get_contents($file),true):[];
    $json=is_array($json)?$json:[];
    foreach($fallback as $id=>$def){
        if(!isset($json[$id]) || !is_array($json[$id]) || ($json[$id]['kategori']??'')!=='silah') $json[$id]=$def;
        else $json[$id]=array_merge($def,$json[$id]);
    }
    return $json;
}
function sa_equipment_defaults(): array {
    return ['karakter'=>'red','silah'=>'pistol','efekt'=>'yok'];
}
function sa_equipment_row(int $uid): array {
    try {
        $st=sa_db()->prepare("SELECT karakter_id AS karakter,silah_id AS silah,efekt_id AS efekt FROM oyuncu_donanim WHERE kullanici_id=? LIMIT 1");
        $st->execute([$uid]); $r=$st->fetch();
        if($r){$r['silah']=sa_normalize_weapon((string)($r['silah']??'pistol'));$r['karakter']=sa_normalize_character((string)($r['karakter']??'red'));}
        return $r ?: sa_equipment_defaults();
    } catch(Throwable $e) { return sa_equipment_defaults(); }
}
function sa_weapon_def(string $id): ?array {
    $items=sa_item_catalog(); $it=$items[$id]??null;
    if(!$it || ($it['kategori']??'')!=='silah') return null;
    return $it;
}
function sa_normalize_weapon(string $id): string {
    $map=['tabanca'=>'pistol','tufek'=>'m4a1','makineli_tufek'=>'mp5','pompal_tufek'=>'shotgun','roketatar'=>'rpg','keskin_nisanci'=>'awp','karbon_silah'=>'vector','karanlik_silah'=>'p90','neon_silah'=>'vector','altin_silah'=>'deagle','alev_silah'=>'rpg','buz_silah'=>'awp'];
    return isset(sa_item_catalog()[$id])?$id:($map[$id]??'pistol');
}
function sa_weapon_ammo_max(string $id): int { $w=sa_weapon_def(sa_normalize_weapon($id)); return max(1,(int)($w['mühimmat']??15)); }
function sa_normalize_character(string $id, string $team='A'): string { $k=strtolower(trim($id)); if(in_array($k,['gold','altin','goldkarakter'],true)) return 'gold'; if(in_array($k,['blue','mavi'],true)) return 'blue'; if(in_array($k,['red','kirmizi'],true)) return 'red'; return $team==='B'?'blue':'red'; }
function sa_spawn_position(string $team): array { if($team==='B') return ['x'=>random_int(3040,3160),'y'=>592]; return ['x'=>random_int(170,430),'y'=>592]; }
function sa_map_catalog(): array {
    return [
      'col_bolgesi'=>['ad'=>'DUNE SECTOR','dosya'=>'assets/sprites/maps/v55/col_bolgesi.jpg'],
      'sehir_insaati'=>['ad'=>'MEGACITY VANTAGE','dosya'=>'assets/sprites/maps/v55/sehir_insaati.jpg'],
      'uzay_istasyonu'=>['ad'=>'ORBITAL DOCK','dosya'=>'assets/sprites/maps/v55/uzay_istasyonu.jpg'],
      'askeri_us'=>['ad'=>'BLACKSITE 09','dosya'=>'assets/sprites/maps/v55/askeri_us.jpg'],
      'orman'=>['ad'=>'VERDANT CORE','dosya'=>'assets/sprites/maps/v55/orman.jpg'],
      'gece_ormani'=>['ad'=>'NIGHTFALL GROVE','dosya'=>'assets/sprites/maps/v55/gece_ormani.jpg'],
      'sehir_gece'=>['ad'=>'NEON DISTRICT','dosya'=>'assets/sprites/maps/v55/sehir_gece.jpg'],
      'liman'=>['ad'=>'PORT VANTA','dosya'=>'assets/sprites/maps/v55/liman.jpg'],
      'harabe'=>['ad'=>'RUINED SECTOR','dosya'=>'assets/sprites/maps/v55/harabe.jpg'],
      'karli_daglar'=>['ad'=>'FROSTLINE','dosya'=>'assets/sprites/maps/v55/karli_daglar.jpg']
    ];
}
function sa_map_layout(string $id): array { $layouts=['col_bolgesi'=>[['x'=>0,'y'=>640,'w'=>560,'h'=>50,'tur'=>'zemin'],['x'=>620,'y'=>555,'w'=>260,'h'=>28,'tur'=>'kopru'],['x'=>950,'y'=>455,'w'=>340,'h'=>28,'tur'=>'kopru'],['x'=>1340,'y'=>565,'w'=>220,'h'=>30,'tur'=>'kutu'],['x'=>1580,'y'=>385,'w'=>470,'h'=>28,'tur'=>'kopru'],['x'=>2100,'y'=>500,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>2410,'y'=>330,'w'=>360,'h'=>28,'tur'=>'kopru'],['x'=>2810,'y'=>545,'w'=>390,'h'=>45,'tur'=>'zemin'],['x'=>1120,'y'=>285,'w'=>230,'h'=>26,'tur'=>'kutu'],['x'=>1970,'y'=>235,'w'=>280,'h'=>26,'tur'=>'kopru']],'sehir_insaati'=>[['x'=>0,'y'=>645,'w'=>500,'h'=>45,'tur'=>'zemin'],['x'=>560,'y'=>545,'w'=>260,'h'=>30,'tur'=>'kutu'],['x'=>850,'y'=>435,'w'=>420,'h'=>28,'tur'=>'kopru'],['x'=>1330,'y'=>575,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>1640,'y'=>455,'w'=>350,'h'=>28,'tur'=>'kopru'],['x'=>2050,'y'=>335,'w'=>250,'h'=>28,'tur'=>'kutu'],['x'=>2360,'y'=>500,'w'=>320,'h'=>28,'tur'=>'kopru'],['x'=>2740,'y'=>420,'w'=>460,'h'=>45,'tur'=>'zemin'],['x'=>1110,'y'=>250,'w'=>220,'h'=>26,'tur'=>'kutu']],'uzay_istasyonu'=>[['x'=>0,'y'=>645,'w'=>620,'h'=>45,'tur'=>'zemin'],['x'=>730,'y'=>530,'w'=>290,'h'=>28,'tur'=>'kopru'],['x'=>1080,'y'=>400,'w'=>300,'h'=>30,'tur'=>'kutu'],['x'=>1450,'y'=>545,'w'=>460,'h'=>28,'tur'=>'kopru'],['x'=>1990,'y'=>415,'w'=>260,'h'=>30,'tur'=>'kutu'],['x'=>2320,'y'=>295,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>2720,'y'=>520,'w'=>480,'h'=>45,'tur'=>'zemin'],['x'=>1290,'y'=>230,'w'=>250,'h'=>26,'tur'=>'kutu']],'askeri_us'=>[['x'=>0,'y'=>645,'w'=>580,'h'=>45,'tur'=>'zemin'],['x'=>690,'y'=>535,'w'=>280,'h'=>30,'tur'=>'kutu'],['x'=>1010,'y'=>430,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>1450,'y'=>565,'w'=>240,'h'=>30,'tur'=>'kutu'],['x'=>1740,'y'=>375,'w'=>450,'h'=>28,'tur'=>'kopru'],['x'=>2240,'y'=>500,'w'=>270,'h'=>30,'tur'=>'kutu'],['x'=>2550,'y'=>305,'w'=>370,'h'=>28,'tur'=>'kopru'],['x'=>2950,'y'=>540,'w'=>250,'h'=>45,'tur'=>'zemin'],['x'=>1240,'y'=>265,'w'=>220,'h'=>26,'tur'=>'kutu']],'orman'=>[['x'=>0,'y'=>645,'w'=>640,'h'=>45,'tur'=>'zemin'],['x'=>740,'y'=>520,'w'=>300,'h'=>28,'tur'=>'kutu'],['x'=>1080,'y'=>410,'w'=>430,'h'=>28,'tur'=>'kopru'],['x'=>1570,'y'=>565,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>1880,'y'=>445,'w'=>380,'h'=>28,'tur'=>'kopru'],['x'=>2290,'y'=>335,'w'=>280,'h'=>30,'tur'=>'kutu'],['x'=>2600,'y'=>510,'w'=>420,'h'=>28,'tur'=>'kopru'],['x'=>3030,'y'=>590,'w'=>170,'h'=>40,'tur'=>'zemin'],['x'=>1290,'y'=>260,'w'=>220,'h'=>26,'tur'=>'kutu']],'gece_ormani'=>[['x'=>0,'y'=>645,'w'=>520,'h'=>45,'tur'=>'zemin'],['x'=>600,'y'=>520,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>900,'y'=>395,'w'=>370,'h'=>28,'tur'=>'kopru'],['x'=>1300,'y'=>550,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>1590,'y'=>335,'w'=>430,'h'=>28,'tur'=>'kopru'],['x'=>2080,'y'=>475,'w'=>240,'h'=>30,'tur'=>'kutu'],['x'=>2380,'y'=>365,'w'=>370,'h'=>28,'tur'=>'kopru'],['x'=>2790,'y'=>520,'w'=>410,'h'=>45,'tur'=>'zemin'],['x'=>1460,'y'=>225,'w'=>240,'h'=>26,'tur'=>'kutu']],'sehir_gece'=>[['x'=>0,'y'=>645,'w'=>580,'h'=>45,'tur'=>'zemin'],['x'=>660,'y'=>530,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>970,'y'=>420,'w'=>360,'h'=>28,'tur'=>'kopru'],['x'=>1360,'y'=>305,'w'=>230,'h'=>30,'tur'=>'kutu'],['x'=>1640,'y'=>495,'w'=>430,'h'=>28,'tur'=>'kopru'],['x'=>2140,'y'=>390,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>2450,'y'=>300,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>2870,'y'=>540,'w'=>330,'h'=>45,'tur'=>'zemin'],['x'=>1170,'y'=>235,'w'=>220,'h'=>26,'tur'=>'kutu']],'liman'=>[['x'=>0,'y'=>645,'w'=>680,'h'=>45,'tur'=>'zemin'],['x'=>770,'y'=>535,'w'=>300,'h'=>30,'tur'=>'kutu'],['x'=>1120,'y'=>440,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>1540,'y'=>560,'w'=>240,'h'=>30,'tur'=>'kutu'],['x'=>1830,'y'=>345,'w'=>450,'h'=>28,'tur'=>'kopru'],['x'=>2320,'y'=>480,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>2620,'y'=>315,'w'=>380,'h'=>28,'tur'=>'kopru'],['x'=>3000,'y'=>560,'w'=>200,'h'=>45,'tur'=>'zemin'],['x'=>2000,'y'=>235,'w'=>240,'h'=>26,'tur'=>'kutu']],'harabe'=>[['x'=>0,'y'=>645,'w'=>550,'h'=>45,'tur'=>'zemin'],['x'=>620,'y'=>545,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>910,'y'=>455,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>1350,'y'=>570,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>1650,'y'=>395,'w'=>430,'h'=>28,'tur'=>'kopru'],['x'=>2120,'y'=>515,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>2410,'y'=>395,'w'=>410,'h'=>28,'tur'=>'kopru'],['x'=>2820,'y'=>525,'w'=>380,'h'=>45,'tur'=>'zemin'],['x'=>1110,'y'=>270,'w'=>230,'h'=>26,'tur'=>'kutu']],'karli_daglar'=>[['x'=>0,'y'=>645,'w'=>600,'h'=>45,'tur'=>'zemin'],['x'=>670,'y'=>535,'w'=>290,'h'=>30,'tur'=>'kutu'],['x'=>1020,'y'=>425,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>1470,'y'=>565,'w'=>240,'h'=>30,'tur'=>'kutu'],['x'=>1760,'y'=>355,'w'=>430,'h'=>28,'tur'=>'kopru'],['x'=>2240,'y'=>475,'w'=>250,'h'=>30,'tur'=>'kutu'],['x'=>2540,'y'=>295,'w'=>390,'h'=>28,'tur'=>'kopru'],['x'=>2970,'y'=>535,'w'=>230,'h'=>45,'tur'=>'zemin'],['x'=>1280,'y'=>235,'w'=>240,'h'=>26,'tur'=>'kutu']],]; return $layouts[$id]??$layouts['col_bolgesi']; }
function sa_map_round(string $oda, int $startedTs): int {
    return max(0,(int)floor(max(0,time()-$startedTs)/180));
}
function sa_next_map(string $current, int $round): string {
    $keys=array_keys(sa_map_catalog());
    if(!$keys)return $current;
    $base=array_search($current,$keys,true);
    if($base===false)$base=0;
    return $keys[($base+$round)%count($keys)];
}

function sa_game_profile(int $uid): array {
    $pdo=sa_db();
    $st=$pdo->prepare("SELECT u.id,u.kullanici_adi,u.yetki,u.dogrulanmis,ku.klan_id,k.ad AS klan_ad,k.etiket AS klan_etiket FROM kullanicilar u LEFT JOIN klan_uyeleri ku ON ku.kullanici_id=u.id LEFT JOIN klanlar k ON k.id=ku.klan_id WHERE u.id=? LIMIT 1");
    $st->execute([$uid]); $r=$st->fetch() ?: ['id'=>$uid,'kullanici_adi'=>'Oyuncu','yetki'=>'user','klan_id'=>null,'klan_ad'=>null,'klan_etiket'=>null];
    $eq=sa_equipment_row($uid);
    return ['id'=>(int)$r['id'],'name'=>(string)$r['kullanici_adi'],'admin'=>sa_role_is_admin($r['yetki']??''),'dogrulanmis'=>(bool)($r['dogrulanmis']??0),'klan'=>$r['klan_ad']?:null,'klan_etiket'=>$r['klan_etiket']?:null,'character'=>$eq['karakter'],'weapon'=>$eq['silah'],'efekt'=>$eq['efekt']];
}
function sa_lobby_players(string $lobi): array {
    $st=sa_db()->prepare("SELECT kullanici_id,takim FROM web_lobi_uyeleri WHERE lobi_id=? ORDER BY katilma_tarihi,id"); $st->execute([$lobi]);
    $out=[]; foreach($st->fetchAll() as $row){ $out[]=sa_game_profile((int)$row['kullanici_id']); $out[count($out)-1]['team']=($row['takim']==='B'?'B':'A'); } return $out;
}
function sa_make_room(): string { return 'WEB5V5_'.strtoupper(bin2hex(random_bytes(5))); }


function sa_request_json(): array {
    static $cache=null;
    if($cache!==null) return $cache;
    $raw=file_get_contents('php://input');
    $cache=is_string($raw)&&$raw!==''?(json_decode($raw,true)?:[]):[];
    return $cache;
}
function sa_chat_moderation_status(int $uid): array {
    try {
        $st=sa_db()->prepare("SELECT COALESCE(chat_mute_until,0) AS mute_until, COALESCE(ban_until,0) AS ban_until, COALESCE(dogrulanmis,0) AS dogrulanmis FROM kullanicilar WHERE id=? LIMIT 1");
        $st->execute([$uid]); $r=$st->fetch()?:[];
        return ['mute_until'=>(int)($r['mute_until']??0),'ban_until'=>(int)($r['ban_until']??0),'dogrulanmis'=>(bool)($r['dogrulanmis']??0)];
    } catch(Throwable $e) { return ['mute_until'=>0,'ban_until'=>0,'dogrulanmis'=>false]; }
}
function sa_is_admin_user(array $u): bool { return sa_role_is_admin($u['yetki']??''); }
function sa_increment_user_death(PDO $pdo, int $uid): void {
    if ($uid <= 0) return;
    try {
        if (sa_column_exists($pdo, 'kullanicilar', 'olum')) {
            $pdo->prepare("UPDATE kullanicilar SET olum=COALESCE(olum,0)+1 WHERE id=?")->execute([$uid]);
        }
    } catch (Throwable $ignore) {
        // İstatistik kolonunun eski şemada bulunmaması maç/hasar işlemini geri almamalı.
    }
}





function sa_level_from_xp(int $xp): int {
    return min(100, 1 + intdiv(max(0,$xp),100));
}
function sa_award_kill_xp(PDO $pdo, int $userId, int $amount=100): array {
    if($userId<=0 || $amount<=0) return ['xp'=>0,'level'=>1,'gained'=>0,'leveled_up'=>false,'old_level'=>1];
    try{
        $st=$pdo->prepare("SELECT COALESCE(xp,0) AS xp, COALESCE(seviye,1) AS seviye FROM kullanicilar WHERE id=? LIMIT 1 FOR UPDATE");
        $st->execute([$userId]);
        $row=$st->fetch()?:[];
        $oldXp=max(0,(int)($row['xp']??0));
        $oldLevel=max(1,min(100,(int)($row['seviye']??1)));
        $newXp=$oldXp+$amount;
        $newLevel=sa_level_from_xp($newXp);
        $pdo->prepare("UPDATE kullanicilar SET xp=?, seviye=? WHERE id=?")->execute([$newXp,$newLevel,$userId]);
        return ['xp'=>$newXp,'level'=>$newLevel,'gained'=>$amount,'leveled_up'=>$newLevel>$oldLevel,'old_level'=>$oldLevel];
    }catch(Throwable $e){
        sa_log_event('XP_AWARD_ERROR',$e->getMessage(),$userId);
        return ['xp'=>0,'level'=>1,'gained'=>0,'leveled_up'=>false,'old_level'=>1,'error'=>true];
    }
}
function sa_sync_player_level_from_xp(PDO $pdo, int $userId): array {
    try{
        $st=$pdo->prepare("SELECT COALESCE(xp,0) AS xp, COALESCE(seviye,1) AS seviye FROM kullanicilar WHERE id=? LIMIT 1");
        $st->execute([$userId]); $r=$st->fetch()?:[];
        $xp=max(0,(int)($r['xp']??0)); $level=sa_level_from_xp($xp);
        if((int)($r['seviye']??1)!==$level) $pdo->prepare("UPDATE kullanicilar SET seviye=? WHERE id=?")->execute([$level,$userId]);
        return ['xp'=>$xp,'level'=>$level];
    }catch(Throwable $e){ return ['xp'=>0,'level'=>1]; }
}

function sa_record_kill(PDO $pdo, string $oda, int $killerId, int $targetId, string $team, string $weapon, int $deathSeq, bool $killerReal): bool {
    $team = $team === 'B' ? 'B' : 'A';
    $inserted=false;
    try {
        $q=$pdo->prepare("INSERT IGNORE INTO oyuncu_kill_log(oda_id,killer_id,target_id,killer_team,weapon,death_seq,tarih) VALUES(?,?,?,?,?,?,NOW())");
        $q->execute([$oda,$killerId,$targetId,$team,$weapon,$deathSeq]);
        $inserted=$q->rowCount()>0;
    } catch(Throwable $ignore) {}
    try {
        $q=$pdo->prepare("INSERT IGNORE INTO web_mac_kill_log(oda_id,killer_id,target_id,killer_team,weapon,death_seq,tarih) VALUES(?,?,?,?,?,?,NOW())");
        $q->execute([$oda,$killerId,$targetId,$team,$weapon,$deathSeq]);
        $inserted=$inserted || $q->rowCount()>0;
    } catch(Throwable $ignore) {}
    if($inserted && $killerReal){
        try { $pdo->prepare("UPDATE kullanicilar SET oldurme=COALESCE(oldurme,0)+1 WHERE id=?")->execute([$killerId]); } catch(Throwable $ignore) {}
    }
    return $inserted;
}

function sa_rebuild_match_score(PDO $pdo, string $oda): array {
    $a=0;$b=0;$rev=0;
    try {
        $q=$pdo->prepare("SELECT COALESCE(SUM(killer_team='A'),0) a,COALESCE(SUM(killer_team='B'),0) b,COUNT(*) c FROM web_mac_kill_log WHERE oda_id=?");
        $q->execute([$oda]); $r=$q->fetch()?:[];
        $a=(int)($r['a']??0); $b=(int)($r['b']??0); $rev=(int)($r['c']??0);
    } catch(Throwable $ignore) {}
    return [$a,$b,$rev];
}

function sa_finalize_match(PDO $pdo, string $oda): array {
    $st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? LIMIT 1 FOR UPDATE");
    $st->execute([$oda]);
    $m=$st->fetch();
    if(!$m) return ['ok'=>false,'mesaj'=>'Maç bulunamadı.'];
    $state=json_decode($m['state_json']??'{}',true)?:['players'=>[]];
    $scoreA=(int)$m['skor_a']; $scoreB=(int)$m['skor_b'];
    $winner=$scoreA===$scoreB?'berabere':($scoreA>$scoreB?'A':'B');
    $already=(int)($m['sonuclar_islendi']??0);
    if($already){return ['ok'=>true,'already'=>true,'winner'=>$winner,'scoreA'=>$scoreA,'scoreB'=>$scoreB];}
    $odul=$pdo->query("SELECT * FROM oyun_odul_ayarlari WHERE id=1 LIMIT 1")->fetch() ?: [];
    $winXp=max(0,(int)($odul['normal_takim_xp']??300));
    $winCoin=max(0,(int)($odul['normal_takim_coin']??300));
    $loseXp=max(0,(int)($odul['klan_kaybeden_xp']??100));
    $loseCoin=max(0,(int)($odul['klan_kaybeden_coin']??100));
    $realPlayers=array_values(array_filter($state['players']??[],fn($x)=>!empty($x['real']) && (int)($x['id']??0)>0));
    $resultRows=[];
    foreach($realPlayers as $pl){
        $uid=(int)$pl['id']; $team=($pl['team']??'A')==='B'?'B':'A';
        $kills=max(0,(int)($pl['kills']??0)); $deaths=max(0,(int)($pl['deaths']??0));
        try{ $k=$pdo->prepare("SELECT COUNT(*) FROM web_mac_kill_log WHERE oda_id=? AND killer_id=?"); $k->execute([$oda,$uid]); $kills=(int)$k->fetchColumn(); $d=$pdo->prepare("SELECT COUNT(*) FROM web_mac_kill_log WHERE oda_id=? AND target_id=?"); $d->execute([$oda,$uid]); $deaths=(int)$d->fetchColumn(); }catch(Throwable $ignore){}
        $isWin=($winner!=='berabere' && $team===$winner); $isDraw=($winner==='berabere');
        $xp=$isDraw?intdiv($winXp+$loseXp,2):($isWin?$winXp:$loseXp);
        $coin=$isDraw?intdiv($winCoin+$loseCoin,2):($isWin?$winCoin:$loseCoin);
        $ratingDelta=$isDraw?0:($isWin?25:-15);
        $cur=sa_sync_player_level_from_xp($pdo,$uid);
        $newXp=(int)$cur['xp']+$xp;
        $newLevel=sa_level_from_xp($newXp);
        $pdo->prepare("UPDATE kullanicilar SET galibiyet=galibiyet+?, maglubiyet=maglubiyet+?, rating=GREATEST(0,rating+?), xp=?, seviye=?, coin=coin+?, oldurme=GREATEST(COALESCE(oldurme,0),?) WHERE id=?")
            ->execute([$isWin?1:0,(!$isWin&&!$isDraw)?1:0,$ratingDelta,$newXp,$newLevel,$coin,$kills,$uid]);
        $resultRows[]=['kullanici_id'=>$uid,'takim'=>$team,'oldurme'=>$kills,'olum'=>$deaths,'kazandi'=>$isWin,'berabere'=>$isDraw,'xp'=>$xp,'xp_toplam'=>$newXp,'seviye'=>$newLevel,'coin'=>$coin,'rating_delta'=>$ratingDelta];
    }
    try{
        $pdo->prepare("INSERT INTO web_mac_sonuclari(oda_id,mod,harita_id,skor_a,skor_b,kazanan_takim,oyuncular_json,tamamlanma_tarihi) VALUES(?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE skor_a=VALUES(skor_a),skor_b=VALUES(skor_b),kazanan_takim=VALUES(kazanan_takim),oyuncular_json=VALUES(oyuncular_json),tamamlanma_tarihi=NOW()")
            ->execute([$oda,$m['mod'],$m['harita_id'],$scoreA,$scoreB,$winner,json_encode($resultRows,JSON_UNESCAPED_UNICODE)]);
    }catch(Throwable $ignore){ /* sonuç tablosu migration uygulanmadan da maç kapanabilsin */ }
    try { $pdo->prepare("UPDATE web_aktif_maclar SET durum='bitti',bitis=NOW(),son_heartbeat=NOW(),sonuclar_islendi=1 WHERE oda_id=?")->execute([$oda]); } catch (Throwable $ignore) { $pdo->prepare("UPDATE web_aktif_maclar SET durum='bitti',bitis=NOW(),son_heartbeat=NOW() WHERE oda_id=?")->execute([$oda]); }
    return ['ok'=>true,'already'=>false,'winner'=>$winner,'scoreA'=>$scoreA,'scoreB'=>$scoreB,'oyuncular'=>$resultRows];
}

$action=$_GET['action']??'';
try { sa_ensure_56_runtime_schema(sa_db()); } catch (Throwable $ignore) { /* mevcut yetkiler kısıtlıysa eski akış çalışmaya devam eder */ }
set_exception_handler(function(Throwable $e) use ($action): void {
    sa_log_event('HATA_UNCAUGHT', 'action='.$action.' | '.$e->getMessage().' | '.$e->getFile().':'.$e->getLine());
    sa_json(['ok'=>false,'mesaj'=>'Beklenmeyen sunucu hatası. Hata kaydı yönetim paneline gönderildi.'],500);
});

if($action==='register'){
 $in=json_decode(file_get_contents('php://input'),true)??[];$u=trim($in['username']??'');$e=trim($in['email']??'');$p=$in['password']??'';
 if(!preg_match('/^[a-zA-Z0-9_]{3,32}$/',$u)||!filter_var($e,FILTER_VALIDATE_EMAIL)||strlen($p)<6)sa_json(['ok'=>false,'mesaj'=>'Kullanıcı adı, e-posta veya parola kurallara uygun değil.'],422);
 try{$st=sa_db()->prepare("INSERT INTO kullanicilar(kullanici_adi,email,sifre_hash) VALUES(?,?,?)");$st->execute([$u,$e,password_hash($p,PASSWORD_DEFAULT)]);$id=(int)sa_db()->lastInsertId();sa_json(['ok'=>true,'token'=>sa_token($id,$u)]);}catch(PDOException $x){sa_json(['ok'=>false,'mesaj'=>'Kullanıcı adı veya e-posta zaten kayıtlı.'],409);}
}
if($action==='login'){
 $in=json_decode(file_get_contents('php://input'),true)??[];$login=trim($in['login']??'');
 $st=sa_db()->prepare("SELECT * FROM kullanicilar WHERE kullanici_adi=? OR email=? LIMIT 1");$st->execute([$login,$login]);$u=$st->fetch();
 if(!$u||!password_verify($in['password']??'',$u['sifre_hash']))sa_json(['ok'=>false,'mesaj'=>'Giriş bilgileri hatalı.'],401);
 $banUntil=(int)($u['ban_until']??0); if($banUntil>time()) sa_json(['ok'=>false,'mesaj'=>'Hesabınız geçici olarak engellendi. Kalan süre: '.max(1,ceil(($banUntil-time())/60)).' dakika.'],403);
 sa_db()->prepare("UPDATE kullanicilar SET son_giris=NOW() WHERE id=?")->execute([$u['id']]);sa_json(['ok'=>true,'token'=>sa_token((int)$u['id'],$u['kullanici_adi'])]);
}
if($action==='me'){
 $u=sa_current();$st=sa_db()->prepare("SELECT k.id,k.ad,k.etiket,k.seviye,k.puan FROM klan_uyeleri ku JOIN klanlar k ON k.id=ku.klan_id WHERE ku.kullanici_id=?");$st->execute([$u['id']]);$klan=$st->fetch();
 unset($u['sifre_hash']);$u['dogrulanmis']=(bool)($u['dogrulanmis']??0);$u['chat_mute_until']=(int)($u['chat_mute_until']??0);sa_json(['ok'=>true,'kullanici'=>$u,'klan'=>$klan?:null]);
}
if($action==='web_status'){
 try { $pdo=sa_db();
 $pdo->exec("DELETE FROM web_aktif_maclar WHERE son_heartbeat < (NOW() - INTERVAL 20 SECOND) OR durum <> 'aktif'");
 $rows=$pdo->query("SELECT w.oda_id AS id,w.`mod`,w.harita_id AS harita,w.skor_a,w.skor_b,w.oyuncu_a AS a,w.oyuncu_b AS b,w.max_a AS maxA,w.max_b AS maxB,GREATEST(0, TIMESTAMPDIFF(SECOND,NOW(),w.bitis)) AS kalan,w.son_heartbeat,COALESCE(c.duraklatildi,0) AS duraklatildi,ca.ad AS clan_a_ad,cb.ad AS clan_b_ad FROM web_aktif_maclar w LEFT JOIN web_mac_kontrol c ON c.oda_id=w.oda_id LEFT JOIN klanlar ca ON ca.id=w.clan_a LEFT JOIN klanlar cb ON cb.id=w.clan_b WHERE durum='aktif' AND son_heartbeat >= (NOW() - INTERVAL 20 SECOND) ORDER BY baslangic DESC")->fetchAll();
 $maclar=[];$oyuncu=0;
 foreach($rows as $r){$oyuncu+=(int)$r['a']+(int)$r['b'];$maclar[]=['id'=>$r['id'],'mod'=>$r['mod'],'harita'=>$r['harita'],'skor'=>['A'=>(int)$r['skor_a'],'B'=>(int)$r['skor_b']],'a'=>(int)$r['a'],'b'=>(int)$r['b'],'maxA'=>(int)$r['maxA'],'maxB'=>(int)$r['maxB'],'kalan'=>(int)$r['kalan'],'duraklatildi'=>(bool)$r['duraklatildi'],'clanA'=>$r['clan_a_ad'],'clanB'=>$r['clan_b_ad']];}
 $lobiler=$pdo->query("SELECT l.lobi_id,l.`mod`,l.harita_id,l.bitis,COUNT(u.id) oyuncu,l.max_oyuncu FROM web_lobiler l LEFT JOIN web_lobi_uyeleri u ON u.lobi_id=l.lobi_id AND u.son_heartbeat >= (NOW() - INTERVAL 25 SECOND) WHERE l.durum='bekliyor' AND l.bitis>NOW() GROUP BY l.id ORDER BY l.id DESC")->fetchAll();
 foreach($lobiler as &$lb){$lb['kalan']=max(0,strtotime($lb['bitis'])-time());$lb['harita_ad']=sa_map_catalog()[$lb['harita_id']]['ad']??$lb['harita_id'];}unset($lb);
 sa_json(['ok'=>true,'sunucu'=>true,'oyuncu'=>$oyuncu,'izleyici'=>0,'maclar'=>$maclar,'lobiler'=>$lobiler]);
 } catch(Throwable $e) { sa_log_event('HATA_WEB_STATUS',$e->getMessage()); sa_json(['ok'=>false,'mesaj'=>'Veritabanı bağlantısı başarısız: '.$e->getMessage()],500); }
}
if($action==='web_ping'){
 try { sa_db()->query('SELECT 1'); sa_json(['ok'=>true,'sunucu'=>true,'veritabani'=>true]); }
 catch(Throwable $e) { sa_log_event('HATA_WEB_PING',$e->getMessage()); sa_json(['ok'=>false,'sunucu'=>false,'veritabani'=>false,'mesaj'=>$e->getMessage()],500); }
}

if($action==='envanter'){
    $u=sa_current(); $items=sa_item_catalog();
    $st=sa_db()->prepare("SELECT item_id,adet FROM envanter WHERE kullanici_id=? AND adet>0 ORDER BY item_id"); $st->execute([$u['id']]);
    $inv=[]; foreach($st->fetchAll() as $r){ $it=$items[$r['item_id']]??['id'=>$r['item_id'],'ad'=>$r['item_id'],'kategori'=>'diger','fiyat'=>0]; $it['adet']=(int)$r['adet']; $inv[]=$it; }
    $eq=sa_equipment_row((int)$u['id']);
    $chars=[['id'=>'red','ad'=>'Kırmızı Stickman','dosya'=>'assets/sprites/characters/v516/red.png'],['id'=>'blue','ad'=>'Mavi Stickman','dosya'=>'assets/sprites/characters/v516/blue.png'],['id'=>'gold','ad'=>'Altın Stickman','dosya'=>'assets/sprites/characters/v516/gold.png']];
    sa_json(['ok'=>true,'envanter'=>$inv,'donanim'=>$eq,'karakterler'=>$chars]);
}
if($action==='donanim_ayarla'){
    $u=sa_current(); $in=json_decode(file_get_contents('php://input'),true)??[];
    $character=sa_normalize_character(preg_replace('/[^a-z0-9_-]/i','',(string)($in['karakter']??'red')),'A');
    $weapon=sa_normalize_weapon(preg_replace('/[^a-z0-9_-]/i','',(string)($in['silah']??'pistol')));
    $effect=preg_replace('/[^a-z0-9_-]/i','',(string)($in['efekt']??'yok'));
    $chars=['red','blue','gold'];
    if(!in_array($character,$chars,true))sa_json(['ok'=>false,'mesaj'=>'Karakter bulunamadı.'],422);
    if($character!=='red'){
        $charItem='karakter_'.$character;$st=sa_db()->prepare("SELECT adet FROM envanter WHERE kullanici_id=? AND item_id=? AND adet>0");$st->execute([$u['id'],$charItem]);
        if(!$st->fetch())sa_json(['ok'=>false,'mesaj'=>'Bu karakter depoda bulunmuyor.'],403);
    }
    if($weapon!=='pistol'){
        $w=sa_weapon_def($weapon); if(!$w)sa_json(['ok'=>false,'mesaj'=>'Silah bulunamadı.'],422);
        $st=sa_db()->prepare("SELECT adet FROM envanter WHERE kullanici_id=? AND item_id=? AND adet>0");$st->execute([$u['id'],$weapon]);
        if(!$st->fetch())sa_json(['ok'=>false,'mesaj'=>'Bu silah depoda bulunmuyor.'],403);
    }
    if($effect!=='yok'){
        $st=sa_db()->prepare("SELECT adet FROM envanter WHERE kullanici_id=? AND item_id=? AND adet>0");$st->execute([$u['id'],$effect]);
        if(!$st->fetch())$effect='yok';
    }
    sa_db()->prepare("INSERT INTO oyuncu_donanim(kullanici_id,karakter_id,silah_id,efekt_id) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE karakter_id=VALUES(karakter_id),silah_id=VALUES(silah_id),efekt_id=VALUES(efekt_id),guncellenme=NOW()")->execute([$u['id'],$character,$weapon,$effect]);
    sa_json(['ok'=>true,'mesaj'=>'Donanım güncellendi.','donanim'=>['karakter'=>$character,'silah'=>$weapon,'efekt'=>$effect]]);
}
if($action==='donanim_cikar'){
    $u=sa_current();$tip=$_GET['tip']??'';$col=$tip==='silah'?'silah_id':($tip==='efekt'?'efekt_id':($tip==='karakter'?'karakter_id':''));
    if(!$col)sa_json(['ok'=>false,'mesaj'=>'Geçersiz donanım türü.'],422);
    $value=$col==='silah_id'?'tabanca':($col==='karakter_id'?'red':'yok');
    sa_db()->prepare("INSERT INTO oyuncu_donanim(kullanici_id,karakter_id,silah_id,efekt_id) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE $col=VALUES($col)")->execute([$u['id'],'red','tabanca','yok']);
    sa_json(['ok'=>true,'mesaj'=>'Donanım çıkarıldı.']);
}
if($action==='harita_listesi'){sa_json(['ok'=>true,'liste'=>sa_map_catalog()]);}
if($action==='web_harita_oyla'){sa_json(['ok'=>false,'mesaj'=>'Harita değişimi otomatik rotasyon ile yapılır.'],409);}

if($action==='web_harita_oy_durum'){
    $in=json_decode(file_get_contents('php://input'),true)??[];
    $oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['oda']??($in['oda']??'')));
    if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç gerekli.'],422);
    $st=sa_db()->prepare("SELECT UNIX_TIMESTAMP(baslangic) baslangic,harita_id,bitis,durum,max_a,max_b FROM web_aktif_maclar WHERE oda_id=? LIMIT 1");$st->execute([$oda]);$m=$st->fetch();if(!$m)sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);
    $round=sa_map_round($oda,(int)$m['baslangic']);$elapsed=max(0,time()-(int)$m['baslangic']);$cycle=180;$left=$cycle-($elapsed%$cycle);$catalog=sa_map_catalog();
    // Harita oylaması yalnızca gerçek oyuncuların verdiği oylarla belirlenir.
    $st=sa_db()->prepare("SELECT harita_id,COUNT(*) oy FROM web_harita_oylari WHERE oda_id=? AND oy_turu=? GROUP BY harita_id ORDER BY oy DESC,harita_id ASC");$st->execute([$oda,$round]);$votes=$st->fetchAll();
    $out=[];foreach($votes as $v)$out[]=['id'=>$v['harita_id'],'ad'=>$catalog[$v['harita_id']]['ad']??$v['harita_id'],'oy'=>(int)$v['oy']];
    $oyum=null;$auth=sa_auth();if($auth){$st=sa_db()->prepare("SELECT harita_id FROM web_harita_oylari WHERE oda_id=? AND oy_turu=? AND kullanici_id=? LIMIT 1");$st->execute([$oda,$round,(int)$auth['sub']]);$oyum=$st->fetchColumn()?:null;}
    sa_json(['ok'=>true,'tur'=>$round,'kalan'=>max(0,$left),'harita'=>$m['harita_id'],'oylar'=>$out,'oyunuz'=>$oyum,'haritalar'=>$catalog]);
}



/* ========================= Stick Arena 3.0 LOBI / CHAT / ADMIN ========================= */
if($action==='web_lobi_katil'){
    try{
        $u=sa_current(); $in=sa_request_json();
        $mode=($in['mod']??'normal')==='clan'?'clan':'normal';
        $map=preg_replace('/[^a-z0-9_-]/i','',(string)($in['harita']??''));
        $catalog=sa_map_catalog(); if(!isset($catalog[$map]))sa_json(['ok'=>false,'mesaj'=>'Geçersiz harita seçimi.'],422);
        $opponent=($in['rakip_turu']??'real')==='bot'?'bot':'real';
        $invite=strtoupper(substr(preg_replace('/[^A-Z0-9]/','',(string)($in['davet_kodu']??'')),0,8));
        if($invite!=='')$opponent='real';
        $max=$mode==='clan'?20:10; $teamMax=$max/2; $selectedTeam=(($in['takim']??'A')==='B'?'B':'A'); $pdo=sa_db();
        /* Bot modu tek insan + botlar için izole lobi; arkadaş/oyuncu modu ortak eşleşme havuzudur. */
        $existingSql=$opponent==='bot'
          ? "SELECT l.lobi_id,l.harita_id,l.bitis,l.durum,l.`mod`,l.rakip_turu FROM web_lobiler l JOIN web_lobi_uyeleri u ON u.lobi_id=l.lobi_id WHERE l.olusturan_id=? AND l.rakip_turu='bot' AND l.durum='bekliyor' AND l.bitis>NOW() ORDER BY l.id DESC LIMIT 1"
          : "SELECT l.lobi_id,l.harita_id,l.bitis,l.durum,l.`mod`,l.rakip_turu FROM web_lobiler l JOIN web_lobi_uyeleri u ON u.lobi_id=l.lobi_id WHERE u.kullanici_id=? AND l.rakip_turu='real' AND l.durum='bekliyor' AND l.bitis>NOW() ORDER BY l.id DESC LIMIT 1";
        $existing=null;
        if($invite!==''){
            $inviteSt=$pdo->prepare("SELECT l.lobi_id,l.harita_id,l.bitis,l.durum,l.`mod`,l.rakip_turu,l.davet_kodu,l.max_oyuncu FROM web_lobiler l WHERE UPPER(l.davet_kodu)=? AND l.rakip_turu='real' AND l.durum='bekliyor' AND l.bitis>NOW() AND (SELECT COUNT(*) FROM web_lobi_uyeleri x WHERE x.lobi_id=l.lobi_id AND x.son_heartbeat >= (NOW()-INTERVAL 25 SECOND)) < l.max_oyuncu LIMIT 1");
            $inviteSt->execute([$invite]);
            $existing=$inviteSt->fetch();
            if(!$existing){
                sa_json(['ok'=>false,'mesaj'=>'Lobi kodu geçersiz veya lobi süresi dolmuş.'],404);
            }
        } else {
            $st=$pdo->prepare($existingSql);
            $st->execute([(int)$u['id']]);
            $existing=$st->fetch();
        }
        if($existing){
            $pdo->prepare("UPDATE web_lobi_uyeleri SET son_heartbeat=NOW(),takim=? WHERE lobi_id=? AND kullanici_id=?")->execute([$selectedTeam,$existing['lobi_id'],$u['id']]);
            sa_json(['ok'=>true,'lobi'=>$existing['lobi_id'],'harita'=>$existing['harita_id'],'harita_ad'=>$catalog[$existing['harita_id']]['ad'],'mod'=>$existing['mod'],'rakip_turu'=>$existing['rakip_turu'],'kalan'=>max(0,strtotime($existing['bitis'])-time()),'davet_kodu'=>$existing['davet_kodu']??null]);
        }
        if($opponent==='real'){
            $st=$pdo->prepare("SELECT l.* FROM web_lobiler l WHERE l.`mod`=? AND l.harita_id=? AND l.rakip_turu='real' AND l.durum='bekliyor' AND l.bitis>NOW() AND (SELECT COUNT(*) FROM web_lobi_uyeleri x WHERE x.lobi_id=l.lobi_id AND x.son_heartbeat >= (NOW()-INTERVAL 25 SECOND)) < l.max_oyuncu ORDER BY l.id ASC LIMIT 1");
            $st->execute([$mode,$map]); $lobi=$st->fetch();
            if($lobi){$tc=$pdo->prepare("SELECT COUNT(*) FROM web_lobi_uyeleri WHERE lobi_id=? AND takim=? AND son_heartbeat >= (NOW()-INTERVAL 25 SECOND)");$tc->execute([$lobi['lobi_id'],$selectedTeam]);if((int)$tc->fetchColumn()>=$teamMax)sa_json(['ok'=>false,'mesaj'=>'Seçtiğin takım bu lobide dolu. Diğer takımı seç.'],409);}
        } else { $lobi=null; }
        if(!$lobi){
            $lobiId='LOBI_'.strtoupper(bin2hex(random_bytes(6)));
            $life=$opponent==='bot'?6:45; $bitis=date('Y-m-d H:i:s',time()+$life); $lobbyMax=$opponent==='bot'?1:$max; $inviteCode=$opponent==='real'?strtoupper(substr(bin2hex(random_bytes(5)),0,8)):null;
            $pdo->prepare("INSERT INTO web_lobiler(lobi_id,`mod`,harita_id,max_oyuncu,rakip_turu,davet_kodu,durum,olusturan_id,bitis) VALUES(?,?,?,?,?,?, 'bekliyor',?,?)")->execute([$lobiId,$mode,$map,$lobbyMax,$opponent,$inviteCode,(int)$u['id'],$bitis]);
            $lobi=['lobi_id'=>$lobiId,'mod'=>$mode,'harita_id'=>$map,'max_oyuncu'=>$lobbyMax,'bitis'=>$bitis,'rakip_turu'=>$opponent,'davet_kodu'=>$inviteCode];
        }
        $pdo->prepare("INSERT INTO web_lobi_uyeleri(lobi_id,kullanici_id,takim) VALUES(?,?,?) ON DUPLICATE KEY UPDATE son_heartbeat=NOW(),takim=VALUES(takim)")->execute([$lobi['lobi_id'],(int)$u['id'],$selectedTeam]);
        sa_json(['ok'=>true,'lobi'=>$lobi['lobi_id'],'harita'=>$lobi['harita_id'],'harita_ad'=>$catalog[$lobi['harita_id']]['ad'],'mod'=>$lobi['mod'],'rakip_turu'=>$opponent,'kalan'=>max(0,strtotime($lobi['bitis'])-time()),'davet_kodu'=>$lobi['davet_kodu']??null]);
    }catch(Throwable $e){sa_log_event('HATA_LOBI_KATIL',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Lobi işlemi gerçekleştirilemedi.'],500);}
}

if($action==='web_lobi_durum'){
    try{
        $u=sa_current(); $in=sa_request_json(); $lobiId=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['lobi']??($_GET['lobi']??''))); if($lobiId==='')sa_json(['ok'=>false,'mesaj'=>'Lobi kimliği gerekli.'],422);
        $pdo=sa_db(); $st=$pdo->prepare("SELECT * FROM web_lobiler WHERE lobi_id=? LIMIT 1");$st->execute([$lobiId]);$l=$st->fetch(); if(!$l)sa_json(['ok'=>false,'mesaj'=>'Lobi bulunamadı.'],404);
        $member=$pdo->prepare("SELECT id FROM web_lobi_uyeleri WHERE lobi_id=? AND kullanici_id=? LIMIT 1");$member->execute([$lobiId,$u['id']]);if(!$member->fetch())sa_json(['ok'=>false,'mesaj'=>'Bu lobinin üyesi değilsiniz.'],403);
        $pdo->prepare("UPDATE web_lobi_uyeleri SET son_heartbeat=NOW() WHERE lobi_id=? AND kullanici_id=?")->execute([$lobiId,$u['id']]);
        if($l['durum']==='bekliyor'){
            $countSt=$pdo->prepare("SELECT COUNT(*) FROM web_lobi_uyeleri WHERE lobi_id=? AND son_heartbeat >= (NOW()-INTERVAL 25 SECOND)");$countSt->execute([$lobiId]);$count=(int)$countSt->fetchColumn();$remaining=max(0,strtotime($l['bitis'])-time());
            /*
 * BOT: tek oyuncu bile yeterli; BOT kadrosu sunucu tarafında tamamlanır.
 * REAL: davet kodlu/normal lobi timer bitene kadar bekler; süre dolduğunda
 * 1 kişi dahil mevcut aktif oyuncu sayısıyla maç başlatılır. Böylece
 * 5/10 kişilik doluluk şartı yüzünden 'lobi süresi doldu' durumuna düşmez.
 * 2+ kişi daha erken başlatma davranışı korunur.
 */
$shouldStart = $l['rakip_turu']==='bot'
    ? ($count>=1)
    : ($count>=2 || ($remaining<=0 && $count>=1));
            if($shouldStart){
                $pdo->beginTransaction();
                try{
                    $lock=$pdo->prepare("SELECT * FROM web_lobiler WHERE lobi_id=? FOR UPDATE");$lock->execute([$lobiId]);$l=$lock->fetch();
                    if($l && $l['durum']==='bekliyor'){
                        $usersSt=$pdo->prepare("SELECT u.kullanici_id,u.takim FROM web_lobi_uyeleri u WHERE u.lobi_id=? AND u.son_heartbeat >= (NOW()-INTERVAL 25 SECOND) ORDER BY u.katilma_tarihi,u.id LIMIT ".max(1,(int)$l['max_oyuncu']));$usersSt->execute([$lobiId]);$userRows=$usersSt->fetchAll();
                        $statePlayers=[]; $teamSize=$l['mod']==='clan'?10:5;
                        foreach($userRows as $ur){$uid=(int)$ur['kullanici_id'];$profile=sa_game_profile($uid);$team=$ur['takim']==='B'?'B':'A';$sp=sa_spawn_position($team);$statePlayers[]=['id'=>$profile['id'],'name'=>$profile['name'],'team'=>$team,'x'=>$sp['x'],'y'=>$sp['y'],'vx'=>0,'vy'=>0,'hp'=>100,'kills'=>0,'deaths'=>0,'death_seq'=>0,'respawn'=>0,'respawn_at'=>0,'combat_at'=>0,'character'=>sa_normalize_character((string)($profile['character']??''),$team),'weapon'=>sa_normalize_weapon((string)($profile['weapon']??'pistol')),'ammo'=>sa_weapon_ammo_max((string)($profile['weapon']??'pistol')),'efekt'=>$profile['efekt'],'admin'=>$profile['admin'],'dogrulanmis'=>$profile['dogrulanmis'],'klan'=>$profile['klan'],'klan_etiket'=>$profile['klan_etiket'],'real'=>true,'bot'=>false];}
                        if($l['rakip_turu']==='bot'){
                            $humanTeam=$statePlayers[0]['team']??'A'; $botNo=0; $characters=['red','blue','gold']; $arsenal=['tabanca','tufek','makineli_tufek','pompal_tufek','roketatar','keskin_nisanci','karbon_silah','karanlik_silah','neon_silah','altin_silah','alev_silah','buz_silah'];
                            foreach(['A','B'] as $team){$need=$teamSize-(int)count(array_filter($statePlayers,fn($p)=>$p['team']===$team));for($j=0;$j<$need;$j++){ $spBot=sa_spawn_position($team); $botNo++; $id=900000+$botNo; $weapon=$arsenal[($botNo-1)%count($arsenal)]; $statePlayers[]=['id'=>$id,'name'=>($team===$humanTeam?'BOT • Müttefik ':'BOT • Rakip ').str_pad((string)$botNo,2,'0',STR_PAD_LEFT),'team'=>$team,'x'=>$spBot['x'],'y'=>$spBot['y'],'vx'=>0,'vy'=>0,'hp'=>100,'kills'=>0,'deaths'=>0,'death_seq'=>0,'respawn'=>0,'respawn_at'=>0,'combat_at'=>0,'character'=>($team==='A'?'red':'blue'),'weapon'=>sa_normalize_weapon($weapon),'ammo'=>sa_weapon_ammo_max($weapon),'efekt'=>'yok','admin'=>false,'dogrulanmis'=>false,'klan'=>null,'klan_etiket'=>null,'real'=>false,'bot'=>true,'ai_seed'=>random_int(1,999999)]; }}
                        }
                        $mapState=['id'=>$l['harita_id'],'genislik'=>3200,'yukseklik'=>720,'platformlar'=>sa_map_layout($l['harita_id']),'baslangic_harita'=>$l['harita_id'],'tur'=>0,'rakip_turu'=>$l['rakip_turu']];
                        $oda='WEB_'.strtoupper(bin2hex(random_bytes(5))); $creator=(int)$l['olusturan_id'];
                        $pdo->prepare("INSERT INTO web_aktif_maclar(oda_id,kullanici_id,`mod`,harita_id,rakip_turu,skor_a,skor_b,oyuncu_a,oyuncu_b,max_a,max_b,baslangic,bitis,son_heartbeat,durum,state_json,map_json,clan_a,clan_b) VALUES(?,?,?,?,?,0,0,?,?,?,?,NOW(),DATE_ADD(NOW(),INTERVAL 15 MINUTE),NOW(),'aktif',?,?,NULL,NULL)")
                           ->execute([$oda,$creator,$l['mod'],$l['harita_id'],$l['rakip_turu'],count(array_filter($statePlayers,fn($p)=>$p['team']==='A'&&$p['real'])),count(array_filter($statePlayers,fn($p)=>$p['team']==='B'&&$p['real'])),$teamSize,$teamSize,json_encode(['players'=>$statePlayers,'bullets'=>[]],JSON_UNESCAPED_UNICODE),json_encode($mapState,JSON_UNESCAPED_UNICODE)]);
                        $pdo->prepare("INSERT INTO web_mac_kontrol(oda_id,duraklatildi,takim_degisti) VALUES(?,0,0) ON DUPLICATE KEY UPDATE duraklatildi=0,takim_degisti=0")->execute([$oda]);
                        $pdo->prepare("UPDATE web_lobiler SET durum='basladi',oda_id=?,baslama=NOW() WHERE lobi_id=?")->execute([$oda,$lobiId]); $l['durum']='basladi';$l['oda_id']=$oda;
                    }
                    $pdo->commit();
                }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
            } elseif($l['rakip_turu']==='real' && $remaining<=0 && $count<=0) {
                sa_json(['ok'=>true,'durum'=>'suresi_doldu','lobi'=>$lobiId,'mod'=>$l['mod'],'rakip_turu'=>$l['rakip_turu'],'davet_kodu'=>$l['davet_kodu']??null,'harita'=>$l['harita_id'],'harita_ad'=>sa_map_catalog()[$l['harita_id']]['ad']??$l['harita_id'],'oyuncu'=>$count,'max'=>(int)$l['max_oyuncu'],'oyuncular'=>sa_lobby_players($lobiId),'kalan'=>0]);
            }
        }
        if($l['durum']==='basladi' && !empty($l['oda_id'])){
            $st2=$pdo->prepare("SELECT state_json FROM web_aktif_maclar WHERE oda_id=? LIMIT 1");$st2->execute([$l['oda_id']]);$room=$st2->fetch();$state=json_decode($room['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];$all=$state['players']??[];
            sa_json(['ok'=>true,'durum'=>'basladi','lobi'=>$lobiId,'oda'=>$l['oda_id'],'mod'=>$l['mod'],'rakip_turu'=>$l['rakip_turu'],'admin_gamemode'=>!empty(($state['admin_gamemode']??[])[(string)$u['id']]),'davet_kodu'=>$l['davet_kodu']??null,'harita'=>$l['harita_id'],'harita_ad'=>sa_map_catalog()[$l['harita_id']]['ad']??$l['harita_id'],'oyuncu'=>count($all),'gercek_oyuncu'=>count(array_filter($all,fn($p)=>!empty($p['real']))),'bot_sayisi'=>count(array_filter($all,fn($p)=>!empty($p['bot']))),'max'=>(int)($l['max_oyuncu']?:($l['mod']==='clan'?20:10)),'oyuncular'=>$all,'kalan'=>max(0,strtotime($l['baslama']??date('Y-m-d H:i:s',time()))-time())]);
        }
        $players=sa_lobby_players($lobiId);$count=count($players);sa_json(['ok'=>true,'durum'=>'bekliyor','lobi'=>$lobiId,'mod'=>$l['mod'],'rakip_turu'=>$l['rakip_turu'],'davet_kodu'=>$l['davet_kodu']??null,'harita'=>$l['harita_id'],'harita_ad'=>sa_map_catalog()[$l['harita_id']]['ad']??$l['harita_id'],'oyuncu'=>$count,'max'=>(int)$l['max_oyuncu'],'oyuncular'=>$players,'kalan'=>max(0,strtotime($l['bitis'])-time())]);
    }catch(Throwable $e){sa_log_event('HATA_LOBI_DURUM',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Lobi durumu geçici olarak alınamıyor.'],500);}
}

if($action==='web_lobi_iptal'){
    $u=sa_current();$in=json_decode(file_get_contents('php://input'),true)??[];$lobi=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['lobi']??''));
    if($lobi!=='')sa_db()->prepare("DELETE l FROM web_lobiler l WHERE l.lobi_id=? AND l.durum='bekliyor' AND l.olusturan_id=?")->execute([$lobi,$u['id']]);
    sa_json(['ok'=>true]);
}

if($action==='web_chat_gonder'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$msg=trim((string)($in['mesaj']??''));
        $msg=mb_substr($msg,0,180);if(!$oda||$msg==='')sa_json(['ok'=>false,'mesaj'=>'Mesaj boş olamaz.'],422);
        $mod=sa_chat_moderation_status((int)$u['id']);
        if($mod['ban_until']>time())sa_json(['ok'=>false,'mesaj'=>'Sohbet kullanımınız geçici olarak engellendi.'],403);
        if($mod['mute_until']>time())sa_json(['ok'=>false,'mesaj'=>'Sohbette sessize alındınız. Kalan süre: '.max(1,ceil(($mod['mute_until']-time())/60)).' dk.'],403);
        $st=sa_db()->prepare("SELECT id FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1");$st->execute([$oda]);if(!$st->fetch())sa_json(['ok'=>false,'mesaj'=>'Bu maç aktif değil.'],404);
        $ins=sa_db()->prepare("INSERT INTO web_mac_sohbet(oda_id,kullanici_id,mesaj) VALUES(?,?,?)");$ins->execute([$oda,$u['id'],$msg]);$id=(int)sa_db()->lastInsertId();
        $cl=sa_db()->prepare("SELECT k.ad FROM klan_uyeleri ku JOIN klanlar k ON k.id=ku.klan_id WHERE ku.kullanici_id=? LIMIT 1");$cl->execute([$u['id']]);$klanAd=$cl->fetchColumn()?:null;
        sa_json(['ok'=>true,'mesaj'=>$msg,'kayit'=>['id'=>$id,'kullanici_id'=>(int)$u['id'],'mesaj'=>$msg,'kullanici_adi'=>$u['kullanici_adi']??'Oyuncu','yetki'=>$u['yetki']??'user','admin'=>sa_role_is_admin($u['yetki']??''),'dogrulanmis'=>(bool)$mod['dogrulanmis'],'klan_ad'=>$klanAd]]);
    }catch(Throwable $e){sa_log_event('HATA_WEB_CHAT_GONDER',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Sohbet mesajı şu anda kaydedilemedi.'],500);}
}
if($action==='web_chat_liste'){
    $u=sa_current();$body=json_decode(file_get_contents('php://input'),true)??[];$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['oda']??($body['oda']??'')));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç gerekli.'],422);
    $st=sa_db()->prepare("SELECT c.id,c.kullanici_id,c.mesaj,c.tarih,COALESCE(u.kullanici_adi,CONCAT('Oyuncu #',c.kullanici_id)) AS kullanici_adi,COALESCE(u.yetki,'user') AS yetki,COALESCE(u.dogrulanmis,0) AS dogrulanmis,k.ad AS klan_ad FROM web_mac_sohbet c LEFT JOIN kullanicilar u ON u.id=c.kullanici_id LEFT JOIN klan_uyeleri ku ON ku.kullanici_id=c.kullanici_id LEFT JOIN klanlar k ON k.id=ku.klan_id WHERE c.oda_id=? ORDER BY c.id DESC LIMIT 80");$st->execute([$oda]);$rows=array_reverse($st->fetchAll());sa_json(['ok'=>true,'liste'=>$rows]);
}


if($action==='chat_kullanici_islem'){
    try{
        $a=sa_require_admin();$in=sa_request_json();$uid=(int)($in['kullanici_id']??0);$islem=(string)($in['islem']??'');$sure=max(1,min(43200,(int)($in['sure_dk']??10)));
        if($uid<=0)sa_json(['ok'=>false,'mesaj'=>'Oyuncu bulunamadı.'],422);
        $st=sa_db()->prepare("SELECT id,kullanici_adi,yetki FROM kullanicilar WHERE id=? LIMIT 1");$st->execute([$uid]);$target=$st->fetch();if(!$target)sa_json(['ok'=>false,'mesaj'=>'Oyuncu bulunamadı.'],404);
        if($islem==='mute') $sql="UPDATE kullanicilar SET chat_mute_until=? WHERE id=?";
        elseif($islem==='unmute') {$sql="UPDATE kullanicilar SET chat_mute_until=0 WHERE id=?";sa_db()->prepare($sql)->execute([$uid]);sa_log_event('CHAT_UNMUTE','uid='.$uid,(int)$a['id']);sa_json(['ok'=>true,'mesaj'=>'Oyuncunun sohbet sessizi kaldırıldı.']);}
        elseif($islem==='ban') $sql="UPDATE kullanicilar SET ban_until=? WHERE id=?";
        elseif($islem==='unban') {$sql="UPDATE kullanicilar SET ban_until=0 WHERE id=?";sa_db()->prepare($sql)->execute([$uid]);sa_log_event('CHAT_UNBAN','uid='.$uid,(int)$a['id']);sa_json(['ok'=>true,'mesaj'=>'Oyuncunun engeli kaldırıldı.']);}
        elseif($islem==='verify') {$sql="UPDATE kullanicilar SET dogrulanmis=1 WHERE id=?";sa_db()->prepare($sql)->execute([$uid]);sa_log_event('OYUNCU_DOGRULANDI','uid='.$uid,(int)$a['id']);sa_json(['ok'=>true,'mesaj'=>'Oyuncu doğrulandı.']);}
        elseif($islem==='unverify') {$sql="UPDATE kullanicilar SET dogrulanmis=0 WHERE id=?";sa_db()->prepare($sql)->execute([$uid]);sa_log_event('OYUNCU_DOGRULAMA_KALDIRILDI','uid='.$uid,(int)$a['id']);sa_json(['ok'=>true,'mesaj'=>'Doğrulama kaldırıldı.']);}
        else sa_json(['ok'=>false,'mesaj'=>'Geçersiz moderasyon işlemi.'],422);
        $until=time()+$sure*60;sa_db()->prepare($sql)->execute([$until,$uid]);sa_log_event('CHAT_MODERASYON',$islem.' uid='.$uid.' sure='.$sure,(int)$a['id']);sa_json(['ok'=>true,'mesaj'=>$islem==='mute'?'Oyuncu sessize alındı.':'Oyuncu engellendi.','bitis'=>$until]);
    }catch(Throwable $e){sa_log_event('HATA_CHAT_MODERASYON',$e->getMessage(),isset($a['id'])?(int)$a['id']:null);sa_json(['ok'=>false,'mesaj'=>'Moderasyon işlemi başarısız: '.$e->getMessage()],500);}
}
if($action==='liderlik'){
    try{
        $pdo=sa_db();
        $rows=$pdo->query("SELECT u.id,u.kullanici_adi,u.seviye,u.rating,u.galibiyet,u.maglubiyet,u.xp,u.dogrulanmis,GREATEST(COALESCE(u.oldurme,0),COALESCE(ks.oldurme,0)) oldurme,u.olum FROM kullanicilar u LEFT JOIN (SELECT killer_id,COUNT(*) oldurme,0 base_oldurme FROM oyuncu_kill_log GROUP BY killer_id) ks ON ks.killer_id=u.id ORDER BY u.rating DESC,oldurme DESC,u.id ASC LIMIT 100")->fetchAll();
        $out=[];$rank=0;
        foreach($rows as $r){$rank++;$kills=max(0,(int)$r['oldurme']);$out[]=['sira'=>$rank,'id'=>(int)$r['id'],'kullanici_adi'=>$r['kullanici_adi'],'seviye'=>(int)$r['seviye'],'rating'=>(int)$r['rating'],'galibiyet'=>(int)$r['galibiyet'],'maglubiyet'=>(int)$r['maglubiyet'],'oldurme'=>$kills,'olum'=>(int)$r['olum'],'xp'=>(int)$r['xp'],'dogrulanmis'=>(bool)$r['dogrulanmis']];}
        sa_json(['ok'=>true,'liste'=>$out]);
    }catch(Throwable $e){
        try{$rows=sa_db()->query("SELECT id,kullanici_adi,seviye,rating,galibiyet,maglubiyet,oldurme,olum,xp,dogrulanmis FROM kullanicilar ORDER BY rating DESC,oldurme DESC,id ASC LIMIT 100")->fetchAll();$out=[];$rank=0;foreach($rows as $r){$rank++;$out[]=['sira'=>$rank,'id'=>(int)$r['id'],'kullanici_adi'=>$r['kullanici_adi'],'seviye'=>(int)$r['seviye'],'rating'=>(int)$r['rating'],'galibiyet'=>(int)$r['galibiyet'],'maglubiyet'=>(int)$r['maglubiyet'],'oldurme'=>(int)$r['oldurme'],'olum'=>(int)$r['olum'],'xp'=>(int)$r['xp'],'dogrulanmis'=>(bool)$r['dogrulanmis']];}sa_json(['ok'=>true,'liste'=>$out]);}catch(Throwable $x){sa_json(['ok'=>false,'mesaj'=>'Liderlik verisi alınamadı: '.$x->getMessage()],500);}
    }
}
if($action==='klan_listesi'){
    $rows=sa_db()->query("SELECT k.id,k.ad,k.etiket,k.seviye,k.puan,COUNT(ku.kullanici_id) uye_sayisi FROM klanlar k LEFT JOIN klan_uyeleri ku ON ku.klan_id=k.id GROUP BY k.id ORDER BY k.puan DESC,k.seviye DESC,k.id ASC LIMIT 100")->fetchAll();$auth=sa_auth();$uid=$auth?(int)$auth['sub']:0;$out=[];foreach($rows as $r){$flag=false;if($uid){$q=sa_db()->prepare("SELECT 1 FROM klan_istekleri WHERE klan_id=? AND kullanici_id=? AND durum='bekliyor' LIMIT 1");$q->execute([$r['id'],$uid]);$flag=(bool)$q->fetchColumn();}$out[]=['id'=>(int)$r['id'],'ad'=>$r['ad'],'etiket'=>$r['etiket'],'seviye'=>(int)$r['seviye'],'puan'=>(int)$r['puan'],'uye_sayisi'=>(int)$r['uye_sayisi'],'istek_gonderildi'=>$flag];}sa_json(['ok'=>true,'liste'=>$out]);
}
if($action==='klan_bilgi'){
    $u=sa_current();$q=sa_db()->prepare("SELECT k.*,ku.rol FROM klan_uyeleri ku JOIN klanlar k ON k.id=ku.klan_id WHERE ku.kullanici_id=? LIMIT 1");$q->execute([$u['id']]);$k=$q->fetch();if(!$k)sa_json(['ok'=>true,'klan'=>null,'istekler'=>[]]);$m=sa_db()->prepare("SELECT u.id,u.kullanici_adi,ku.rol,u.seviye,u.rating,u.dogrulanmis FROM klan_uyeleri ku JOIN kullanicilar u ON u.id=ku.kullanici_id WHERE ku.klan_id=? ORDER BY FIELD(ku.rol,'sahip','yonetici','uye'),u.rating DESC");$m->execute([$k['id']]);$req=[];if(in_array($k['rol'],['sahip','yonetici'],true)){$r=sa_db()->prepare("SELECT i.id,u.kullanici_adi FROM klan_istekleri i JOIN kullanicilar u ON u.id=i.kullanici_id WHERE i.klan_id=? AND i.durum='bekliyor' ORDER BY i.id DESC");$r->execute([$k['id']]);$req=$r->fetchAll();}sa_json(['ok'=>true,'klan'=>['id'=>(int)$k['id'],'ad'=>$k['ad'],'etiket'=>$k['etiket'],'seviye'=>(int)$k['seviye'],'puan'=>(int)$k['puan'],'sahip_id'=>(int)$k['sahip_id'],'rol'=>$k['rol'],'uyeler'=>$m->fetchAll()],'istekler'=>$req]);
}
if($action==='klan_istek_gonder'){$u=sa_current();$in=sa_request_json();$id=(int)($in['klan_id']??0);if(!$id)sa_json(['ok'=>false,'mesaj'=>'Klan seçilmedi.'],422);try{sa_db()->prepare("INSERT INTO klan_istekleri(klan_id,kullanici_id,durum) VALUES(?,?,'bekliyor') ON DUPLICATE KEY UPDATE durum='bekliyor',tarih=NOW()")->execute([$id,$u['id']]);sa_json(['ok'=>true,'mesaj'=>'Katılım isteği gönderildi.']);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'İstek gönderilemedi: '.$e->getMessage()],500);}}
if($action==='klan_istek_karar'){$u=sa_current();$in=sa_request_json();$id=(int)($in['istek_id']??0);$karar=($in['karar']??'')==='onay'?'onaylandi':'reddedildi';$q=sa_db()->prepare("SELECT i.*,k.sahip_id FROM klan_istekleri i JOIN klanlar k ON k.id=i.klan_id WHERE i.id=? LIMIT 1");$q->execute([$id]);$r=$q->fetch();if(!$r||((int)$r['sahip_id']!==(int)$u['id']))sa_json(['ok'=>false,'mesaj'=>'Yetkisiz işlem.'],403);if($karar==='onaylandi'){sa_db()->beginTransaction();try{sa_db()->prepare("INSERT INTO klan_uyeleri(klan_id,kullanici_id,rol) VALUES(?,?, 'uye') ON DUPLICATE KEY UPDATE klan_id=VALUES(klan_id)")->execute([$r['klan_id'],$r['kullanici_id']]);sa_db()->prepare("UPDATE klan_istekleri SET durum='onaylandi' WHERE id=?")->execute([$id]);sa_db()->commit();}catch(Throwable $e){sa_db()->rollBack();throw $e;}}else sa_db()->prepare("UPDATE klan_istekleri SET durum='reddedildi' WHERE id=?")->execute([$id]);sa_json(['ok'=>true]);}
if($action==='klan_yonet'){$u=sa_current();$in=sa_request_json();$uid=(int)($in['kullanici_id']??0);$is=(string)($in['islem']??'');$q=sa_db()->prepare("SELECT k.id FROM klanlar k JOIN klan_uyeleri ku ON ku.klan_id=k.id WHERE k.sahip_id=? AND ku.kullanici_id=? LIMIT 1");$q->execute([$u['id'],$u['id']]);$klan=$q->fetchColumn();if(!$klan)sa_json(['ok'=>false,'mesaj'=>'Yalnızca klan sahibi yönetebilir.'],403);if($is==='at')sa_db()->prepare("DELETE FROM klan_uyeleri WHERE klan_id=? AND kullanici_id=?")->execute([$klan,$uid]);elseif(in_array($is,['uye','yonetici'],true))sa_db()->prepare("UPDATE klan_uyeleri SET rol=? WHERE klan_id=? AND kullanici_id=? AND kullanici_id<>? ")->execute([$is,$klan,$uid,$u['id']]);else sa_json(['ok'=>false,'mesaj'=>'Geçersiz işlem.'],422);sa_json(['ok'=>true,'mesaj'=>'Klan güncellendi.']);}
if($action==='klan_olustur'){$u=sa_current();$in=sa_request_json();$ad=trim((string)($in['ad']??''));$et=trim((string)($in['etiket']??''));if(mb_strlen($ad)<3||mb_strlen($ad)>32||!preg_match('/^[A-Za-z0-9_-]{2,8}$/',$et))sa_json(['ok'=>false,'mesaj'=>'Klan adı veya etiketi geçersiz.'],422);$q=sa_db()->prepare("SELECT 1 FROM klan_uyeleri WHERE kullanici_id=?");$q->execute([$u['id']]);if($q->fetch())sa_json(['ok'=>false,'mesaj'=>'Zaten bir klana üyesiniz.'],409);$key=sa_db()->prepare("SELECT adet FROM envanter WHERE kullanici_id=? AND item_id='klan_anahtari' AND adet>0 LIMIT 1");$key->execute([$u['id']]);if(!$key->fetch())sa_json(['ok'=>false,'mesaj'=>'Klan oluşturmak için Klan Kurma Anahtarı gerekiyor.'],403);sa_db()->beginTransaction();try{$st=sa_db()->prepare("INSERT INTO klanlar(ad,etiket,sahip_id) VALUES(?,?,?)");$st->execute([$ad,$et,$u['id']]);$kid=(int)sa_db()->lastInsertId();sa_db()->prepare("INSERT INTO klan_uyeleri(klan_id,kullanici_id,rol) VALUES(?,?,'sahip')")->execute([$kid,$u['id']]);sa_db()->prepare("UPDATE envanter SET adet=adet-1 WHERE kullanici_id=? AND item_id='klan_anahtari' AND adet>0")->execute([$u['id']]);sa_db()->prepare("DELETE FROM envanter WHERE kullanici_id=? AND item_id='klan_anahtari' AND adet<=0")->execute([$u['id']]);sa_db()->commit();sa_json(['ok'=>true,'mesaj'=>'Klan oluşturuldu. Klan Kurma Anahtarı kullanıldı.']);}catch(Throwable $e){sa_db()->rollBack();sa_json(['ok'=>false,'mesaj'=>'Klan oluşturulamadı: '.$e->getMessage()],500);}}

if($action==='klan_savas_baslat'){
 $u=sa_current();$in=sa_request_json();$target=(int)($in['hedef_klan_id']??0);$q=sa_db()->prepare("SELECT k.id,k.sahip_id FROM klanlar k JOIN klan_uyeleri ku ON ku.klan_id=k.id WHERE ku.kullanici_id=? LIMIT 1");$q->execute([$u['id']]);$mine=$q->fetch();if(!$mine||((int)$mine['sahip_id']!==(int)$u['id']))sa_json(['ok'=>false,'mesaj'=>'Klan savaşı yalnızca klan sahibi tarafından başlatılabilir.'],403);if($target===(int)$mine['id'])sa_json(['ok'=>false,'mesaj'=>'Kendi klanınıza savaş açamazsınız.'],422);$q=sa_db()->prepare("SELECT id FROM klanlar WHERE id=?");$q->execute([$target]);if(!$q->fetch())sa_json(['ok'=>false,'mesaj'=>'Rakip klan bulunamadı.'],404);$oda='CLAN_'.strtoupper(bin2hex(random_bytes(5)));sa_db()->prepare("INSERT INTO klan_savaslari(oda_id,klan_a,klan_b,durum,baslangic) VALUES(?,?,?,'aktif',NOW())")->execute([$oda,$mine['id'],$target]);sa_json(['ok'=>true,'oda'=>$oda,'mesaj'=>'10v10 klan savaşı hazırlandı.']);
}
if($action==='web_mac_baslat'){
    // Geriye dönük uyumluluk: eski istemciler doğrudan çağırırsa da güvenli şekilde oda açılır.
    try{$u=sa_current();$in=json_decode(file_get_contents('php://input'),true)??[];$mode=($in['mod']??'normal')==='clan'?'clan':'normal';$size=$mode==='clan'?10:5;$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));if(!$oda)$oda='WEB_'.strtoupper(bin2hex(random_bytes(5)));$map=preg_replace('/[^a-z0-9_-]/i','',(string)($in['harita']??'col_bolgesi'));if(!isset(sa_map_catalog()[$map]))$map='col_bolgesi';$pdo=sa_db();$pdo->prepare("INSERT INTO web_aktif_maclar(oda_id,kullanici_id,`mod`,harita_id,skor_a,skor_b,oyuncu_a,oyuncu_b,max_a,max_b,baslangic,bitis,son_heartbeat,durum,state_json,map_json,clan_a,clan_b) VALUES(?,?,?,?,0,0,1,0,?,?,?,?,NOW(),DATE_ADD(NOW(),INTERVAL 15 MINUTE),NOW(),'aktif',?,?,NULL,NULL)")->execute([$oda,$u['id'],$mode,$map,1,$size,$size,json_encode(['players'=>[],'bullets'=>[]]),json_encode(['id'=>$map,'genislik'=>3200,'yukseklik'=>720,'platformlar'=>sa_map_layout($map),'baslangic_harita'=>$map,'tur'=>0])]);$pdo->prepare("INSERT INTO web_mac_kontrol(oda_id,duraklatildi,takim_degisti) VALUES(?,0,0) ON DUPLICATE KEY UPDATE duraklatildi=0,takim_degisti=0")->execute([$oda]);sa_json(['ok'=>true,'oda'=>$oda,'mod'=>$mode,'harita'=>$map]);}catch(Throwable $e){sa_log_event('HATA_MAC_BASLAT',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Maç başlatılamadı: '.$e->getMessage()],500);}
}

if($action==='admin_gamemode'){
    try{
        $a=sa_require_admin();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$mode=((int)($in['mode']??0)===1);
        if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();$pdo->beginTransaction();
        $st=$pdo->prepare("SELECT state_json FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();
        if(!$m){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Aktif maç bulunamadı.'],404);}
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];
        if(!isset($state['admin_gamemode'])||!is_array($state['admin_gamemode']))$state['admin_gamemode']=[];
        if($mode){
            $state['admin_gamemode'][(string)$a['id']]=true;
            foreach($state['players'] as &$gp){if((int)($gp['id']??0)===(int)$a['id']){$gp['hp']=100;$gp['weapon']=sa_normalize_weapon((string)($gp['weapon']??'pistol'));$gp['ammo']=999999;$gp['admin']=true;}}unset($gp);
        }else unset($state['admin_gamemode'][(string)$a['id']]);
        $pdo->prepare("UPDATE web_aktif_maclar SET state_json=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'")->execute([json_encode($state,JSON_UNESCAPED_UNICODE),$oda]);
        $pdo->commit();sa_log_event('ADMIN_GAMEMODE',$mode?'1':'0',(int)$a['id']);
        sa_json(['ok'=>true,'enabled'=>$mode,'mesaj'=>$mode?'Gamemode 1 aktif.':'Gamemode kapatıldı.']);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Gamemode uygulanamadı.'],500);}
}

if($action==='web_mac_ayril'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));
        if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();$pdo->beginTransaction();$st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();
        if(!$m){$pdo->commit();sa_json(['ok'=>true]);}
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];
        $state['players']=array_values(array_filter($state['players']??[],fn($p)=>(int)($p['id']??0)!==(int)$u['id']));
        if(isset($state['admin_gamemode'][(string)$u['id']]))unset($state['admin_gamemode'][(string)$u['id']]);
        $realA=count(array_filter($state['players'],fn($p)=>($p['team']??'A')==='A'&&!empty($p['real'])));$realB=count(array_filter($state['players'],fn($p)=>($p['team']??'A')==='B'&&!empty($p['real'])));
        $pdo->prepare("UPDATE web_aktif_maclar SET oyuncu_a=?,oyuncu_b=?,state_json=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'")->execute([$realA,$realB,json_encode($state,JSON_UNESCAPED_UNICODE),$oda]);
        if($realA+$realB===0)$pdo->prepare("UPDATE web_aktif_maclar SET durum='bitti',bitis=NOW() WHERE oda_id=? AND durum='aktif'")->execute([$oda]);
        $pdo->commit();sa_json(['ok'=>true,'ayrildi'=>true]);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Maçtan ayrılamadın.'],500);}
}

if($action==='web_mac_heartbeat'){
    try{
        $u=sa_current(); $in=sa_request_json(); $oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??'')); if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();$st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();if(!$m)sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı veya sona erdi.'],404);
        $stored=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];
        $storedPlayers=$stored['players']??[];
        $adminGamemode=is_array($stored['admin_gamemode']??null)?$stored['admin_gamemode']:[];
        $byId=[];
        foreach($storedPlayers as $sp){$byId[(string)($sp['id']??'')]=$sp;}

        $incoming=is_array($in['players']??null)?array_slice($in['players'],0,20):[];
        $allowedWeapons=array_keys(sa_item_catalog());
        $incomingById=[];
        foreach($incoming as $ip){
            $id=(string)($ip['id']??'');
            if($id==='')continue;
            $ip['x']=(float)($ip['x']??0);
            $ip['y']=(float)($ip['y']??0);
            $ip['vx']=(float)($ip['vx']??0);
            $ip['vy']=(float)($ip['vy']??0);
            $ip['team']=(($ip['team']??'A')==='B'?'B':'A');
            $ip['hp']=max(0,min(100,(int)($ip['hp']??100)));
            $incomingById[$id]=$ip;
        }

        $isHost=((int)$m['kullanici_id']===(int)$u['id']);
        $botMode=($m['rakip_turu']??'real')==='bot';
        foreach($byId as $id=>$old){
            $isOwnReal=((int)$id===(int)$u['id']&&!empty($old['real']));
            $isOwnedBot=$botMode&&$isHost&&!empty($old['bot']);
            if(!($isOwnReal||$isOwnedBot)||!isset($incomingById[$id])) continue;

            $inc=$incomingById[$id];
            $inc['id']=(int)$old['id'];
            $inc['name']=$old['name']??$inc['name']??'Oyuncu';
            $inc['team']=$old['team']??$inc['team']??'A';
            $inc['real']=(bool)($old['real']??false);
            $inc['bot']=(bool)($old['bot']??false);
            $inc['admin']=(bool)($old['admin']??false);
            $inc['dogrulanmis']=(bool)($old['dogrulanmis']??false);
            $inc['klan']=$old['klan']??($inc['klan']??null);
            $inc['klan_etiket']=$old['klan_etiket']??($inc['klan_etiket']??null);
            $inc['character']=sa_normalize_character((string)($old['character']??$inc['character']??''),$inc['team']);

            // Combat state is SERVER AUTHORITATIVE. Heartbeats only update movement.
            $serverHp=(int)($old['hp']??100);
            $serverRespawn=(int)($old['respawn']??0);
            $serverRespawnAt=(int)($old['respawn_at']??0);
            $serverDeathSeq=(int)($old['death_seq']??0);
            $serverKills=(int)($old['kills']??0);
            $serverDeaths=(int)($old['deaths']??0);
            $serverCombatAt=(int)($old['combat_at']??0);
            $serverWeapon=$old['weapon']??null;
            $serverAmmo=(int)($old['ammo']??0);
            $serverSpawnProtectedUntil=(int)($old['spawn_protected_until_ms']??0);
            $isAdminGamemode=!empty($adminGamemode[(string)$id]) && ((int)$id===(int)$u['id'] ? sa_role_is_admin($u['yetki']??'') : !empty($old['admin']));

            if($isAdminGamemode){
                $inc['hp']=100;
                $inc['respawn']=0;
                $inc['respawn_at']=0;
                $inc['deaths']=$serverDeaths;
                $inc['kills']=$serverKills;
                $inc['combat_at']=$serverCombatAt;
                $inc['spawn_protected_until_ms']=0;
                $inc['weapon']=$serverWeapon ?: 'pistol';
                $inc['ammo']=999999;
                $byId[$id]=$inc;
                continue;
            }

            if($serverHp<=0 && $serverRespawnAt>time()){
                $inc['hp']=0;
                $inc['respawn']=max(0,$serverRespawnAt-time());
                $inc['respawn_at']=$serverRespawnAt;
                $inc['death_seq']=$serverDeathSeq;
                $inc['deaths']=$serverDeaths;
                $inc['kills']=$serverKills;
                $inc['spawn_protected_until_ms']=$serverSpawnProtectedUntil;
                $inc['weapon']=null;
                $inc['ammo']=0;
            }elseif($serverHp<=0 && $serverRespawnAt>0 && $serverRespawnAt<=time()){
                $sp=sa_spawn_position($inc['team']);
                $inc['hp']=100;
                $inc['respawn']=0;
                $inc['respawn_at']=0;
                $inc['death_seq']=$serverDeathSeq;
                $inc['deaths']=$serverDeaths;
                $inc['kills']=$serverKills;
                $inc['x']=$sp['x'];
                $inc['y']=$sp['y'];
                $inc['vx']=0;
                $inc['vy']=0;
                $inc['weapon']='pistol';
                $inc['ammo']=sa_weapon_ammo_max('pistol');
                $inc['spawn_protected_until_ms']=max($serverSpawnProtectedUntil,(int)round(microtime(true)*1000)+3000);
            }else{
                $inc['hp']=$serverHp;
                $inc['respawn']=max(0,$serverRespawn);
                $inc['respawn_at']=$serverRespawnAt;
                $inc['death_seq']=$serverDeathSeq;
                $inc['kills']=$serverKills;
                $inc['deaths']=$serverDeaths;
                $inc['combat_at']=$serverCombatAt;
                $inc['spawn_protected_until_ms']=$serverSpawnProtectedUntil;

                // Only accept equipment changes when they represent a genuine pickup/drop;
                // never let an old heartbeat restore a weapon emptied by combat.
                $incomingWeapon=$inc['weapon']??null;
                $incomingAmmo=(int)($inc['ammo']??0);
                if($serverHp>0 && $serverRespawn<=0){
                    if($serverWeapon===null){
                        $inc['weapon']=$incomingWeapon!==null ? sa_normalize_weapon((string)$incomingWeapon) : null;
                        $inc['ammo']=$inc['weapon']!==null ? max(0,min(sa_weapon_ammo_max($inc['weapon']),$incomingAmmo)) : 0;
                    }else{
                        $sameWeapon=($incomingWeapon!==null && sa_normalize_weapon((string)$incomingWeapon)===$serverWeapon);
                        if($sameWeapon){
                            $inc['weapon']=$serverWeapon;
                            $inc['ammo']=max(0,min(sa_weapon_ammo_max($serverWeapon),min($serverAmmo,$incomingAmmo)));
                        }elseif($incomingWeapon!==null && $incomingWeapon!==$serverWeapon){
                            // Pickup/drop is explicitly reflected in the incoming state.
                            $candidate=sa_normalize_weapon((string)$incomingWeapon);
                            $inc['weapon']=$candidate;
                            $inc['ammo']=max(0,min(sa_weapon_ammo_max($candidate),$incomingAmmo));
                        }else{
                            $inc['weapon']=$serverWeapon;
                            $inc['ammo']=$serverAmmo;
                        }
                    }
                }
            }
            $byId[$id]=$inc;
        }

        $players=array_values($byId);
        $bullets=is_array($in['bullets']??null)?array_slice($in['bullets'],0,120):[];
        $elapsed=max(0,time()-strtotime($m['baslangic']));
        $serverRemain=max(0,min(900,900-$elapsed));
        $mapRound=(int)floor($elapsed/180);
        $storedMap=json_decode($m['map_json']??'{}',true)?:[];
        $baseMap=(string)($storedMap['baslangic_harita']??$m['harita_id']);
        if(!isset(sa_map_catalog()[$baseMap]))$baseMap='col_bolgesi';
        $desiredMap=sa_next_map($baseMap,$mapRound);
        $map=['id'=>$desiredMap,'genislik'=>3200,'yukseklik'=>720,'platformlar'=>sa_map_layout($desiredMap),'baslangic_harita'=>$baseMap,'tur'=>$mapRound,'rakip_turu'=>$m['rakip_turu']??'real'];
        if($desiredMap!==$m['harita_id']){
            $pdo->prepare("UPDATE web_aktif_maclar SET harita_id=?,map_json=? WHERE oda_id=? AND durum='aktif'")->execute([$desiredMap,json_encode($map,JSON_UNESCAPED_UNICODE),$oda]);
            $m['harita_id']=$desiredMap;
        }
        $ctl=$pdo->prepare("SELECT duraklatildi,takim_degisti,degisiklik_tarihi FROM web_mac_kontrol WHERE oda_id=? LIMIT 1");
        $ctl->execute([$oda]);
        $ctlRow=$ctl->fetch()?:['duraklatildi'=>0,'takim_degisti'=>0,'degisiklik_tarihi'=>date('Y-m-d H:i:s')];
        $paused=(bool)$ctlRow['duraklatildi'];
        $swapped=(int)$ctlRow['takim_degisti'];
        $teamSwapPending=false;
        $teamSwapped=false;

        // Keep the stored score authoritative; do NOT rebuild it from the kill-log on every heartbeat.
        $scoreA=(int)$m['skor_a'];
        $scoreB=(int)$m['skor_b'];
        $scoreRev=(int)($m['skor_rev']??0);
        if($swapped===2){
            $teamSwapPending=true;
            $paused=true;
            $swapAt=strtotime($ctlRow['degisiklik_tarihi']??date('Y-m-d H:i:s'));
            if(time()-$swapAt>=5){
                foreach($players as &$p)$p['team']=(($p['team']??'A')==='A'?'B':'A');
                unset($p);
                $tmp=$scoreA;$scoreA=$scoreB;$scoreB=$tmp;
                $teamSwapped=true;$teamSwapPending=false;$paused=false;
                $pdo->prepare("UPDATE web_mac_kontrol SET takim_degisti=1,duraklatildi=0,degisiklik_tarihi=NOW() WHERE oda_id=?")->execute([$oda]);
            }
        }elseif(!$paused&&$serverRemain<=450&&$swapped===0){
            $pdo->prepare("UPDATE web_mac_kontrol SET takim_degisti=2,duraklatildi=1,degisiklik_tarihi=NOW() WHERE oda_id=?")->execute([$oda]);
        }
        $realA=count(array_filter($players,fn($p)=>($p['team']??'A')==='A'&&!empty($p['real'])));$realB=count(array_filter($players,fn($p)=>($p['team']??'A')==='B'&&!empty($p['real'])));
        $stateJson=json_encode(['players'=>$players,'bullets'=>$bullets,'admin_gamemode'=>$adminGamemode],JSON_UNESCAPED_UNICODE);$mapJson=json_encode($map,JSON_UNESCAPED_UNICODE);
        $pdo->prepare("UPDATE web_aktif_maclar SET skor_a=?,skor_b=?,oyuncu_a=?,oyuncu_b=?,son_heartbeat=NOW(),state_json=?,map_json=? WHERE oda_id=? AND durum='aktif'")->execute([$scoreA,$scoreB,$realA,$realB,$stateJson,$mapJson,$oda]);
        sa_json(['ok'=>true,'duraklatildi'=>$paused,'map'=>$map,'team_swap_pending'=>$teamSwapPending,'team_swapped'=>$teamSwapped,'scoreA'=>$scoreA,'scoreB'=>$scoreB,'score_rev'=>$scoreRev,'admin_gamemode'=>!empty($adminGamemode[(string)$u['id']]),'server_remaining'=>$serverRemain,'players'=>$players]);
    }catch(Throwable $e){sa_log_event('HATA_MAC_HEARTBEAT',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Maç senkronizasyon hatası: '.$e->getMessage()],500);}
}


if($action==='web_ates' || $action==='web_bot_ates'){
    try{
        $u=sa_current();
        $in=sa_request_json();
        $oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));
        $targetId=(int)($in['target_id']??0);
        $isBotAction=$action==='web_bot_ates';
        $attackerId=$isBotAction?(int)($in['attacker_id']??0):(int)$u['id'];

        if(!$oda || !is_finite((float)($in['angle']??NAN))){
            sa_json(['ok'=>false,'mesaj'=>'Geçersiz atış.'],422);
        }

        $pdo=sa_db();
        $pdo->beginTransaction();
        $st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");
        $st->execute([$oda]);
        $m=$st->fetch();

        if(!$m){
            $pdo->rollBack();
            sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);
        }

        if($isBotAction && (int)$m['kullanici_id']!==(int)$u['id']){
            $pdo->rollBack();
            sa_json(['ok'=>false,'mesaj'=>'Bot saldırısı yetkili değil.'],403);
        }

        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];
        $adminGamemodeMap=is_array($state['admin_gamemode']??null)?$state['admin_gamemode']:[];
        $ai=null;
        $ti=null;

        foreach(($state['players']??[]) as $i=>$pp){
            if((int)($pp['id']??0)===$attackerId) $ai=$i;
            if($targetId && (int)($pp['id']??0)===$targetId) $ti=$i;
        }

        if($ai===null){
            $pdo->rollBack();
            sa_json(['ok'=>false,'mesaj'=>'Atıcı bulunamadı.'],404);
        }

        $att=&$state['players'][$ai];
        $adminGm=!empty($adminGamemodeMap[(string)$attackerId]) && !$isBotAction && ($attackerId===(int)$u['id'] ? sa_role_is_admin($u['yetki']??'') : !empty($att['admin']));
        $target=$ti!==null ? $state['players'][$ti] : null;
        // Hedef state üzerinde doğrudan değiştirilecek; kopya kullanımı damage'in kaybolmasına neden oluyordu.
        if($ti!==null) $target=&$state['players'][$ti];

        $wid=sa_normalize_weapon((string)($att['weapon']??'pistol'));
        $att['weapon']=$wid;
        $def=sa_weapon_def($wid);

        if(!$def){
            $pdo->rollBack();
            sa_json(['ok'=>false,'mesaj'=>'Silah tanınmıyor.'],409);
        }

        $ammo=(int)($att['ammo']??0);
        if($adminGm)$ammo=max(1,$ammo);
        if($ammo<=0 || ($att['hp']??0)<=0 || ($att['respawn']??0)>0){
            $pdo->rollBack();
            sa_json(['ok'=>false,'mesaj'=>'Atış yapılamadı.'],409);
        }

        $nowMs=(int)round(microtime(true)*1000);
        $gap=max(45,(int)($def['bekleme']??180)-55);

        if((int)($att['combat_at']??0)>0 && $nowMs-(int)$att['combat_at']<$gap){
            $pdo->rollBack();
            sa_json(['ok'=>false,'mesaj'=>'Atış bekleme süresi.'],429);
        }

        $hit=false;
        $killed=false;
        $scoreA=(int)$m['skor_a'];
        $scoreB=(int)$m['skor_b'];
        $scoreRev=(int)($m['skor_rev']??0);
        $xpAward=0;$xpTotal=0;$killerLevel=(int)($u['seviye']??1);$levelUp=false;
        $deathSeq=0;
        $respawnAt=0;

        /*
         * KRİTİK COMBAT FIX 5.13.5
         *
         * Önceki sürüm, istemcinin target_x/target_y değerlerini de
         * vuruşun ön koşulu yapıyordu. Ağ/interpolasyon sırasında bu
         * değerler güncel server state'den farklılaşabiliyor ve mermi
         * karakteri görsel olarak tutturduğu halde sunucu 'menzil dışında'
         * diyerek transaction'ı geri alıyordu.
         *
         * target_id geçerli bir düşmansa hedefi SERVER state'teki gerçek
         * koordinatlarla doğruluyoruz. İstemcinin target_x/target_y'si artık
         * hasarın ön koşulu değil.
         */
        if($target!==null
            && (int)($target['id']??0)!==$attackerId
            && ($target['team']??'A')!==($att['team']??'A')
            && ($target['hp']??0)>0
            && ($target['respawn']??0)<=0){

            $ax=(float)($att['x']??0);
            $ay=(float)($att['y']??0)-42;
            $tx=(float)($target['x']??0);
            $ty=(float)($target['y']??0)-42;
            $dist=hypot($tx-$ax,$ty-$ay);
            $effectiveRange=min(3600.0,max(1800.0,(float)($def['menzil']??1800)+1600.0));

            if($dist<=$effectiveRange){
                $hit=true;
            }
        }

        /*
         * Explicit target yoksa veya geçersizse, atış açısı üzerinden server
         * raycast yap. Böylece hedef ID tarafı bozulsa bile mermiler çalışır.
         */
        if(!$hit){
            $angle=(float)$in['angle'];
            $dirX=cos($angle);
            $dirY=sin($angle);
            $ax=(float)($att['x']??0);
            $ay=(float)($att['y']??0)-48;
            $range=(float)($def['menzil']??1800)+900.0;
            $bestIndex=null;
            $bestAlong=INF;
            /* Botlarda hedef kilidi kullanılmadığı için raycast toleransını özellikle daralt.
             * Böylece botlar hedef yokken ateş etmez ve hedef varken de kusursuz nişancı olmaz. */
            $hitRadius=$isBotAction?92.0:155.0;

            foreach(($state['players']??[]) as $i=>$q){
                if($i===$ai) continue;
                if(($q['team']??'A')===($att['team']??'A')) continue;
                if(($q['hp']??0)<=0 || ($q['respawn']??0)>0) continue;

                $qx=(float)($q['x']??0);
                $qy=(float)($q['y']??0)-42;
                $vx=$qx-$ax;
                $vy=$qy-$ay;
                $along=$vx*$dirX+$vy*$dirY;

                if($along<0 || $along>$range) continue;

                $perp=abs($vx*$dirY-$vy*$dirX);
                if($perp<=$hitRadius && $along<$bestAlong){
                    $bestAlong=$along;
                    $bestIndex=$i;
                }
            }

            if($bestIndex!==null){
                $ti=$bestIndex;
                $target=&$state['players'][$ti];
                $hit=true;
            }
        }

        /* Mermi yalnızca server tarafından onaylanan atışta tüketilir. */
        if(!$adminGm)$att['ammo']=max(0,$ammo-1); else $att['ammo']=999999;
        $att['combat_at']=$nowMs;
        if($att['ammo']===0&&!$adminGm){
            $att['weapon']=null;
        }

        $protectedTarget=false;
        if($hit && $target!==null){
            $damage=max(1,(int)($def['hasar']??30));
            $targetGm=!empty($adminGamemodeMap[(string)((int)$target['id'])]) && !empty($target['admin']);
            $protectedTarget=((int)($target['spawn_protected_until_ms']??0)>$nowMs);
            if(!$targetGm && !$protectedTarget)$target['hp']=max(0,(int)($target['hp']??100)-$damage);

            if(!$protectedTarget && $target['hp']<=0){
                $killed=true;
                $target['deaths']=(int)($target['deaths']??0)+1;
                $deathSeq=(int)($target['death_seq']??0)+1;
                $respawnAt=time()+10;

                $target['death_seq']=$deathSeq;
                $target['respawn_at']=$respawnAt;
                $target['respawn']=10;
                $target['spawn_protected_until_ms']=$nowMs+13000;
                $target['weapon']=null;
                $target['ammo']=0;

                $att['kills']=(int)($att['kills']??0)+1;

                if(($att['team']??'A')==='B') $scoreB++; else $scoreA++;

                if(!empty($target['real'])){
                    sa_increment_user_death($pdo,(int)$target['id']);
                }

                sa_record_kill(
                    $pdo,
                    $oda,
                    $attackerId,
                    (int)$target['id'],
                    (($att['team']??'A')==='B'?'B':'A'),
                    $wid,
                    $deathSeq,
                    !$isBotAction
                );

                if(!$isBotAction){
                    $xpInfo=sa_award_kill_xp($pdo,$attackerId,100);
                    $xpAward=(int)($xpInfo['gained']??0);
                    $xpTotal=(int)($xpInfo['xp']??0);
                    $killerLevel=(int)($xpInfo['level']??1);
                    $levelUp=!empty($xpInfo['leveled_up']);
                }

                [$scoreA,$scoreB,$scoreRev]=sa_rebuild_match_score($pdo,$oda);
            }
        }

        $stateJson=json_encode(
            ['players'=>array_values($state['players']??[]),'bullets'=>$state['bullets']??[],'admin_gamemode'=>$adminGamemodeMap],
            JSON_UNESCAPED_UNICODE
        );

        if(sa_column_exists($pdo,'web_aktif_maclar','skor_rev')){
            $pdo->prepare(
                "UPDATE web_aktif_maclar SET skor_a=?,skor_b=?,skor_rev=?,state_json=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'"
            )->execute([
                $scoreA,
                $scoreB,
                (int)$scoreRev,
                $stateJson,
                $oda
            ]);
        }else{
            $pdo->prepare(
                "UPDATE web_aktif_maclar SET skor_a=?,skor_b=?,state_json=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'"
            )->execute([
                $scoreA,
                $scoreB,
                $stateJson,
                $oda
            ]);
        }

        $pdo->commit();
        unset($att,$target);

        sa_json([
            'ok'=>true,
            'hit'=>$hit,
            'killed'=>$killed,
            'target_id'=>$hit && $target ? (int)$target['id'] : 0,
            'hp'=>$hit && $target ? (int)$target['hp'] : 0,
            'damage'=>$hit && $target ? $damage : 0,
            'respawn'=>$hit && $target ? (float)($target['respawn']??0) : 0,
            'deaths'=>$hit && $target ? (int)($target['deaths']??0) : 0,
            'killer_id'=>$attackerId,
            'killer_kills'=>(int)$att['kills'],
            'weapon'=>$att['weapon']??null,
            'ammo'=>(int)$att['ammo'],
            'death_seq'=>$deathSeq,
            'respawn_at'=>$respawnAt,
            'spawn_protected_until_ms'=>(int)($target['spawn_protected_until_ms']??0),
            'protected'=>(bool)$protectedTarget,
            'scoreA'=>$scoreA,
            'scoreB'=>$scoreB,
            'score_rev'=>(int)$scoreRev,
            'xp_gained'=>$xpAward,
            'xp_total'=>$xpTotal,
            'level'=>$killerLevel,
            'level_up'=>$levelUp
        ]);

    }catch(Throwable $e){
        try{
            if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction()){
                $pdo->rollBack();
            }
        }catch(Throwable $ignore){}

        sa_log_event(
            'HATA_AUTH_ATISI',
            $e->getMessage(),
            isset($u['id'])?(int)$u['id']:null
        );

        sa_json([
            'ok'=>false,
            'mesaj'=>'Atış sunucuda işlenemedi.',
            'kod'=>'COMBAT_SERVER_ERROR'
        ],500);
    }
}

if($action==='web_saldiri'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$targetId=(int)($in['target_id']??0);if(!$oda||!$targetId||$targetId===(int)$u['id'])sa_json(['ok'=>false,'mesaj'=>'Geçersiz saldırı.'],422);
        $pdo=sa_db();$pdo->beginTransaction();$st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();if(!$m){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);}
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];$adminGamemodeMap=is_array($state['admin_gamemode']??null)?$state['admin_gamemode']:[];$att=null;$target=null;foreach(($state['players']??[]) as &$pp){if((int)($pp['id']??0)===(int)$u['id'])$att=&$pp;if((int)($pp['id']??0)===$targetId)$target=&$pp;}unset($pp);if(!$att||!$target){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Oyuncu durumu bulunamadı.'],404);}
        $attAdminGm=!empty($adminGamemodeMap[(string)$u['id']]) && sa_role_is_admin($u['yetki']??'');
        $wid=sa_normalize_weapon((string)($att['weapon']??'pistol'));$catalogDef=sa_weapon_def($wid);$weapons=$catalogDef?[$wid=>['damage'=>(int)($catalogDef['hasar']??30),'gap'=>max(55,(int)($catalogDef['bekleme']??180)-35),'range'=>(int)($catalogDef['menzil']??1600)]]:[];if(!isset($weapons[$wid])||(int)($att['ammo']??0)<=0){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Silah veya mühimmat bulunmuyor.'],409);} $w=$weapons[$wid];$nowMs=(int)round(microtime(true)*1000);if((int)($att['combat_at']??0)>0&&$nowMs-(int)$att['combat_at']<$w['gap']){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Silah atış bekleme süresi.'],429);}
        if(($att['team']??'A')===($target['team']??'A')){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Takım arkadaşına saldıramazsın.'],422);}if(($att['hp']??0)<=0||($att['respawn']??0)>0||($target['hp']??0)<=0||($target['respawn']??0)>0){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Oyunculardan biri elenmiş durumda.'],409);}
        // Ağ gecikmesi ve oyuncu interpolasyonu nedeniyle sunucudaki konum, merminin yerel çarpışma anındaki konumundan kısa süreli olarak farklı olabilir.
        // Bu nedenle istemcinin bildirdiği hedef konumu yalnızca sunucu konumuna makul bir tolerans içindeyse kullanılır; atış yönü artık zorunlu bir engel değildir.
        $serverAx=(float)($att['x']??0);$serverAy=(float)($att['y']??0);$serverTx=(float)($target['x']??0);$serverTy=(float)($target['y']??0);
        $reportedAx=is_numeric($in['attacker_x']??null)?(float)$in['attacker_x']:$serverAx;$reportedAy=is_numeric($in['attacker_y']??null)?(float)$in['attacker_y']:$serverAy;
        $reportedTx=is_numeric($in['target_x']??null)?(float)$in['target_x']:$serverTx;$reportedTy=is_numeric($in['target_y']??null)?(float)$in['target_y']:$serverTy;
        if(abs($reportedAx-$serverAx)>320||abs($reportedAy-$serverAy)>260){$reportedAx=$serverAx;$reportedAy=$serverAy;}
        if(abs($reportedTx-$serverTx)>420||abs($reportedTy-$serverTy)>300){$reportedTx=$serverTx;$reportedTy=$serverTy;}
        $dx=$reportedTx-$reportedAx;$dy=($reportedTy-18)-($reportedAy-18);$dist=hypot($dx,$dy);
        $effectiveRange=min(3600.0,(float)$w['range']+1700.0);$verticalTolerance=520.0;
        if($dist>$effectiveRange||abs($dy)>$verticalTolerance){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Hedef menzil dışında.'],409);}
        $protectedTarget=((int)($target['spawn_protected_until_ms']??0)>$nowMs);
        $targetGm=!empty($adminGamemodeMap[(string)((int)$target['id'])]) && !empty($target['admin']);
        if($attAdminGm)$att['ammo']=999999;else $att['ammo']=max(0,(int)$att['ammo']-1);if(!$protectedTarget&&!$targetGm)$target['hp']=max(0,(int)$target['hp']-(int)$w['damage']);$att['combat_at']=$nowMs;$killed=false;$xpAward=0;$xpTotal=0;$killerLevel=(int)($u['seviye']??1);$levelUp=false;$xpAward=0;$xpTotal=0;$killerLevel=(int)($u['seviye']??1);$levelUp=false;$deathSeq=(int)($target['death_seq']??0);$respawnAt=(int)($target['respawn_at']??0);$scoreA=(int)$m['skor_a'];$scoreB=(int)$m['skor_b'];
        if($att['ammo']===0&&!$attAdminGm)$att['weapon']=null;
        if(!$protectedTarget&&!$targetGm&&$target['hp']<=0){
            $killed=true;
            $target['deaths']=(int)($target['deaths']??0)+1;
            $deathSeq++;
            $respawnAt=time()+10;
            $target['death_seq']=$deathSeq;
            $target['respawn_at']=$respawnAt;
            $target['respawn']=10;
            $target['spawn_protected_until_ms']=$nowMs+13000;
            $target['weapon']=null;
            $target['ammo']=0;
            $att['kills']=(int)($att['kills']??0)+1;
            if(($att['team']??'A')==='B')$scoreB++;else$scoreA++;
            if(!empty($target['real']))sa_increment_user_death($pdo,(int)$target['id']);
            sa_record_kill($pdo,$oda,$u['id'],(int)$target['id'],(($att['team']??'A')==='B'?'B':'A'),$wid,$deathSeq,true);
            $xpInfo=sa_award_kill_xp($pdo,(int)$u['id'],100);
            $xpAward=(int)($xpInfo['gained']??0);$xpTotal=(int)($xpInfo['xp']??0);$killerLevel=(int)($xpInfo['level']??1);$levelUp=!empty($xpInfo['leveled_up']);
            [$scoreA,$scoreB,$scoreRev]=sa_rebuild_match_score($pdo,$oda);
            sa_log_event('OYUN_KILL','oda='.$oda.' hedef='.$targetId.' silah='.$wid,(int)$u['id']);
        }
        if($killed){ $scoreRev++; }
        $pdo->prepare("UPDATE web_aktif_maclar SET skor_a=?,skor_b,state_json=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'")->execute([$scoreA,$scoreB,json_encode($state,JSON_UNESCAPED_UNICODE),$oda]);
        try { $pdo->prepare("UPDATE web_aktif_maclar SET skor_rev=? WHERE oda_id=? AND durum='aktif'")->execute([$scoreRev,$oda]); } catch(Throwable $ignore) {}
        $pdo->commit();sa_json(['ok'=>true,'target_id'=>$targetId,'hp'=>(int)$target['hp'],'respawn'=>(float)($target['respawn']??0),'deaths'=>(int)($target['deaths']??0),'killer_id'=>(int)$u['id'],'killer_kills'=>(int)$att['kills'],'weapon'=>$att['weapon']??null,'ammo'=>(int)($att['ammo']??0),'death_seq'=>$deathSeq,'respawn_at'=>$respawnAt,'spawn_protected_until_ms'=>(int)($target['spawn_protected_until_ms']??0),'protected'=>(bool)$protectedTarget,'killed'=>$killed,'scoreA'=>$scoreA,'scoreB'=>$scoreB,'score_rev'=>$scoreRev,'xp_gained'=>$xpAward,'xp_total'=>$xpTotal,'level'=>$killerLevel,'level_up'=>$levelUp]);
    }catch(Throwable $e){try{if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();}catch(Throwable $ignore){}sa_log_event('HATA_MAC_SALDIRI',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Saldırı senkronizasyon hatası: '.$e->getMessage()],500);}
}

if($action==='web_bot_saldiri'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$attackerId=(int)($in['attacker_id']??0);$targetId=(int)($in['target_id']??0);if(!$oda||$attackerId<900000||!$targetId)sa_json(['ok'=>false,'mesaj'=>'Geçersiz bot saldırısı.'],422);
        $pdo=sa_db();$pdo->beginTransaction();$st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();if(!$m||($m['rakip_turu']??'real')!=='bot'||(int)$m['kullanici_id']!==(int)$u['id']){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bot saldırısı için yetkili maç bulunamadı.'],403);}
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];$adminGamemodeMap=is_array($state['admin_gamemode']??null)?$state['admin_gamemode']:[];$att=null;$target=null;foreach(($state['players']??[]) as &$pp){if((int)($pp['id']??0)===$attackerId)$att=&$pp;if((int)($pp['id']??0)===$targetId)$target=&$pp;}unset($pp);if(!$att||!$target||empty($att['bot'])){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bot/oyuncu durumu bulunamadı.'],404);}
        $adminGm=!empty($adminGamemodeMap[(string)$attackerId]) && !empty($att['admin']);
        $wid=sa_normalize_weapon((string)($att['weapon']??'pistol'));$catalogDef=sa_weapon_def($wid);$weapons=$catalogDef?[$wid=>['damage'=>(int)($catalogDef['hasar']??30),'gap'=>max(55,(int)($catalogDef['bekleme']??180)-35),'range'=>(int)($catalogDef['menzil']??1600)]]:[];if(!isset($weapons[$wid])||(int)($att['ammo']??0)<=0){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Botun mühimmatı yok.'],409);} $w=$weapons[$wid];$nowMs=(int)round(microtime(true)*1000);if((int)($att['combat_at']??0)>0&&$nowMs-(int)$att['combat_at']<$w['gap']){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bot atış bekleme süresi.'],429);}
        if(($att['team']??'A')===($target['team']??'A')||($att['hp']??0)<=0||($att['respawn']??0)>0||($target['hp']??0)<=0||($target['respawn']??0)>0){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Geçersiz bot hedefi.'],409);}
        $serverAx=(float)($att['x']??0);$serverAy=(float)($att['y']??0);$serverTx=(float)($target['x']??0);$serverTy=(float)($target['y']??0);
        $reportedAx=is_numeric($in['attacker_x']??null)?(float)$in['attacker_x']:$serverAx;$reportedAy=is_numeric($in['attacker_y']??null)?(float)$in['attacker_y']:$serverAy;
        $reportedTx=is_numeric($in['target_x']??null)?(float)$in['target_x']:$serverTx;$reportedTy=is_numeric($in['target_y']??null)?(float)$in['target_y']:$serverTy;
        if(abs($reportedAx-$serverAx)>320||abs($reportedAy-$serverAy)>260){$reportedAx=$serverAx;$reportedAy=$serverAy;}
        if(abs($reportedTx-$serverTx)>420||abs($reportedTy-$serverTy)>300){$reportedTx=$serverTx;$reportedTy=$serverTy;}
        $dx=$reportedTx-$reportedAx;$dy=($reportedTy-18)-($reportedAy-18);$dist=hypot($dx,$dy);$effectiveRange=min(3600.0,(float)$w['range']+1700.0);$verticalTolerance=520.0;
        if($dist>$effectiveRange||abs($dy)>$verticalTolerance){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bot hedefi menzil dışında.'],409);}
        $protectedTarget=((int)($target['spawn_protected_until_ms']??0)>$nowMs);
        if(!$adminGm)$att['ammo']=max(0,(int)$att['ammo']-1); else $att['ammo']=999999;if(!$protectedTarget && (empty($adminGamemodeMap[(string)((int)$target['id'])])||empty($target['admin'])))$target['hp']=max(0,(int)$target['hp']-(int)$w['damage']);$att['combat_at']=$nowMs;if($att['ammo']===0)$att['weapon']=null;$killed=false;$deathSeq=(int)($target['death_seq']??0);$respawnAt=(int)($target['respawn_at']??0);$scoreA=(int)$m['skor_a'];$scoreB=(int)$m['skor_b'];
        if($target['hp']<=0){
            $killed=true;
            $target['deaths']=(int)($target['deaths']??0)+1;
            $deathSeq++;
            $respawnAt=time()+10;
            $target['death_seq']=$deathSeq;
            $target['respawn_at']=$respawnAt;
            $target['respawn']=10;
            $target['weapon']=null;
            $target['ammo']=0;
            $att['kills']=(int)($att['kills']??0)+1;
            if(($att['team']??'A')==='B')$scoreB++;else$scoreA++;
            if(!empty($target['real']))sa_increment_user_death($pdo,(int)$target['id']);
            sa_record_kill($pdo,$oda,$attackerId,(int)$target['id'],(($att['team']??'A')==='B'?'B':'A'),$wid,$deathSeq,false);
            [$scoreA,$scoreB,$scoreRev]=sa_rebuild_match_score($pdo,$oda);
            sa_log_event('OYUN_KILL','oda='.$oda.' hedef='.$targetId.' silah='.$wid,$attackerId);
        }
        if($killed){ $scoreRev++; }
        $pdo->prepare("UPDATE web_aktif_maclar SET skor_a=?,skor_b,state_json=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'")->execute([$scoreA,$scoreB,json_encode($state,JSON_UNESCAPED_UNICODE),$oda]);
        try { $pdo->prepare("UPDATE web_aktif_maclar SET skor_rev=? WHERE oda_id=? AND durum='aktif'")->execute([$scoreRev,$oda]); } catch(Throwable $ignore) {}
        $pdo->commit();sa_json(['ok'=>true,'target_id'=>$targetId,'killer_id'=>$attackerId,'killer_kills'=>(int)$att['kills'],'hp'=>(int)$target['hp'],'respawn'=>(float)($target['respawn']??0),'deaths'=>(int)($target['deaths']??0),'weapon'=>$att['weapon']??null,'ammo'=>(int)($att['ammo']??0),'death_seq'=>$deathSeq,'respawn_at'=>$respawnAt,'spawn_protected_until_ms'=>(int)($target['spawn_protected_until_ms']??0),'protected'=>(bool)$protectedTarget,'killed'=>$killed,'scoreA'=>$scoreA,'scoreB'=>$scoreB,'score_rev'=>$scoreRev]);
    }catch(Throwable $e){try{if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();}catch(Throwable $ignore){}sa_log_event('HATA_BOT_SALDIRI',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Bot saldırısı senkronizasyon hatası.'],500);}
}




if($action==='web_mac_killfeed'){
    try{
        $u=sa_current();
        $in=sa_request_json();
        $oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??($_GET['oda']??'')));
        if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();
        $st=$pdo->prepare("SELECT state_json FROM web_aktif_maclar WHERE oda_id=? LIMIT 1");
        $st->execute([$oda]);$m=$st->fetch();
        if(!$m)sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[]];
        $member=false;
        foreach(($state['players']??[]) as $pp){if((int)($pp['id']??0)===(int)$u['id']){$member=true;break;}}
        if(!$member && !sa_role_is_admin($u['yetki']??''))sa_json(['ok'=>false,'mesaj'=>'Bu maçın olay akışına erişemezsiniz.'],403);
        $rows=[];
        try{
            $q=$pdo->prepare("SELECT id,killer_id,target_id,killer_team,weapon,death_seq,tarih FROM web_mac_kill_log WHERE oda_id=? ORDER BY id DESC LIMIT 8");
            $q->execute([$oda]);
            $rows=$q->fetchAll()?:[];
        }catch(Throwable $ignore){$rows=[];}
        $players=[];
        foreach(($state['players']??[]) as $pp){
            $players[(string)(int)($pp['id']??0)]=['name'=>(string)($pp['name']??'Oyuncu'),'team'=>(($pp['team']??'A')==='B'?'B':'A'),'bot'=>(bool)($pp['bot']??false)];
        }
        $out=[];
        foreach($rows as $r){
            $kid=(string)(int)$r['killer_id'];$tid=(string)(int)$r['target_id'];
            $out[]=[
                'id'=>(int)$r['id'],
                'killer_id'=>(int)$r['killer_id'],
                'target_id'=>(int)$r['target_id'],
                'killer_name'=>$players[$kid]['name']??'Oyuncu #'.(int)$r['killer_id'],
                'target_name'=>$players[$tid]['name']??'Oyuncu #'.(int)$r['target_id'],
                'killer_team'=>(($r['killer_team']??'A')==='B'?'B':'A'),
                'weapon'=>(string)($r['weapon']??'tabanca'),
                'death_seq'=>(int)($r['death_seq']??0),
                'tarih'=>(string)($r['tarih']??'')
            ];
        }
        sa_json(['ok'=>true,'oda'=>$oda,'olaylar'=>$out,'son_id'=>(int)($rows[0]['id']??0)]);
    }catch(Throwable $e){
        sa_log_event('HATA_KILLFEED',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);
        sa_json(['ok'=>false,'mesaj'=>'Öldürme akışı alınamadı.'],500);
    }
}

if($action==='web_mac_scoreboard'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??($_GET['oda']??'')));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();$st=$pdo->prepare("SELECT oda_id,harita_id,mod,rakip_turu,skor_a,skor_b,son_heartbeat,state_json FROM web_aktif_maclar WHERE oda_id=? LIMIT 1");$st->execute([$oda]);$m=$st->fetch();if(!$m)sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[]];$players=$state['players']??[];
        $member=false;foreach($players as $p){if((int)($p['id']??0)===(int)$u['id']){$member=true;break;}}if(!$member && !sa_role_is_admin($u['yetki']??''))sa_json(['ok'=>false,'mesaj'=>'Bu maçın skor tablosuna erişemezsiniz.'],403);
        $kills=[];
        $deaths=[];
        try {
            $kq=$pdo->prepare("SELECT killer_id,COUNT(*) sayi FROM web_mac_kill_log WHERE oda_id=? GROUP BY killer_id");
            $kq->execute([$oda]);
            foreach($kq->fetchAll() as $r)$kills[(string)$r['killer_id']]=(int)$r['sayi'];
            $dq=$pdo->prepare("SELECT target_id,COUNT(*) sayi FROM web_mac_kill_log WHERE oda_id=? GROUP BY target_id");
            $dq->execute([$oda]);
            foreach($dq->fetchAll() as $r)$deaths[(string)$r['target_id']]=(int)$r['sayi'];
        } catch(Throwable $ignore) {}
        // Match score is stored in web_aktif_maclar and is authoritative.
        $rows=[];foreach($players as $p){$pid=(int)($p['id']??0);$stateKills=max(0,(int)($p['kills']??0));$stateDeaths=max(0,(int)($p['deaths']??0));$logKills=max(0,(int)($kills[(string)$pid]??0));$logDeaths=max(0,(int)($deaths[(string)$pid]??0));$rows[]=['id'=>$pid,'name'=>(string)($p['name']??'Oyuncu'),'team'=>(($p['team']??'A')==='B'?'B':'A'),'kills'=>max($stateKills,$logKills),'deaths'=>max($stateDeaths,$logDeaths),'real'=>(bool)($p['real']??false),'bot'=>(bool)($p['bot']??false),'alive'=>(int)($p['hp']??0)>0,'character'=>sa_normalize_character((string)($p['character']??''),(($p['team']??'A')==='B'?'B':'A'))];}
        usort($rows,function($a,$b){if($a['team']!==$b['team'])return $a['team']==='A'?-1:1; if($a['kills']!==$b['kills'])return $b['kills']<=>$a['kills']; return strcasecmp($a['name'],$b['name']);});
        sa_json(['ok'=>true,'oda'=>$oda,'scoreA'=>(int)$m['skor_a'],'scoreB'=>(int)$m['skor_b'],'score_rev'=>(int)($m['score_rev']??0),'oyuncular'=>$rows,'server_time'=>date('Y-m-d H:i:s')]);
    }catch(Throwable $e){sa_log_event('HATA_SCOREBOARD',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Skor tablosu alınamadı.'],500);}
}

function sa_apply_environment_death(PDO $pdo, array $m, string $oda, int $targetId): array {
    $state=json_decode($m['state_json']??'{}',true)?:['players'=>[]];
    $changed=false;$target=null;
    foreach($state['players']??[] as &$p){
        if((int)($p['id']??0)===$targetId){$target=&$p;break;}
    }
    unset($p);
    $nowMs=(int)round(microtime(true)*1000);
    if(!$target || (int)($target['hp']??0)<=0){
        [$sa,$sb,$rev]=sa_rebuild_match_score($pdo,$oda);
        return ['changed'=>false,'state'=>$state,'scoreA'=>$sa,'scoreB'=>$sb,'score_rev'=>$rev,'target'=>$target];
    }
    if((int)($target['spawn_protected_until_ms']??0)>$nowMs){
        [$sa,$sb,$rev]=sa_rebuild_match_score($pdo,$oda);
        return ['changed'=>false,'protected'=>true,'state'=>$state,'scoreA'=>$sa,'scoreB'=>$sb,'score_rev'=>$rev,'target'=>$target];
    }
    $targetTeam=(($target['team']??'A')==='B'?'B':'A');
    $pointTeam=$targetTeam==='A'?'B':'A';
    $target['hp']=0;
    $target['deaths']=(int)($target['deaths']??0)+1;
    $target['death_seq']=(int)($target['death_seq']??0)+1;
    $target['respawn_at']=time()+10;$target['respawn']=10;$target['spawn_protected_until_ms']=$nowMs+13000;$target['weapon']=null;$target['ammo']=0;
    // Killer id 0 represents environmental death; the opposing team receives the requested point without a player kill stat.
    sa_record_kill($pdo,$oda,0,$targetId,$pointTeam,'environment',$target['death_seq'],false);
    if(!empty($target['real'])){try{$pdo->prepare("UPDATE kullanicilar SET olum=olum+1 WHERE id=?")->execute([$targetId]);}catch(Throwable $ignore){}}
    [$scoreA,$scoreB,$scoreRev]=sa_rebuild_match_score($pdo,$oda);
    $pdo->prepare("UPDATE web_aktif_maclar SET skor_a=?,skor_b,state_json=?,skor_rev=?,son_heartbeat=NOW() WHERE oda_id=? AND durum='aktif'")->execute([$scoreA,$scoreB,$scoreRev,json_encode($state,JSON_UNESCAPED_UNICODE),$oda]);
    sa_log_event('OYUN_CEVRESEL_OLUM','oda='.$oda.' hedef='.$targetId.' puan_takimi='.$pointTeam,$targetId>0?$targetId:null);
    return ['changed'=>true,'state'=>$state,'scoreA'=>$scoreA,'scoreB'=>$scoreB,'score_rev'=>$scoreRev,'target'=>$target];
}

if($action==='web_player_death'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();$pdo->beginTransaction();
        $st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();
        if(!$m){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);}
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[]];$member=false;
        foreach($state['players']??[] as $pp){if((int)($pp['id']??0)===(int)$u['id']){$member=true;break;}}
        if(!$member){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bu maçta oyuncu değilsiniz.'],403);}
        $r=sa_apply_environment_death($pdo,$m,$oda,(int)$u['id']);
        if($r['changed']){$pdo->commit();$t=$r['target'];sa_json(['ok'=>true,'changed'=>true,'cause'=>'environment','target_id'=>(int)$u['id'],'hp'=>0,'deaths'=>(int)($t['deaths']??0),'death_seq'=>(int)($t['death_seq']??0),'respawn'=>10,'respawn_at'=>(int)($t['respawn_at']??time()+10),'spawn_protected_until_ms'=>(int)($t['spawn_protected_until_ms']??0),'protected'=>(bool)($r['protected']??false),'scoreA'=>(int)$r['scoreA'],'scoreB'=>(int)$r['scoreB'],'score_rev'=>(int)$r['score_rev']]);}
        $pdo->commit();sa_json(['ok'=>true,'changed'=>false,'scoreA'=>(int)$r['scoreA'],'scoreB'=>(int)$r['scoreB'],'score_rev'=>(int)$r['score_rev']]);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_log_event('HATA_OYUNCU_OLUM',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Ölüm senkronizasyonu başarısız.'],500);}
}

if($action==='web_bot_death'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$targetId=(int)($in['target_id']??0);if(!$oda||$targetId<900000)sa_json(['ok'=>false,'mesaj'=>'Geçersiz bot ölümü.'],422);
        $pdo=sa_db();$pdo->beginTransaction();$st=$pdo->prepare("SELECT * FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1 FOR UPDATE");$st->execute([$oda]);$m=$st->fetch();
        if(!$m||($m['rakip_turu']??'real')!=='bot'||(int)$m['kullanici_id']!==(int)$u['id']){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bot ölümü için yetkili maç bulunamadı.'],403);}
        $state=json_decode($m['state_json']??'{}',true)?:['players'=>[]];$bot=null;foreach($state['players']??[] as $pp){if((int)($pp['id']??0)===$targetId && !empty($pp['bot'])){$bot=$pp;break;}}
        if(!$bot){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bot bulunamadı.'],404);}
        $r=sa_apply_environment_death($pdo,$m,$oda,$targetId);$pdo->commit();$t=$r['target']?:$bot;sa_json(['ok'=>true,'changed'=>(bool)$r['changed'],'cause'=>'environment','target_id'=>$targetId,'hp'=>0,'deaths'=>(int)($t['deaths']??0),'death_seq'=>(int)($t['death_seq']??0),'respawn'=>10,'respawn_at'=>(int)($t['respawn_at']??time()+10),'spawn_protected_until_ms'=>(int)($t['spawn_protected_until_ms']??0),'protected'=>(bool)($r['protected']??false),'scoreA'=>(int)$r['scoreA'],'scoreB'=>(int)$r['scoreB'],'score_rev'=>(int)$r['score_rev']]);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_log_event('HATA_BOT_OLUM',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Bot ölümü senkronizasyonu başarısız.'],500);}
}

if($action==='web_mac_durum'){
    $u=sa_current();
    $body=json_decode(file_get_contents('php://input'),true)??[];$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['oda']??($body['oda']??'')));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);
    $st=sa_db()->prepare("SELECT w.oda_id AS id,w.`mod`,w.harita_id,w.skor_a,w.skor_b,w.bitis,w.son_heartbeat,w.state_json,w.map_json,COALESCE(c.duraklatildi,0) duraklatildi,COALESCE(c.takim_degisti,0) takim_degisti FROM web_aktif_maclar w LEFT JOIN web_mac_kontrol c ON c.oda_id=w.oda_id WHERE w.oda_id=? AND w.durum='aktif' LIMIT 1");$st->execute([$oda]);$m=$st->fetch();if(!$m)sa_json(['ok'=>false,'mesaj'=>'Bu maç artık aktif değil.'],404);
    $state=json_decode($m['state_json']??'{}',true)?:['players'=>[],'bullets'=>[]];$map=json_decode($m['map_json']??'{}',true)?:['id'=>$m['harita_id'],'genislik'=>3200,'yukseklik'=>720,'platformlar'=>sa_map_layout($m['harita_id'])];$kalan=max(0,strtotime($m['bitis'])-time());$chatSt=sa_db()->prepare("SELECT c.id,c.kullanici_id,c.mesaj,c.tarih,COALESCE(u.kullanici_adi,CONCAT('Oyuncu #',c.kullanici_id)) AS kullanici_adi,COALESCE(u.yetki,'user') AS yetki,COALESCE(u.dogrulanmis,0) AS dogrulanmis,k.ad AS klan_ad FROM web_mac_sohbet c LEFT JOIN kullanicilar u ON u.id=c.kullanici_id LEFT JOIN klan_uyeleri ku ON ku.kullanici_id=c.kullanici_id LEFT JOIN klanlar k ON k.id=ku.klan_id WHERE c.oda_id=? ORDER BY c.id DESC LIMIT 40");$chatSt->execute([$oda]);$chat=array_reverse($chatSt->fetchAll());
    sa_json(['ok'=>true,'mac'=>['id'=>$m['id'],'admin_gamemode'=>!empty(($state['admin_gamemode']??[])[(string)$u['id']]),'mod'=>$m['mod'],'harita'=>$m['harita_id'],'skor'=>['A'=>(int)$m['skor_a'],'B'=>(int)$m['skor_b']],'oyuncular'=>count($state['players']??[]),'kalan'=>$kalan,'duraklatildi'=>(bool)$m['duraklatildi'],'takim_degisti'=>(int)$m['takim_degisti'],'team_swap_pending'=>(int)$m['takim_degisti']===2,'state'=>$state,'map'=>$map,'chat'=>$chat]]);
}
if($action==='web_mac_bitir'){
    try{
        $u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pdo=sa_db();$pdo->beginTransaction();
        $q=$pdo->prepare("SELECT kullanici_id FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1");$q->execute([$oda]);$host=$q->fetchColumn();
        if(!$host){$pdo->rollBack();sa_json(['ok'=>true,'already'=>true]);}
        if((int)$host!==(int)$u['id'] && !sa_role_is_admin($u['yetki']??'')){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Bu maçı kapatma yetkiniz yok.'],403);}
        $result=sa_finalize_match($pdo,$oda);$pdo->commit();sa_json($result);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_log_event('HATA_MAC_BITIR',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Maç sonuçları işlenemedi: '.$e->getMessage()],500);}
}

if($action==='admin_mac_duraklat' || $action==='admin_mac_devam'){
    try{
        $a=sa_require_admin();
        $raw=file_get_contents('php://input');
        $in=json_decode($raw,true);
        if(!is_array($in))$in=[];
        $oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));
        if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç kimliği gerekli.'],422);
        $pause=$action==='admin_mac_duraklat';$pdo=sa_db();
        $st=$pdo->prepare("SELECT id FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1");$st->execute([$oda]);
        if(!$st->fetch())sa_json(['ok'=>false,'mesaj'=>'Aktif maç bulunamadı.'],404);
        $pdo->prepare("INSERT INTO web_mac_kontrol(oda_id,duraklatildi,admin_id,degisiklik_tarihi) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE duraklatildi=VALUES(duraklatildi),admin_id=VALUES(admin_id),degisiklik_tarihi=NOW()")->execute([$oda,$pause?1:0,(int)$a['id']]);
        sa_log_event($pause?'OYUN_DURAKLAT':'OYUN_DEVAM','oda='.$oda,(int)$a['id']);
        sa_json(['ok'=>true,'duraklatildi'=>$pause,'oda'=>$oda,'mesaj'=>$pause?'Maç duraklatıldı.':'Maç devam ettirildi.']);
    }catch(Throwable $e){
        sa_log_event('HATA_ADMIN_MAC_KONTROL',$e->getMessage(),isset($a['id'])?(int)$a['id']:null);
        sa_json(['ok'=>false,'mesaj'=>'Maç kontrolü sırasında sunucu hatası: '.$e->getMessage()],500);
    }
}




if($action==='sistem_saglik'){
    try{
        $u=sa_current();$pdo=sa_db();$tables=['destek_talepleri','destek_mesajlari','oyuncu_kill_log','web_mac_kill_log','web_aktif_maclar','oyun_kurallari'];$ok=[];$missing=[];foreach($tables as $t){$q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");$q->execute([$t]);if((int)$q->fetchColumn()>0)$ok[]=$t;else$missing[]=$t;}sa_json(['ok'=>true,'hazir'=>!$missing,'tablolar'=>$ok,'eksik'=>$missing,'zaman'=>date('Y-m-d H:i:s')]);
    }catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Sistem sağlık kontrolü başarısız: '.$e->getMessage()],500);}
}
if($action==='admin_sistem_saglik'){
    $a=sa_require_admin();
    try{$pdo=sa_db();$tables=['destek_talepleri','destek_mesajlari','oyuncu_kill_log','web_mac_kill_log','web_mac_sonuclari','web_voice_signals','oyun_kurallari','web_aktif_maclar','web_lobiler'];$res=[];foreach($tables as $t){$q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");$q->execute([$t]);$res[$t]=(int)$q->fetchColumn()>0;}sa_json(['ok'=>true,'tables'=>$res,'ready'=>!in_array(false,$res,true),'php'=>PHP_VERSION,'time'=>date('Y-m-d H:i:s')]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Sistem sağlık kontrolü alınamadı: '.$e->getMessage()],500);}
}
/* ============================ 5.4 DESTEK MERKEZİ ============================ */
function sa_support_categories(): array { return ['Genel','Hesap','Maç','Ödeme','Teknik','Klan','Güvenlik']; }
function sa_support_status_label(string $s): string { return ['acik'=>'Açık','beklemede'=>'Yanıt bekleniyor','cozuldu'=>'Çözüldü'][$s]??$s; }

if($action==='destek_ozet'){
    try{
        $u=sa_current();
        $st=sa_db()->prepare("SELECT t.id,t.konu,t.kategori,t.oncelik,t.durum,t.son_mesaj_tarihi,t.guncellenme,\n            (SELECT LEFT(m.mesaj,180) FROM destek_mesajlari m WHERE m.talep_id=t.id ORDER BY m.id DESC LIMIT 1) son_mesaj,\n            (SELECT COUNT(*) FROM destek_mesajlari m WHERE m.talep_id=t.id AND m.gonderen_tipi='admin' AND m.okundu=0) okunmamis\n            FROM destek_talepleri t WHERE t.kullanici_id=? ORDER BY t.guncellenme DESC LIMIT 40");
        $st->execute([(int)$u['id']]);
        $rows=$st->fetchAll();
        sa_json(['ok'=>true,'talepler'=>$rows,'acik_sayi'=>count(array_filter($rows,fn($r)=>$r['durum']!=='cozuldu')),'kategoriler'=>sa_support_categories()]);
    }catch(Throwable $e){sa_log_event('HATA_DESTEK_OZET',$e->getMessage());sa_json(['ok'=>false,'mesaj'=>'Destek bilgileri alınamadı.'],500);}
}

if($action==='destek_talep_olustur'){
    try{
        $u=sa_current();$in=sa_request_json();
        $konu=trim((string)($in['konu']??''));$mesaj=trim((string)($in['mesaj']??''));$kategori=trim((string)($in['kategori']??'Genel'));$oncelik=in_array(($in['oncelik']??'normal'),['dusuk','normal','yuksek','acil'],true)?$in['oncelik']:'normal';
        if(mb_strlen($konu)<5||mb_strlen($konu)>150)sa_json(['ok'=>false,'mesaj'=>'Konu 5-150 karakter arasında olmalı.'],422);
        if(mb_strlen($mesaj)<10||mb_strlen($mesaj)>4000)sa_json(['ok'=>false,'mesaj'=>'Mesaj 10-4000 karakter arasında olmalı.'],422);
        if(!in_array($kategori,sa_support_categories(),true))$kategori='Genel';
        $pdo=sa_db();$pdo->beginTransaction();
        $st=$pdo->prepare("INSERT INTO destek_talepleri(kullanici_id,konu,kategori,oncelik,durum,son_mesaj_tarihi) VALUES(?,?,?,?, 'acik', NOW())");$st->execute([(int)$u['id'],$konu,$kategori,$oncelik]);$id=(int)$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO destek_mesajlari(talep_id,gonderen_tipi,gonderen_id,mesaj,okundu) VALUES(?, 'oyuncu', ?, ?, 1)")->execute([$id,(int)$u['id'],$mesaj]);
        $pdo->commit();sa_log_event('DESTEK_TALEP_OLUSTUR','talep='.$id,(int)$u['id']);sa_json(['ok'=>true,'talep_id'=>$id,'mesaj'=>'Destek talebiniz oluşturuldu.']);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_log_event('HATA_DESTEK_OLUSTUR',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Destek talebi oluşturulamadı.'],500);}
}

if($action==='destek_talep_detay'){
    try{
        $u=sa_current();$in=sa_request_json();$id=(int)($in['talep_id']??($_GET['talep_id']??0));if(!$id)sa_json(['ok'=>false,'mesaj'=>'Talep bulunamadı.'],422);
        $st=sa_db()->prepare("SELECT t.*,u.kullanici_adi,ua.kullanici_adi AS admin_adi FROM destek_talepleri t JOIN kullanicilar u ON u.id=t.kullanici_id LEFT JOIN kullanicilar ua ON ua.id=t.atanan_admin_id WHERE t.id=? LIMIT 1");$st->execute([$id]);$t=$st->fetch();if(!$t)sa_json(['ok'=>false,'mesaj'=>'Talep bulunamadı.'],404);
        if(!sa_is_admin_user($u)&&(int)$t['kullanici_id']!==(int)$u['id'])sa_json(['ok'=>false,'mesaj'=>'Yetkisiz erişim.'],403);
        $m=$pdo=sa_db()->prepare("SELECT m.id,m.gonderen_tipi,m.gonderen_id,m.mesaj,m.okundu,m.tarih,COALESCE(u.kullanici_adi,'Yönetim') AS gonderen_adi FROM destek_mesajlari m LEFT JOIN kullanicilar u ON u.id=m.gonderen_id WHERE m.talep_id=? ORDER BY m.id ASC");$m->execute([$id]);$messages=$m->fetchAll();
        if(sa_is_admin_user($u))sa_db()->prepare("UPDATE destek_mesajlari SET okundu=1 WHERE talep_id=? AND gonderen_tipi='oyuncu'")->execute([$id]);else sa_db()->prepare("UPDATE destek_mesajlari SET okundu=1 WHERE talep_id=? AND gonderen_tipi='admin'")->execute([$id]);
        sa_json(['ok'=>true,'talep'=>$t,'mesajlar'=>$messages]);
    }catch(Throwable $e){sa_log_event('HATA_DESTEK_DETAY',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Destek talebi açılamadı.'],500);}
}

if($action==='destek_mesaj_gonder'){
    try{
        $u=sa_current();$in=sa_request_json();$id=(int)($in['talep_id']??0);$mesaj=trim((string)($in['mesaj']??''));if(!$id||mb_strlen($mesaj)<1||mb_strlen($mesaj)>4000)sa_json(['ok'=>false,'mesaj'=>'Geçerli bir mesaj yazın.'],422);
        $st=sa_db()->prepare("SELECT * FROM destek_talepleri WHERE id=? LIMIT 1");$st->execute([$id]);$t=$st->fetch();if(!$t)sa_json(['ok'=>false,'mesaj'=>'Talep bulunamadı.'],404);
        $admin=sa_is_admin_user($u);if(!$admin&&(int)$t['kullanici_id']!==(int)$u['id'])sa_json(['ok'=>false,'mesaj'=>'Yetkisiz erişim.'],403);
        if(!$admin&&$t['durum']==='cozuldu')sa_db()->prepare("UPDATE destek_talepleri SET durum='acik' WHERE id=?")->execute([$id]);
        $tip=$admin?'admin':'oyuncu';
        sa_db()->prepare("INSERT INTO destek_mesajlari(talep_id,gonderen_tipi,gonderen_id,mesaj,okundu) VALUES(?,?,?,?,?)")->execute([$id,$tip,(int)$u['id'],$mesaj,$admin?1:0]);
        $newStatus=$admin?'beklemede':'acik';sa_db()->prepare("UPDATE destek_talepleri SET durum=?,atanan_admin_id=IF(?=1,?,atanan_admin_id),son_mesaj_tarihi=NOW(),guncellenme=NOW() WHERE id=?")->execute([$newStatus,$admin?1:0,$admin?(int)$u['id']:null,$id]);
        sa_log_event('DESTEK_MESAJ','talep='.$id.' tip='.$tip,(int)$u['id']);
        sa_json(['ok'=>true,'durum'=>$newStatus,'mesaj'=>'Mesaj gönderildi.']);
    }catch(Throwable $e){sa_log_event('HATA_DESTEK_MESAJ',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Mesaj gönderilemedi.'],500);}
}

if($action==='admin_destek_ozet'){
    $a=sa_require_admin();
    try{
        $pdo=sa_db();
        $counts=$pdo->query("SELECT durum,COUNT(*) adet FROM destek_talepleri GROUP BY durum")->fetchAll();$map=['acik'=>0,'beklemede'=>0,'cozuldu'=>0];foreach($counts as $c)$map[$c['durum']]=(int)$c['adet'];
        $unread=(int)$pdo->query("SELECT COUNT(*) FROM destek_mesajlari WHERE gonderen_tipi='oyuncu' AND okundu=0")->fetchColumn();
        sa_json(['ok'=>true,'acik'=>$map['acik'],'beklemede'=>$map['beklemede'],'cozuldu'=>$map['cozuldu'],'okunmamis'=>$unread]);
    }catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Destek istatistikleri alınamadı.'],500);}
}

if($action==='admin_destek_listesi'){
    $a=sa_require_admin();try{
        $in=sa_request_json();$status=trim((string)($in['durum']??''));$q=trim((string)($in['q']??''));$limit=max(1,min(100,(int)($in['limit']??50)));
        $sql="SELECT t.id,t.konu,t.kategori,t.oncelik,t.durum,t.son_mesaj_tarihi,t.guncellenme,u.kullanici_adi,u.email,COALESCE(ad.kullanici_adi,'—') admin_adi,(SELECT LEFT(m.mesaj,160) FROM destek_mesajlari m WHERE m.talep_id=t.id ORDER BY m.id DESC LIMIT 1) son_mesaj,(SELECT COUNT(*) FROM destek_mesajlari m WHERE m.talep_id=t.id AND m.gonderen_tipi='oyuncu' AND m.okundu=0) okunmamis FROM destek_talepleri t JOIN kullanicilar u ON u.id=t.kullanici_id LEFT JOIN kullanicilar ad ON ad.id=t.atanan_admin_id WHERE 1=1";
        $params=[];if(in_array($status,['acik','beklemede','cozuldu'],true)){$sql.=' AND t.durum=?';$params[]=$status;}if($q!==''){$sql.=' AND (t.konu LIKE ? OR u.kullanici_adi LIKE ? OR u.email LIKE ? OR CAST(t.id AS CHAR) LIKE ?)';$like='%'.$q.'%';array_push($params,$like,$like,$like,$like);} $sql.=' ORDER BY CASE t.durum WHEN "acik" THEN 0 WHEN "beklemede" THEN 1 ELSE 2 END, t.son_mesaj_tarihi DESC LIMIT '.$limit;
        $st=sa_db()->prepare($sql);$st->execute($params);sa_json(['ok'=>true,'liste'=>$st->fetchAll()]);
    }catch(Throwable $e){sa_log_event('HATA_ADMIN_DESTEK_LISTE',$e->getMessage(),(int)$a['id']);sa_json(['ok'=>false,'mesaj'=>'Destek talepleri alınamadı.'],500);}
}


if($action==='admin_destek_detay'){
    try{
        $a=sa_require_admin();$in=sa_request_json();$id=(int)($in['talep_id']??0);if(!$id)sa_json(['ok'=>false,'mesaj'=>'Talep numarası gerekli.'],422);
        $st=sa_db()->prepare("SELECT t.*,u.kullanici_adi,u.email,COALESCE(ad.kullanici_adi,'—') admin_adi FROM destek_talepleri t JOIN kullanicilar u ON u.id=t.kullanici_id LEFT JOIN kullanicilar ad ON ad.id=t.atanan_admin_id WHERE t.id=? LIMIT 1");$st->execute([$id]);$t=$st->fetch();if(!$t)sa_json(['ok'=>false,'mesaj'=>'Talep bulunamadı.'],404);
        $m=sa_db()->prepare("SELECT m.id,m.gonderen_tipi,m.gonderen_id,m.mesaj,m.okundu,m.tarih,COALESCE(u.kullanici_adi,IF(m.gonderen_tipi='admin','Yönetim','Oyuncu')) gonderen_adi FROM destek_mesajlari m LEFT JOIN kullanicilar u ON u.id=m.gonderen_id WHERE m.talep_id=? ORDER BY m.id ASC");$m->execute([$id]);$msgs=$m->fetchAll();sa_db()->prepare("UPDATE destek_mesajlari SET okundu=1 WHERE talep_id=? AND gonderen_tipi='oyuncu'")->execute([$id]);sa_db()->prepare("UPDATE destek_talepleri SET atanan_admin_id=? WHERE id=?")->execute([(int)$a['id'],$id]);sa_json(['ok'=>true,'talep'=>$t,'mesajlar'=>$msgs]);
    }catch(Throwable $e){sa_log_event('HATA_ADMIN_DESTEK_DETAY',$e->getMessage(),isset($a['id'])?(int)$a['id']:null);sa_json(['ok'=>false,'mesaj'=>'Destek talebi açılamadı: '.$e->getMessage()],500);}
}
if($action==='admin_destek_yanit'){
    try{
        $a=sa_require_admin();$in=sa_request_json();$id=(int)($in['talep_id']??0);$mesaj=trim((string)($in['mesaj']??''));$durum=in_array(($in['durum']??'beklemede'),['acik','beklemede','cozuldu'],true)?$in['durum']:'beklemede';if(!$id||mb_strlen($mesaj)<1||mb_strlen($mesaj)>4000)sa_json(['ok'=>false,'mesaj'=>'Geçerli bir yanıt gerekli.'],422);
        $pdo=sa_db();$pdo->beginTransaction();$q=$pdo->prepare("SELECT id FROM destek_talepleri WHERE id=? LIMIT 1");$q->execute([$id]);if(!$q->fetch()){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Talep bulunamadı.'],404);}
        $pdo->prepare("INSERT INTO destek_mesajlari(talep_id,gonderen_tipi,gonderen_id,mesaj,okundu) VALUES(?,?,?,?,1)")->execute([$id,'admin',(int)$a['id'],$mesaj]);$pdo->prepare("UPDATE destek_talepleri SET durum=?,atanan_admin_id=?,son_mesaj_tarihi=NOW(),guncellenme=NOW() WHERE id=?")->execute([$durum,(int)$a['id'],$id]);$pdo->commit();sa_log_event('ADMIN_DESTEK_YANIT','talep='.$id,(int)$a['id']);sa_json(['ok'=>true,'durum'=>$durum,'mesaj'=>'Yanıt kaydedildi.']);
    }catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_log_event('HATA_ADMIN_DESTEK_YANIT',$e->getMessage(),isset($a['id'])?(int)$a['id']:null);sa_json(['ok'=>false,'mesaj'=>'Yanıt gönderilemedi: '.$e->getMessage()],500);}
}

if($action==='admin_destek_durum'){
    $a=sa_require_admin();try{$in=sa_request_json();$id=(int)($in['talep_id']??0);$durum=in_array(($in['durum']??''),['acik','beklemede','cozuldu'],true)?$in['durum']:'beklemede';if(!$id)sa_json(['ok'=>false,'mesaj'=>'Talep bulunamadı.'],422);sa_db()->prepare("UPDATE destek_talepleri SET durum=?,atanan_admin_id=?,guncellenme=NOW() WHERE id=?")->execute([$durum,(int)$a['id'],$id]);sa_log_event('DESTEK_DURUM','talep='.$id.' durum='.$durum,(int)$a['id']);sa_json(['ok'=>true,'durum'=>$durum]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Talep durumu güncellenemedi.'],500);}
}

/* ============================ 5.4 ADMIN API ============================ */
if($action==='admin_users'){
    $a=sa_require_admin();try{$rows=sa_db()->query("SELECT id,kullanici_adi,email,yetki,seviye,xp,coin,elmas,rating,galibiyet,maglubiyet,oldurme,olum,son_giris,dogrulanmis,chat_mute_until,ban_until FROM kullanicilar ORDER BY id DESC LIMIT 500")->fetchAll();sa_json(['ok'=>true,'liste'=>$rows]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>$e->getMessage()],500);}
}
if($action==='admin_bakiye'){
    $a=sa_require_admin();try{$in=sa_request_json();$id=(int)($in['id']??0);$coin=max(0,(int)($in['coin']??0));$elmas=max(0,(int)($in['elmas']??0));if(!$id)sa_json(['ok'=>false,'mesaj'=>'Oyuncu seçilmedi.'],422);sa_db()->prepare("UPDATE kullanicilar SET coin=?,elmas=? WHERE id=?")->execute([$coin,$elmas,$id]);sa_log_event('ADMIN_BAKIYE','uid='.$id,(int)$a['id']);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Bakiye güncellenemedi.'],500);}
}
if($action==='admin_oyuncu_islem'){
    $a=sa_require_admin();try{$in=sa_request_json();$id=(int)($in['id']??0);$islem=(string)($in['islem']??'');if(!$id)sa_json(['ok'=>false,'mesaj'=>'Oyuncu seçilmedi.'],422);$allowed=['ban','unban','mute','unmute','verify','unverify'];if(!in_array($islem,$allowed,true))sa_json(['ok'=>false,'mesaj'=>'Geçersiz işlem.'],422);if($islem==='ban'){$until=time()+max(1,min(10080,(int)($in['sure_dk']??60)))*60;sa_db()->prepare("UPDATE kullanicilar SET ban_until=? WHERE id=?")->execute([$until,$id]);}elseif($islem==='unban')sa_db()->prepare("UPDATE kullanicilar SET ban_until=0 WHERE id=?")->execute([$id]);elseif($islem==='mute'){$until=time()+max(1,min(43200,(int)($in['sure_dk']??30)))*60;sa_db()->prepare("UPDATE kullanicilar SET chat_mute_until=? WHERE id=?")->execute([$until,$id]);}elseif($islem==='unmute')sa_db()->prepare("UPDATE kullanicilar SET chat_mute_until=0 WHERE id=?")->execute([$id]);elseif($islem==='verify')sa_db()->prepare("UPDATE kullanicilar SET dogrulanmis=1 WHERE id=?")->execute([$id]);else sa_db()->prepare("UPDATE kullanicilar SET dogrulanmis=0 WHERE id=?")->execute([$id]);sa_log_event('ADMIN_OYUNCU_ISLEM',$islem.' uid='.$id,(int)$a['id']);sa_json(['ok'=>true,'mesaj'=>'Oyuncu güncellendi.']);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Oyuncu işlemi başarısız: '.$e->getMessage()],500);}
}
if($action==='admin_hatalar'){$a=sa_require_admin();try{$rows=sa_db()->query("SELECT s.id,s.kullanici_id,s.olay,s.detay,s.ip_adresi,s.tarih,u.kullanici_adi FROM sistem_loglari s LEFT JOIN kullanicilar u ON u.id=s.kullanici_id WHERE s.olay LIKE 'HATA%' OR s.olay LIKE 'JS_%' OR s.olay LIKE 'API_%' OR s.olay LIKE 'OYUN_%' ORDER BY s.id DESC LIMIT 300")->fetchAll();sa_json(['ok'=>true,'liste'=>$rows,'sunucu_zamani'=>date('Y-m-d H:i:s')]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>$e->getMessage()],500);}}
if($action==='admin_hatalar_temizle'){$a=sa_require_admin();try{sa_db()->exec("DELETE FROM sistem_loglari WHERE olay LIKE 'HATA%' OR olay LIKE 'JS_%' OR olay LIKE 'API_%' OR olay LIKE 'OYUN_%'");sa_log_event('ADMIN_HATALAR_TEMIZLENDI','',(int)$a['id']);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Hata kayıtları temizlenemedi.'],500);}}
if($action==='admin_guvenlik'){$a=sa_require_admin();try{$rows=sa_db()->query("SELECT g.id,g.kullanici_id,g.olay,g.puan,g.detay,g.ip_adresi,g.tarih,u.kullanici_adi FROM guvenlik_olaylari g LEFT JOIN kullanicilar u ON u.id=g.kullanici_id ORDER BY g.id DESC LIMIT 250")->fetchAll();sa_json(['ok'=>true,'liste'=>$rows]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>$e->getMessage()],500);}}
if($action==='admin_oduller_get'){$a=sa_require_admin();$r=sa_db()->query("SELECT * FROM oyun_odul_ayarlari WHERE id=1 LIMIT 1")->fetch();sa_json(['ok'=>true,'ayar'=>$r?:[]]);}
if($action==='admin_oduller_save'){$a=sa_require_admin();try{$in=sa_request_json();$keys=['normal_sure_saniye','normal_birinci_xp','normal_birinci_coin','normal_takim_xp','normal_takim_coin','klan_kazanan_xp','klan_kazanan_coin','klan_kaybeden_xp','klan_kaybeden_coin'];$vals=[];foreach($keys as $k)$vals[]=max(0,(int)($in[$k]??0));sa_db()->prepare("UPDATE oyun_odul_ayarlari SET normal_sure_saniye=?,normal_birinci_xp=?,normal_birinci_coin=?,normal_takim_xp=?,normal_takim_coin=?,klan_kazanan_xp=?,klan_kazanan_coin=?,klan_kaybeden_xp=?,klan_kaybeden_coin=? WHERE id=1")->execute($vals);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Ödüller kaydedilemedi.'],500);}}
if($action==='admin_iyzico_get'){$a=sa_require_admin();$r=sa_db()->query("SELECT api_key,secret_key,base_url,aktif FROM ayarlar_iyzico WHERE id=1")->fetch()?:[];$r['api_key']=function_exists('sa_decrypt')?sa_decrypt($r['api_key']??''):($r['api_key']??'');$r['secret_key']='';sa_json(['ok'=>true,'ayar'=>$r]);}
if($action==='admin_iyzico_save'){$a=sa_require_admin();try{$in=sa_request_json();$key=trim((string)($in['api_key']??''));$secret=trim((string)($in['secret_key']??''));$env=($in['base_url']??'')==='live'?'https://api.iyzipay.com':'https://sandbox-api.iyzipay.com';$active=!empty($in['aktif'])?1:0;$old=sa_db()->query("SELECT secret_key FROM ayarlar_iyzico WHERE id=1")->fetchColumn();$storedSecret=$secret!==''?$secret:$old;$ek=static function($v){return function_exists('sa_crypt')?sa_crypt($v):$v;};sa_db()->prepare("INSERT INTO ayarlar_iyzico(id,api_key,secret_key,base_url,aktif) VALUES(1,?,?,?,?) ON DUPLICATE KEY UPDATE api_key=VALUES(api_key),secret_key=VALUES(secret_key),base_url=VALUES(base_url),aktif=VALUES(aktif)")->execute([$ek($key),$ek($storedSecret),$env,$active]);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'iyzico ayarları kaydedilemedi.'],500);}}
if($action==='admin_urunler'){$a=sa_require_admin();sa_json(['ok'=>true,'liste'=>sa_db()->query("SELECT * FROM sanal_urunler ORDER BY fiyat ASC,id ASC")->fetchAll()]);}
if($action==='admin_urun_kaydet'){$a=sa_require_admin();try{$in=sa_request_json();$id=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['id']??''));$ad=trim((string)($in['ad']??''));$ac=trim((string)($in['aciklama']??''));$f=max(0,(float)($in['fiyat']??0));$coin=max(0,(int)($in['coin']??0));$elmas=max(0,(int)($in['elmas']??0));$aktif=!empty($in['aktif'])?1:0;if(!$id||!$ad)sa_json(['ok'=>false,'mesaj'=>'Ürün ID ve adı gerekli.'],422);sa_db()->prepare("INSERT INTO sanal_urunler(id,ad,aciklama,fiyat,coin,elmas,aktif) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE ad=VALUES(ad),aciklama=VALUES(aciklama),fiyat=VALUES(fiyat),coin=VALUES(coin),elmas=VALUES(elmas),aktif=VALUES(aktif)")->execute([$id,$ad,$ac,$f,$coin,$elmas,$aktif]);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Ürün kaydedilemedi.'],500);}}
if($action==='admin_duyuru_yayinla'){
    $a=sa_require_admin();try{$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$bas=mb_substr(trim((string)($in['baslik']??'Yönetici Duyurusu')),0,120);$icer=mb_substr(trim((string)($in['icerik']??'')),0,1000);if(!$oda||$icer==='')sa_json(['ok'=>false,'mesaj'=>'Duyuru boş olamaz.'],422);$pdo=sa_db();$pdo->prepare("INSERT INTO duyurular(oda_id,baslik,icerik,tur,aktif,sabit) VALUES(?,?,?,'uyari',1,1)")->execute([$oda,$bas,$icer]);$id=(int)$pdo->lastInsertId();$pdo->prepare("INSERT INTO web_mac_sohbet(oda_id,kullanici_id,mesaj) VALUES(?,?,?)")->execute([$oda,(int)$a['id'],'📢 DUYURU • '.$bas.' • '.$icer]);$chatId=(int)$pdo->lastInsertId();sa_log_event('ADMIN_DUYURU_YAYINLA','oda='.$oda.' id='.$id.' chat='.$chatId,(int)$a['id']);sa_json(['ok'=>true,'id'=>$id,'chat_id'=>$chatId,'mesaj'=>$icer]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Duyuru yayınlanamadı.'],500);}}
if($action==='web_duyurular_aktif'){
    try{$u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$since=max(0,(int)($in['since_id']??0));$hasOda=false;try{$q=sa_db()->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='duyurular' AND column_name='oda_id'");$q->execute();$hasOda=(int)$q->fetchColumn()>0;}catch(Throwable $ignore){}$sql=$hasOda?"SELECT id,baslik,icerik FROM duyurular WHERE aktif=1 AND id>? AND yayin_tarihi<=NOW() AND (oda_id=? OR oda_id IS NULL) ORDER BY id ASC LIMIT 20":"SELECT id,baslik,icerik FROM duyurular WHERE aktif=1 AND id>? AND yayin_tarihi<=NOW() ORDER BY id ASC LIMIT 20";$st=sa_db()->prepare($sql);if($hasOda)$st->execute([$since,$oda]);else$st->execute([$since]);sa_json(['ok'=>true,'liste'=>$st->fetchAll()]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Duyurular alınamadı.'],500);}}

if($action==='admin_duyurular'){$a=sa_require_admin();sa_json(['ok'=>true,'liste'=>sa_db()->query("SELECT * FROM duyurular ORDER BY sabit DESC,yayin_tarihi DESC,id DESC LIMIT 200")->fetchAll()]);}
if($action==='admin_duyuru_kaydet'){$a=sa_require_admin();try{$in=sa_request_json();$id=(int)($in['id']??0);$bas=trim((string)($in['baslik']??''));$icer=trim((string)($in['icerik']??''));$tur=in_array(($in['tur']??'bilgi'),['bilgi','etkinlik','guncelleme','uyari'],true)?$in['tur']:'bilgi';$aktif=!empty($in['aktif'])?1:0;$sabit=!empty($in['sabit'])?1:0;if(mb_strlen($bas)<3||$icer==='')sa_json(['ok'=>false,'mesaj'=>'Başlık ve içerik gerekli.'],422);if($id){sa_db()->prepare("UPDATE duyurular SET baslik=?,icerik=?,tur=?,aktif=?,sabit=? WHERE id=?")->execute([$bas,$icer,$tur,$aktif,$sabit,$id]);}else{sa_db()->prepare("INSERT INTO duyurular(baslik,icerik,tur,aktif,sabit) VALUES(?,?,?,?,?)")->execute([$bas,$icer,$tur,$aktif,$sabit]);}sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Duyuru kaydedilemedi.'],500);}}
if($action==='admin_duyuru_sil'){$a=sa_require_admin();try{$in=sa_request_json();$id=(int)($in['id']??0);if(!$id)sa_json(['ok'=>false,'mesaj'=>'Duyuru bulunamadı.'],422);sa_db()->prepare("DELETE FROM duyurular WHERE id=?")->execute([$id]);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Duyuru silinemedi.'],500);}}

/* ============================ 5.8 STORE / RULES / VOICE ============================ */
if($action==='magaza'){
    try{
        $items=sa_item_catalog();$out=[];foreach($items as $id=>$it){if(($it['fiyat']??0)>0)$out[]=array_merge($it,['id'=>$id,'aciklama'=>$it['aciklama']??'']);}
        usort($out,fn($a,$b)=>((int)($a['fiyat']??0)<=>((int)($b['fiyat']??0))));sa_json(['ok'=>true,'liste'=>$out]);
    }catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Mağaza yüklenemedi.'],500);}
}
if($action==='satinal'){
    try{$u=sa_current();$in=sa_request_json();$id=preg_replace('/[^a-z0-9_-]/i','',(string)($in['item_id']??''));$items=sa_item_catalog();$it=$items[$id]??null;if(!$it||($it['fiyat']??0)<=0)sa_json(['ok'=>false,'mesaj'=>'Ürün bulunamadı.'],404);$currency=($it['para']??'coin')==='elmas'?'elmas':'coin';$price=(int)$it['fiyat'];$pdo=sa_db();$pdo->beginTransaction();$lock=$pdo->prepare("SELECT coin,elmas FROM kullanicilar WHERE id=? FOR UPDATE");$lock->execute([$u['id']]);$bal=$lock->fetch();if(!$bal||((int)$bal[$currency]<$price)){$pdo->rollBack();sa_json(['ok'=>false,'mesaj'=>'Yeterli '.($currency==='coin'?'Coin':'Elmas').' bulunmuyor.'],409);} $pdo->prepare("UPDATE kullanicilar SET $currency=$currency-? WHERE id=?")->execute([$price,$u['id']]);$pdo->prepare("INSERT INTO envanter(kullanici_id,item_id,adet) VALUES(?,?,1) ON DUPLICATE KEY UPDATE adet=adet+1")->execute([$u['id'],$id]);$pdo->prepare("INSERT INTO satin_almalar(kullanici_id,item_id,fiyat,para_birimi) VALUES(?,?,?,?)")->execute([$u['id'],$id,$price,$currency]);$pdo->commit();sa_json(['ok'=>true,'mesaj'=>'Ürün hesabınıza eklendi.','urun'=>$id]);}catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();sa_log_event('HATA_SATINAL',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>'Satın alma başarısız oldu.'],500);}
}
if($action==='odeme_urunler'){
    try{$rows=sa_db()->query("SELECT id,ad,aciklama,fiyat,coin,elmas FROM sanal_urunler WHERE aktif=1 ORDER BY fiyat ASC,id ASC")->fetchAll();sa_json(['ok'=>true,'liste'=>$rows]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Ödeme ürünleri alınamadı.'],500);}
}
if($action==='odeme_baslat'){
    try{$u=sa_current();$in=sa_request_json();$id=preg_replace('/[^a-z0-9_-]/i','',(string)($in['urun_id']??''));$st=sa_db()->prepare("SELECT * FROM sanal_urunler WHERE id=? AND aktif=1 LIMIT 1");$st->execute([$id]);$prod=$st->fetch();if(!$prod)sa_json(['ok'=>false,'mesaj'=>'Ödeme ürünü bulunamadı.'],404);$callback=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').'/iyzico_callback.php';$res=sa_iyzi_initialize($u,$prod,(float)$prod['fiyat'],$callback);$conv=$res['_conversation']??('SA'.date('YmdHis').bin2hex(random_bytes(3)));$tokenPay=(string)($res['token']??'');sa_db()->prepare("INSERT INTO iyzico_siparisler(kullanici_id,urun_id,tutar,token,conversation_id,durum,yanit) VALUES(?,?,?,?,?,'bekliyor',?)")->execute([$u['id'],$id,$prod['fiyat'],$tokenPay,$conv,json_encode($res,JSON_UNESCAPED_UNICODE)]);sa_json(['ok'=>true,'icerik'=>$res['checkoutFormContent']??null,'odeme_url'=>$res['paymentPageUrl']??null,'token'=>$tokenPay]);}catch(Throwable $e){sa_log_event('HATA_IYZICO_BASLAT',$e->getMessage(),isset($u['id'])?(int)$u['id']:null);sa_json(['ok'=>false,'mesaj'=>$e->getMessage()],500);}
}
if($action==='kurallar'){
    try{$r=sa_db()->query("SELECT id,baslik,ozet,icerik,guncellenme FROM oyun_kurallari WHERE aktif=1 ORDER BY id ASC LIMIT 1")->fetch();sa_json(['ok'=>true,'kural'=>$r?:['id'=>1,'baslik'=>'Stick Arena Oyun Kuralları','ozet'=>'Adil oyun, saygılı iletişim ve weapon-only arena.','icerik'=>'Maçlarda yalnızca silah sistemi kullanılır. Hile, açık istismarı, tehdit, spam ve kötüye kullanım yasaktır. Sesli iletişimde takım arkadaşlarına saygılı olun.','guncellenme'=>date('Y-m-d H:i:s')]]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Kurallar yüklenemedi.'],500);}
}
if($action==='admin_kurallar_get'){ $a=sa_require_admin();try{$r=sa_db()->query("SELECT * FROM oyun_kurallari WHERE id=1 LIMIT 1")->fetch();sa_json(['ok'=>true,'kural'=>$r?:[]]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Kurallar alınamadı.'],500);}}
if($action==='admin_kurallar_save'){ $a=sa_require_admin();try{$in=sa_request_json();$bas=trim((string)($in['baslik']??''));$oz=trim((string)($in['ozet']??''));$icer=trim((string)($in['icerik']??''));$aktif=!empty($in['aktif'])?1:0;if(mb_strlen($bas)<3||$icer==='')sa_json(['ok'=>false,'mesaj'=>'Başlık ve kurallar metni gerekli.'],422);sa_db()->prepare("INSERT INTO oyun_kurallari(id,baslik,ozet,icerik,aktif) VALUES(1,?,?,?,?) ON DUPLICATE KEY UPDATE baslik=VALUES(baslik),ozet=VALUES(ozet),icerik=VALUES(icerik),aktif=VALUES(aktif),guncellenme=NOW()")->execute([$bas,$oz,$icer,$aktif]);sa_log_event('ADMIN_KURALLAR_GUNCELLENDI','',(int)$a['id']);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Kurallar kaydedilemedi.'],500);}}
if($action==='voice_participants'){
    try{$u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç gerekli.'],422);$st=sa_db()->prepare("SELECT rakip_turu,state_json FROM web_aktif_maclar WHERE oda_id=? AND durum='aktif' LIMIT 1");$st->execute([$oda]);$m=$st->fetch();if(!$m)sa_json(['ok'=>false,'mesaj'=>'Maç bulunamadı.'],404);$state=json_decode($m['state_json']??'{}',true)?:[];$meTeam='A';foreach($state['players']??[] as $p){if((int)($p['id']??0)===(int)$u['id']){$meTeam=$p['team']==='B'?'B':'A';break;}}$out=[];foreach($state['players']??[] as $p){if(empty($p['real'])||($p['team']??'A')!==$meTeam)continue;$out[]=['id'=>(int)$p['id'],'name'=>(string)($p['name']??'Oyuncu'),'team'=>$meTeam];}sa_json(['ok'=>true,'oda'=>$oda,'takim'=>$meTeam,'katilimcilar'=>$out]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Sesli kanal bilgisi alınamadı.'],500);}
}
if($action==='voice_signal_send'){
    try{$u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$to=(int)($in['to']??0);$kind=in_array(($in['kind']??''),['offer','answer','candidate','leave'],true)?$in['kind']:'';$payload=(string)($in['payload']??'');if(!$oda||!$to||$kind===''||mb_strlen($payload)>20000)sa_json(['ok'=>false,'mesaj'=>'Geçersiz ses sinyali.'],422);$st=sa_db()->prepare("INSERT INTO web_voice_signals(oda_id,gonderen_id,alan_id,tur,payload) VALUES(?,?,?,?,?)");$st->execute([$oda,$u['id'],$to,$kind,$payload]);sa_json(['ok'=>true,'id'=>(int)sa_db()->lastInsertId()]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Ses sinyali gönderilemedi.'],500);}
}
if($action==='voice_signal_poll'){
    try{$u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));$after=max(0,(int)($in['after']??0));if(!$oda)sa_json(['ok'=>false,'mesaj'=>'Maç gerekli.'],422);$st=sa_db()->prepare("SELECT id,gonderen_id,alan_id,tur,payload,tarih FROM web_voice_signals WHERE oda_id=? AND alan_id=? AND id>? ORDER BY id ASC LIMIT 80");$st->execute([$oda,$u['id'],$after]);sa_json(['ok'=>true,'liste'=>$st->fetchAll()]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Ses sinyalleri alınamadı.'],500);}
}
if($action==='voice_signal_clean'){
    try{$u=sa_current();$in=sa_request_json();$oda=preg_replace('/[^A-Za-z0-9_-]/','',(string)($in['oda']??''));if($oda)sa_db()->prepare("DELETE FROM web_voice_signals WHERE oda_id=? AND (gonderen_id=? OR alan_id=?)")->execute([$oda,$u['id'],$u['id']]);sa_json(['ok'=>true]);}catch(Throwable $e){sa_json(['ok'=>false,'mesaj'=>'Ses bağlantıları temizlenemedi.'],500);}
}

// Son güvenli yanıt: tanımsız bir action hiçbir zaman boş HTTP 200 dönmez.
sa_json(['ok'=>false,'mesaj'=>'Geçersiz işlem: '.($action?:'action belirtilmedi').'.'],404);
