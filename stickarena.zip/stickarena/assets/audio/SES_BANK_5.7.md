# Stick Arena 5.8 — Ses Bankası

Bu sürümdeki WAV dosyaları proje için yerel olarak sentezlenmiş, yeniden dağıtım kısıtı bulunmayan özgün seslerdir. Silah sesi tasarımında kısa muzzle-crack, düşük frekans basınç dalgası, mekanik klik ve kısa oda yankısı katmanları kullanılır. Harici CC0 kaynaklar referans olarak incelenebilir; ham üçüncü taraf kayıtları pakete kopyalanmamıştır.

İncelenen açık lisanslı referanslar: Free Firearm Sound Library (CC0) ve OpenGameArt CC0 silah/reload kaynakları.
