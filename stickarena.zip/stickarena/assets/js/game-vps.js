const canvas=document.getElementById('oyun'),ctx=canvas.getContext('2d');
const token=localStorage.getItem('stickarena_token');
if(!token){location.href='giris.php';throw new Error('Giriş gerekli');}
const server=window.STICKARENA_GAME_SERVER;
let ws,me=null,state={players:[],score:{A:0,B:0},map:null},mode='normal',seq=0;
function oyunModu(m){mode=m; if(ws&&ws.readyState===1) ws.close(); connect();}
window.oyunModu=oyunModu;
const keys={left:false,right:false,up:false,shoot:false};
function connect(){
 ws=new WebSocket(server);
 ws.onopen=()=>{ws.send(JSON.stringify({t:'auth',token,mode}));document.getElementById('durum').textContent='Sunucuya bağlı';};
 ws.onclose=()=>{document.getElementById('durum').textContent='Bağlantı kesildi';setTimeout(connect,3000);}
 ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}
  if(m.t==='baglanti'){me=m.id;state.map=m.harita;document.getElementById('oda').textContent=m.oda;document.getElementById('mod').textContent=m.mod==='klan'?'100v100 KLAN':'20v20';}
  if(m.t==='basladi'){document.getElementById('sure').textContent='15:00';}
  if(m.t==='mac_sonu'){const el=document.getElementById('mesajlar');el.innerHTML='<div><b>MAÇ BİTTİ</b> — Birinci: '+(m.birinci?m.birinci.name+' ('+m.birinci.kills+' kill)':'—')+'</div>'+el.innerHTML;}
  if(m.t==='lobi'){document.getElementById('durum').textContent='Lobi';}
  if(m.t==='durum'){state.players=m.oyuncular;state.score=m.skor;document.getElementById('skor').textContent=state.score.A+' — '+state.score.B;document.getElementById('oyuncular').textContent=state.players.length+(mode==='klan'?'/200':'/40');const sec=Number(m.kalan||900);document.getElementById('sure').textContent=String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');}
  if(m.t==='sistem'||m.t==='olay'){const el=document.getElementById('mesajlar');el.innerHTML='<div>'+m.mesaj+'</div>'+el.innerHTML;el.innerHTML=[...el.children].slice(0,8).map(x=>x.outerHTML).join('');}
 };
}
function sendInput(){if(ws&&ws.readyState===1)ws.send(JSON.stringify({t:'input',seq:++seq,...keys}));}
addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp',' ','a','d','w'].includes(e.key))e.preventDefault();
 if(e.key==='a'||e.key==='ArrowLeft')keys.left=true;
 if(e.key==='d'||e.key==='ArrowRight')keys.right=true;
 if(e.key==='w'||e.key==='ArrowUp')keys.up=true;
 if(e.key===' ')keys.shoot=true;sendInput();});
addEventListener('keyup',e=>{if(e.key==='a'||e.key==='ArrowLeft')keys.left=false;if(e.key==='d'||e.key==='ArrowRight')keys.right=false;if(e.key==='w'||e.key==='ArrowUp')keys.up=false;if(e.key===' ')keys.shoot=false;sendInput();});
function draw(){
 ctx.clearRect(0,0,canvas.width,canvas.height);
 const m=state.map;if(!m){requestAnimationFrame(draw);return;}
 const mep=state.players.find(p=>p.id===me),cam=mep?Math.max(0,Math.min(m.genislik-canvas.width,mep.x-canvas.width/2)):0;
 ctx.save();ctx.translate(-cam,0);
 ctx.fillStyle='#080b11';ctx.fillRect(cam,0,canvas.width,canvas.height);
 ctx.fillStyle='#171d28';for(const p of m.platformlar)ctx.fillRect(p.x,p.y,p.w,p.h);
 for(const p of state.players){ctx.save();ctx.translate(p.x,p.y);ctx.strokeStyle=p.team==='A'?'#5da9ff':'#ff6574';ctx.lineWidth=5;ctx.beginPath();ctx.arc(0,-32,14,0,Math.PI*2);ctx.moveTo(0,-18);ctx.lineTo(0,28);ctx.moveTo(0,-2);ctx.lineTo(-18,12);ctx.moveTo(0,-2);ctx.lineTo(18,12);ctx.moveTo(0,28);ctx.lineTo(-15,48);ctx.moveTo(0,28);ctx.lineTo(15,48);ctx.stroke();ctx.fillStyle='#fff';ctx.font='13px Arial';ctx.textAlign='center';ctx.fillText(p.name,0,-58);ctx.fillStyle='#222';ctx.fillRect(-24,-52,48,5);ctx.fillStyle='#6ee58b';ctx.fillRect(-24,-52,48*(p.hp/100),5);ctx.restore();}
 ctx.restore();requestAnimationFrame(draw);
}
connect();draw();
