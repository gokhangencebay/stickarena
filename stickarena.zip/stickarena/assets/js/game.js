// v2.8 legacy loader intentionally disabled. oyun.php loads game-web.js directly.
