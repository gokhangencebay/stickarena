window.STICKARENA_GAME_SERVER = "wss://gncby.com.tr";
