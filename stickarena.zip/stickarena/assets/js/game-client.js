(() => {
  'use strict';

  const CONFIGURED_GAME_SERVER = String(window.STICKARENA_GAME_SERVER || '').trim();
  const CONFIGURED_GAME_HTTP = String(window.STICKARENA_GAME_HTTP_SERVER || '').trim();
  const VERSION = String(window.STICKARENA_GAME_VERSION || '5.4.0');
  const token = localStorage.getItem('stickarena_token') || '';
  const $ = (id) => document.getElementById(id);
  const canvas = $('oyun');
  const ctx = canvas?.getContext('2d');
  if (!canvas || !ctx) return;

  const MAPS = [
    ['orman','Neon Metropol','https://opengameart.org/sites/default/files/scifi_platform_BG1.jpg'],
    ['gece_ormani','Gece Şehri','https://opengameart.org/sites/default/files/citynight.png'],
    ['sehir_gece','Retro Mega Şehir','https://opengameart.org/sites/default/files/retropixelcity.png'],
    ['liman','Uzay Limanı','https://opengameart.org/sites/default/files/Space-Background-1.jpg'],
    ['askeri_us','Derin Uzay Üssü','https://opengameart.org/sites/default/files/Space-Background-2.jpg'],
    ['col_bolgesi','Kızıl Nebula','https://opengameart.org/sites/default/files/Background-1.png'],
    ['sehir_insaati','Mavi Nebula','https://opengameart.org/sites/default/files/Background-2.png'],
    ['karli_daglar','Mor Nebula','https://opengameart.org/sites/default/files/Background-3.png'],
    ['uzay_istasyonu','Mavi Derinlik','https://opengameart.org/sites/default/files/Background-4.png'],
    ['harabe','Sisli Şehir','https://opengameart.org/sites/default/files/image5.jpg'],
  ];
  const CHARACTER_SHEETS = {
    A: 'https://opengameart.org/sites/default/files/Soldier%20Full.png',
    B: 'https://opengameart.org/sites/default/files/Soldier%20Helmet.png'
  };
  const WEAPONS = {
    tabanca:['Standart Tabanca','https://opengameart.org/sites/default/files/pistol.png','pistol'],
    tufek:['Taarruz Tüfeği','https://opengameart.org/sites/default/files/rifle.png','rifle'],
    makineli_tufek:['Makineli Tüfek','https://opengameart.org/sites/default/files/handgun.png','smg'],
    pompal_tufek:['Pompalı Tüfek','https://opengameart.org/sites/default/files/shotgun.png','shotgun'],
    keskin_nisanci:['Keskin Nişancı','https://opengameart.org/sites/default/files/spritesheet-guns.png','sniper'],
    roketatar:['Roketatar','https://opengameart.org/sites/default/files/Rocket_Launcher.png','rocket'],
    neon_silah:['Neon Blaster','https://opengameart.org/sites/default/files/Weapons%20by%20Ergorius.png','neon'],
    alev_silah:['Alev Silahı','https://opengameart.org/sites/default/files/handgun.png','fire'],
    buz_silah:['Buz Silahı','https://opengameart.org/sites/default/files/rifle.png','ice'],
    karbon_silah:['Karbon Tüfek','https://opengameart.org/sites/default/files/ww2-thompson-gun-vector-png.png','thompson'],
    altin_silah:['Altın Silah','https://opengameart.org/sites/default/files/pistol.png','gold'],
    karanlik_silah:['Karanlık Silah','https://opengameart.org/sites/default/files/Rocket_Launcher.png','dark']
  };
  const EMOJIS = ['😀','😎','😂','🔥','💀','GG','👏','⚡','🎯','❤️','😈','🤝'];
  const imageCache = new Map();
  const state = {
    socket:null, mode:'normal', room:null, team:null, connected:false, started:false, ended:false,
    map:null, score:{A:0,B:0}, players:new Map(), bullets:[], pickups:[], killFeed:[],
    serverOffset:0, remainingMs:15*60*1000, paused:false, pauseRemainingMs:0, attackStyles:new Map(),
    localId:null, inputSeq:0, input:{left:false,right:false,jump:false,shoot:false,down:false,aimX:1,aimY:0},
    renderPlayers:new Map(), fx:[], activeChannel:'all', chatHidden:false, muted:new Set(JSON.parse(localStorage.getItem('sa51_muted')||'[]')),
    spectatorTarget:null,authenticated:false,connectionStage:'idle',authWatchdog:null, halfUntil:0, messageTimer:null, lastSnapshotAt:0, connecting:false, connectAttempt:0, manualClose:false, lastCloseCode:0, lastCloseReason:''
  };

  function img(src) {
    if (imageCache.has(src)) return imageCache.get(src);
    const im = new Image(); im.decoding = 'async'; im.src = src; imageCache.set(src, im); return im;
  }
  function asset(path){ return /^https?:\/\//i.test(String(path)) ? String(path) : ''; }
  function escText(value){ return String(value ?? '').replace(/[\u0000-\u001F\u007F]/g,''); }
  function formatTime(ms){ const s=Math.max(0,Math.ceil(ms/1000)); return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; }
  function setStatus(text, good){ $('connectionStatus').textContent=text; $('connectionStatus').parentElement.style.color=good?'var(--sa-green)':'var(--sa-red)'; }
  function message(text){ $('lobbyMessage').textContent=text; }
  function mapById(id){ return MAPS.find(x=>x[0]===id) || MAPS[0]; }
  function localPlayer(){ return state.localId ? state.players.get(String(state.localId)) : null; }

  function buildLobby(){
    const grid=$('mapPreviewGrid');
    if (!grid) return;
    grid.replaceChildren();
    MAPS.forEach((m,i)=>{
      const card=document.createElement('div'); card.className='sa51-map-card';
      const im=document.createElement('img'); im.src=m[2]; im.alt=m[1]; im.loading=i<4?'eager':'lazy';
      const name=document.createElement('b'); name.textContent=m[1]; const no=document.createElement('em'); no.textContent=String(i+1).padStart(2,'0');
      card.append(im,name,no); grid.append(card);
    });
    EMOJIS.forEach(e=>{ const b=document.createElement('button'); b.type='button'; b.textContent=e; b.addEventListener('click',()=>{ $('chatInput').value += e; $('chatInput').focus(); }); $('emojiPicker').append(b); });
  }

  function setMode(mode){
    state.mode=mode==='klan'?'klan':'normal';
    document.querySelectorAll('.sa51-mode-card').forEach(b=>b.classList.toggle('active',b.dataset.mode===state.mode));
    $('modeSummary').textContent=state.mode==='klan'?'10v10 KLAN SAVAŞI':'5v5 NORMAL';
  }

  function openMatch(){ $('lobbyScreen').hidden=true; $('matchLayer').hidden=false; }
  function backLobby(){
    state.ended=true; state.manualClose=true;
    if (state.socket) { try{state.socket.close(1000,'lobi');}catch(_){} }
    state.socket=null; state.connected=false; state.started=false; state.ended=false; state.room=null; state.players.clear(); state.renderPlayers.clear(); state.bullets=[]; state.pickups=[]; state.killFeed=[]; state.ended=false;
    $('matchLayer').hidden=true; $('lobbyScreen').hidden=false; $('spectatorOverlay').hidden=true; $('halfOverlay').hidden=true; $('matchEndOverlay').hidden=true;
    setStatus('HAZIR',true); message('Mod seç ve eşleşmeye kat.');
  }

  async function lockLandscape(){ try{ if (screen.orientation?.lock) await screen.orientation.lock('landscape'); }catch(_){} }
  async function toggleFullscreen(){
    try{
      if (!document.fullscreenElement) { await document.body.requestFullscreen(); await lockLandscape(); }
      else await document.exitFullscreen();
    }catch(_){ message('Tarayıcı tam ekran izni vermedi.'); }
  }

  function gameEndpointCandidates(){
    const list=[];
    const push=v=>{v=String(v||'').trim(); if(!v || /oyunalanadiniz|YOUR-|CHANGE_ME/i.test(v)) return; if(!/^wss?:\/\//i.test(v)) return; if(!list.includes(v)) list.push(v.replace(/\/$/,''));};
    push(CONFIGURED_GAME_SERVER);
    if(CONFIGURED_GAME_HTTP && !/^(auto|\$|YOUR-)/i.test(CONFIGURED_GAME_HTTP)){
      try{ const u=new URL(CONFIGURED_GAME_HTTP); u.protocol=u.protocol==='https:'?'wss:':'ws:'; push(u.toString()); }catch(_){}
    }
    try{ const same=location.origin.replace(/^https:/i,'wss:').replace(/^http:/i,'ws:'); push(same); }catch(_){}
    return list;
  }

  function closeDiagnostic(code, reason){
    state.lastCloseCode=Number(code||0); state.lastCloseReason=String(reason||'');
    const friendly={1000:'Normal kapanış',1001:'Sunucu veya proxy bağlantıyı kapattı',1002:'WebSocket protokol hatası',1003:'Desteklenmeyen veri',1006:'Ağ/proxy bağlantısı kesildi',1008:'Sunucu güvenlik politikası bağlantıyı reddetti',1011:'Sunucuda beklenmeyen hata'};
    return friendly[code] || (reason ? `Kod ${code}: ${reason}` : `Kod ${code}`);
  }

  function connect(){
    if (!token) { location.href='giris.php'; return; }
    if (state.connecting || state.connected) return;
    const candidates=gameEndpointCandidates();
    if(!candidates.length){ setStatus('SUNUCU YAPILANDIRILMAMIŞ',false); message('Oyun sunucusu tanımlı değil. Aynı alan adında WebSocket proxy kullanabilir veya config.php içindeki SA_GAME_SERVER değerini belirtebilirsin.'); return; }
    state.connecting=true; state.manualClose=false; state.connectAttempt++; setStatus('BAĞLANIYOR',false); message(`Oyun sunucusuna bağlanılıyor… (${state.connectAttempt}. deneme)`);

    let index=0, settled=false;
    const tryNext=()=>{
      if(index>=candidates.length){
        state.connecting=false; state.connected=false; setStatus('BAĞLANTI HATASI',false);
        const diag=closeDiagnostic(state.lastCloseCode,state.lastCloseReason);
        message(`Sunucu bağlantısı kurulamadı • ${diag}. Tekrar EŞLEŞMEYE KATIL ile deneyebilirsin.`);
        return;
      }
      const endpoint=candidates[index++];
      let ws;
      try{ ws=new WebSocket(endpoint); }catch(_){ state.lastCloseCode=1006; state.lastCloseReason='WebSocket oluşturulamadı'; tryNext(); return; }
      state.socket=ws;
      ws.addEventListener('open',()=>{
        settled=true; state.connecting=false; state.connected=true; state.lastCloseCode=0; state.lastCloseReason=''; setStatus('CANLI',true); openMatch();
        state.connectionStage='authenticating';
        send({t:'auth',token,mode:state.mode,version:VERSION,client:'web'});
        clearTimeout(state.authWatchdog);
        state.authWatchdog=setTimeout(()=>{ if(state.connected && !state.authenticated){ setStatus('AUTH BEKLENİYOR',false); message('Sunucu bağlantısı açık fakat kimlik doğrulama yanıtı gelmedi. Node oyun sunucusunun logunu kontrol edin.'); } },8000);
      });
      ws.addEventListener('message',ev=>{ try{ handleMessage(JSON.parse(ev.data)); }catch(_){ setStatus('PROTOKOL HATASI',false); message('Sunucudan geçersiz paket geldi.'); }});
      ws.addEventListener('error',()=>{ if(!settled) { state.lastCloseReason='WebSocket error'; } setStatus('BAĞLANTI SORUNU',false); });
      ws.addEventListener('close',ev=>{
        if(state.socket===ws) state.socket=null;
        state.connected=false; state.connecting=false;
        const diag=closeDiagnostic(ev.code,ev.reason);
        if(!settled && index<candidates.length){ settled=false; state.connecting=true; setStatus('SUNUCU DEĞİŞTİRİLİYOR',false); setTimeout(tryNext,180); return; }
        if(!state.ended && !state.manualClose){
          const retryable=[1006,1012,1013,1014].includes(Number(ev.code));
          if(retryable && state.connectAttempt<3){
            const delay=700*state.connectAttempt;
            setStatus('YENİDEN BAĞLANIYOR',false); message(`Bağlantı yenileniyor • ${diag}`);
            setTimeout(()=>{ if(!state.connected && !state.ended && !state.manualClose) connect(); },delay);
          }else{
            setStatus('BAĞLANTI KAPANDI',false); message(`Sunucu bağlantısı kapandı • ${diag}. Sayfayı yenilemeden EŞLEŞMEYE KAT ile yeniden deneyebilirsin.`);
          }
        }
      });
    };
    tryNext();
  }

  function send(data){
    if(!state.socket || state.socket.readyState!==WebSocket.OPEN) return false;
    try{ state.socket.send(JSON.stringify(data)); return true; }catch(_){ return false; }
  }

  function handleMessage(m){
    switch(m.t){
      case 'auth_ok': clearTimeout(state.authWatchdog); state.authWatchdog=null; state.authenticated=true; state.connectionStage='authenticated'; message(m.message||'Sunucu kimliği doğrulandı • eşleşme aranıyor…'); break;
      case 'queue': state.connectionStage='queue'; message(m.message||'Eşleşme aranıyor…'); break;
      case 'match_found': state.room=m.room; state.team=m.team; state.localId=m.playerId||null; state.teamClan=m.map?.teamClan||{}; state.teamClanName=m.map?.teamClanName||{}; $('halfState').textContent='HAZIR'; message(`Maç bulundu • ${m.mode==='klan'?'10v10 Klan Savaşı':'5v5 Normal'}`); break;
      case 'match_start':
        state.room=m.room; state.team=m.team; state.localId=m.playerId||null; state.teamClan=m.map?.teamClan||state.teamClan||{}; state.teamClanName=m.map?.teamClanName||state.teamClanName||{}; state.started=true; state.ended=false; state.remainingMs=Number(m.durationMs||900000); state.score=m.score||{A:0,B:0}; state.map=m.map; updateMapUi(m.map); message('Maç başladı • ilk silah merkezden düşecek.'); break;
      case 'snapshot': applySnapshot(m); break;
      case 'event': handleEvent(m); break;
      case 'attack': state.attackStyles.set(String(m.playerId), m.style || (m.kind==='weapon'?'shoot':'punch')); addFx({kind:m.kind||'attack',playerId:m.playerId,weapon:m.weapon,style:m.style,until:performance.now()+300}); break;
      case 'kill': handleKill(m); break;
      case 'respawn': addFx({kind:'respawn',playerId:m.playerId,until:performance.now()+500}); break;
      case 'chat': addChat(m); break;
      case 'half_pause': state.paused=true; state.pauseRemainingMs=Number(m.durationMs||5000); state.halfUntil=performance.now()+state.pauseRemainingMs; $('halfOverlay').hidden=false; $('halfText').textContent=m.message||'Takımlar ve skorlar değişiyor.'; $('halfCountdown').textContent='5'; break;
      case 'half_swap': state.paused=false; state.pauseRemainingMs=0; state.score=m.score||state.score; $('halfOverlay').hidden=true; addFx({kind:'swap',until:performance.now()+900}); break;
      case 'map_change': state.map=m.map; updateMapUi(m.map); addSystemLine(`Harita değişti • ${m.map?.name||'Yeni harita'}`); break;
      case 'system': addSystemLine(m.message); break;
      case 'match_end':
        state.ended=true; state.score=m.score||state.score; $('winnerText').textContent=m.winnerTeam?`Takım ${m.winnerTeam==='A'?'MAVİ':'KIRMIZI'} KAZANDI`:'BERABERE'; $('finalScoreText').textContent=`${state.score.A} — ${state.score.B}`; $('matchEndOverlay').hidden=false; break;
      case 'lobby': setTimeout(backLobby,350); break;
      case 'reconnect': state.room=m.room; state.team=m.team; state.localId=m.playerId||state.localId||null; state.started=true; state.teamClan=m.map?.teamClan||state.teamClan||{}; state.teamClanName=m.map?.teamClanName||state.teamClanName||{}; state.map=m.map; updateMapUi(m.map); break;
      case 'error': state.connectionStage='error'; setStatus('HATA',false); message(`${m.message||'Oyun sunucusu bir hata bildirdi.'}${m.code?` (kod ${m.code})`:''}`); break;
      case 'pong': state.serverOffset=Number(m.serverTime||Date.now())-Date.now(); break;
      default: break;
    }
  }

  function applySnapshot(m){
    state.lastSnapshotAt=performance.now(); state.remainingMs=Number(m.remainingMs||0); state.paused=!!m.paused; state.pauseRemainingMs=Number(m.pauseRemainingMs||0); state.score=m.score||state.score; state.map=state.map || mapById(m.mapId); state.serverOffset=Number(m.serverTime||Date.now())-Date.now();
    if (m.mapId && (!state.map || state.map.id!==m.mapId)) { state.map=mapById(m.mapId); }
    if(m.teamClan) state.teamClan=m.teamClan; if(m.teamClanName) state.teamClanName=m.teamClanName;
    updateMapUi(state.map);
    const seen=new Set();
    for(const p of (m.players||[])){
      const id=String(p.id); seen.add(id); const prev=state.players.get(id); const next={...p}; state.players.set(id,next);
      if (!prev) state.renderPlayers.set(id,{...next});
      state.renderPlayers.get(id).target=next;
    }
    for(const id of state.players.keys()){ if(!seen.has(id)){ state.players.delete(id); state.renderPlayers.delete(id); }}
    const currentLocal = state.localId ? state.players.get(String(state.localId)) : null; if(currentLocal?.team) state.team=currentLocal.team;
    state.localId = state.localId || [...state.players.values()].find(p=>!p.bot && (p.team===state.team || p.id===state.team))?.id || null;
    state.bullets=Array.isArray(m.bullets)?m.bullets:[]; state.pickups=Array.isArray(m.pickups)?m.pickups:[]; state.killFeed=Array.isArray(m.killFeed)?m.killFeed:state.killFeed;
    renderKillFeed(); updateHud();
  }

  function handleEvent(m){
    addFx({kind:m.event,playerId:m.playerId,targetId:m.targetId,x:m.x,y:m.y,weapon:m.weapon,until:performance.now()+500});
    if(m.event==='pickup' && String(m.playerId)===String(state.localId)){ addSystemLine(`${m.weapon||'Silah'} alındı • ${m.ammo} mermi`); }
    if(m.event==='drop') addSystemLine(`${m.player||'Oyuncu'} silah bıraktı.`);
  }
  function handleKill(m){
    state.score=m.score||state.score; addFx({kind:'death',playerId:m.victim?.id,until:performance.now()+800}); if(String(m.victim?.id)===String(state.localId)){ state.spectatorTarget=String(m.killer?.id||[...state.renderPlayers.values()].find(p=>String(p.id)!==String(state.localId)&&Number(p.deadUntil||0)<=Date.now()+state.serverOffset)?.id||''); } renderKillFeed(); updateHud(); }

  function addFx(f){ state.fx.push(f); }
  function updateHud(){
    const p=localPlayer(); if(!p) return;
    $('playerName').textContent=p.name||'Oyuncu'; $('playerClan').textContent=p.clanTag?`[${p.clanTag}]`:p.clan||''; $('playerHpText').textContent=`${Math.max(0,Math.round(p.hp||0))} HP`;
    $('playerKills').textContent=`${p.kills||0} KILL`; $('playerDeaths').textContent=`${p.deaths||0} ÖLÜM`;
    $('scoreA').textContent=state.score.A||0; $('scoreB').textContent=state.score.B||0;
    const clanNames=state.teamClanName || state.map?.teamClanName || state.map?.teamClan || {};
    $('teamALabel').textContent=state.mode==='klan'?(clanNames.A||'MAVİ'):'MAVİ'; $('teamBLabel').textContent=state.mode==='klan'?(clanNames.B||'KIRMIZI'):'KIRMIZI';
    const bar=$('.sa51-hp span'); if(bar) bar.style.width=`${Math.max(0,Math.min(100,p.hp||0))}%`;
    const weapon=WEAPONS[p.weapon]; $('playerWeaponName').textContent=weapon?weapon[0]:'SİLAHSIZ'; $('playerAmmo').textContent=weapon?String(p.ammo??0):'—';
    const wi=$('playerWeaponImage'); wi.hidden=!weapon; if(weapon){ wi.src=asset('weapons/'+weapon[1]); }
    const sprite=p.team==='B'?'red_idle.png':'blue_idle.png'; $('playerHudSprite').src=asset('characters/'+sprite);
    if(p.deadUntil && Number(p.deadUntil)>Date.now()+state.serverOffset){ $('spectatorOverlay').hidden=false; const left=Math.ceil((Number(p.deadUntil)-(Date.now()+state.serverOffset))/1000); $('spectatorText').textContent=`${Math.max(0,left)} saniye seyirci modundasın.`; } else $('spectatorOverlay').hidden=true;
  }

  function updateMapUi(map){ const m=map?.id?map:mapById(map?.id||map); $('mapName').textContent=m?.name||m?.[1]||'—'; }
  function renderKillFeed(){
    const box=$('killFeed'); if(!box) return; box.replaceChildren(); const list=state.killFeed.slice(-6).reverse();
    list.forEach(k=>{ const d=document.createElement('div'); d.className='sa51-kill'; const a=document.createElement('span');a.className='a';a.textContent=k.killer||'Çevre'; const w=document.createElement('span');w.className='w';w.textContent=` ${k.weapon||'—'} → `; const v=document.createElement('span');v.className='v';v.textContent=k.victim||'Oyuncu'; d.append(a,w,v); box.append(d); });
  }

  function addChat(m){
    if(String(m.userId)!=='system' && state.muted.has(String(m.userId))) return;
    const box=$('chatMessages'); if(!box) return;
    const line=document.createElement('div'); line.className='sa51-chat-line'; line.dataset.channel=m.channel||'all';
    const tag=document.createElement('span');tag.className='tag';tag.textContent=m.clanTag?`[${m.clanTag}]`:'';
    const n=document.createElement('span');n.className='n';n.textContent=m.username||'Oyuncu';
    const msg=document.createElement('span');msg.className='msg';msg.textContent=m.message||'';
    line.append(tag,n,msg);
    if(String(m.userId)!=='system' && String(m.userId)!==String(state.localId)){
      const mute=document.createElement('button'); mute.type='button'; mute.textContent=state.muted.has(String(m.userId))?'🔇':'🔈'; mute.title='Bu oyuncuyu sustur / sesi aç'; mute.style.cssText='border:0;background:transparent;color:#6f8a9a;font-size:10px;margin-left:5px;padding:0;cursor:pointer';
      mute.addEventListener('click',()=>{ const id=String(m.userId); if(state.muted.has(id)) state.muted.delete(id); else state.muted.add(id); localStorage.setItem('sa51_muted',JSON.stringify([...state.muted])); mute.textContent=state.muted.has(id)?'🔇':'🔈'; });
      line.append(mute);
    }
    box.append(line); box.scrollTop=box.scrollHeight;
  }
  function addSystemLine(text){ if(!text) return; addChat({channel:'all',username:'SİSTEM',message:String(text),userId:'system'}); }

  function toggleChat(hidden){ state.chatHidden=hidden; $('gameChat').classList.toggle('is-hidden',hidden); $('chatGhost').style.display=hidden?'block':'none'; }

  function sendChat(){ const text=escText($('chatInput').value).trim(); if(!text) return; send({t:'chat',channel:state.activeChannel,message:text.slice(0,180)}); $('chatInput').value=''; }

  function sendInput(){
    const lp=localPlayer(); if(!lp || state.ended) return;
    state.inputSeq++; send({t:'input',seq:state.inputSeq,...state.input});
  }

  function setKey(code,down){
    if(code==='KeyA'||code==='ArrowLeft') state.input.left=down;
    if(code==='KeyD'||code==='ArrowRight') state.input.right=down;
    if(code==='KeyW'||code==='ArrowUp') state.input.jump=down;
    if(code==='Space') state.input.shoot=down;
    if(code==='KeyS'||code==='ArrowDown') state.input.down=down;
    if(code==='KeyF'&&down) send({t:'drop_weapon'});
    if(code==='KeyE'&&down) send({t:'pickup'});
  }

  function pointerAim(ev){
    const r=canvas.getBoundingClientRect(); const x=((ev.clientX-r.left)/r.width)*canvas.width; const y=((ev.clientY-r.top)/r.height)*canvas.height; const lp=localPlayer(); if(!lp) return;
    const pr=state.renderPlayers.get(String(lp.id)); const worldW=Number(state.map?.width||2048); const camX=Math.max(0,Math.min(worldW-canvas.width,(pr?.x||worldW/2)-canvas.width/2));
    const worldX=camX+x; const worldY=y; state.input.aimX=worldX-(pr?.x||lp.x); state.input.aimY=worldY-((pr?.y||lp.y)-40); if(Math.abs(state.input.aimX)<.01&&Math.abs(state.input.aimY)<.01)state.input.aimX=lp.facing||1;
  }

  function bindTouch(id,key){ const el=$(id); if(!el) return; const on=e=>{e.preventDefault();state.input[key]=true;};const off=e=>{e.preventDefault();state.input[key]=false;};el.addEventListener('pointerdown',on);el.addEventListener('pointerup',off);el.addEventListener('pointercancel',off);el.addEventListener('pointerleave',off); }

  function updateRenderState(){
    const now=performance.now(); const a=Math.min(.45,(now-state.lastSnapshotAt)/60);
    for(const [id,r] of state.renderPlayers){ const t=r.target||r; r.x+=(Number(t.x||0)-r.x)*a; r.y+=(Number(t.y||0)-r.y)*a; r.hp+=(Number(t.hp||0)-r.hp)*Math.min(.6,a+.15); r.vx=t.vx||0; r.vy=t.vy||0; r.team=t.team; r.deadUntil=t.deadUntil; r.weapon=t.weapon; r.ammo=t.ammo; r.facing=t.facing; r.grounded=t.grounded; r.name=t.name; r.kills=t.kills; r.deaths=t.deaths; r.bot=t.bot; r.hitUntil=t.hitUntil; r.attackUntil=t.attackUntil; }
    state.fx=state.fx.filter(f=>f.until>now);
    if(state.paused){ const left=Math.max(0,(state.halfUntil-now)); $('halfCountdown').textContent=String(Math.max(1,Math.ceil(left/1000))); }
  }

  function draw(){
    updateRenderState();
    const map=state.map || mapById('orman'); const worldW=Number(map?.width||2048), worldH=Number(map?.height||720);
    const lp=localPlayer(); const lpRender=lp?state.renderPlayers.get(String(lp.id)):null;
    const spectator=(!lpRender || Number(lp?.deadUntil||0)>Date.now()+state.serverOffset) && state.spectatorTarget ? state.renderPlayers.get(String(state.spectatorTarget)) : null;
    const anchor=spectator||lpRender; const camX=Math.max(0,Math.min(worldW-canvas.width,(anchor?.x||worldW/2)-canvas.width/2));
    ctx.clearRect(0,0,canvas.width,canvas.height); ctx.save(); ctx.translate(-camX,0);
    const bgSrc=String(map?.asset || mapById(map?.id)[2] || ''); const bg=img(bgSrc); drawCover(bg,camX,0,canvas.width,worldH);
    ctx.fillStyle='rgba(3,8,14,.28)';ctx.fillRect(camX,0,canvas.width,worldH);
    drawAtmosphere(camX, worldW, worldH, map?.id || 'orman');

    drawPlatforms(map);
    drawPickups(); drawBullets(); drawPlayers(); drawFx();
    ctx.restore();
    $('timer').textContent=formatTime(state.remainingMs); $('halfState').textContent=state.paused?'DURAKLATILDI':(state.started?'CANLI':'HAZIR'); $('scoreA').textContent=state.score.A||0; $('scoreB').textContent=state.score.B||0; updateHud();
    requestAnimationFrame(draw);
  }

  function drawCover(im,x,y,w,h){
    if(!im || !im.complete || !im.naturalWidth || !im.naturalHeight) return false;
    const scale=Math.max(w/im.naturalWidth,h/im.naturalHeight);
    const dw=im.naturalWidth*scale, dh=im.naturalHeight*scale;
    ctx.drawImage(im,x+(w-dw)/2,y+(h-dh)/2,dw,dh); return true;
  }
  function drawAtmosphere(x,w,h,mapId){
    const themes={
      orman:['rgba(0,225,255,.10)','rgba(0,0,0,.28)'],gece_ormani:['rgba(70,130,255,.12)','rgba(0,0,0,.30)'],sehir_gece:['rgba(255,0,150,.10)','rgba(0,0,0,.30)'],
      liman:['rgba(0,190,255,.10)','rgba(10,0,30,.28)'],askeri_us:['rgba(90,255,180,.08)','rgba(0,10,10,.30)'],col_bolgesi:['rgba(255,120,40,.11)','rgba(30,0,0,.28)'],
      sehir_insaati:['rgba(80,160,255,.10)','rgba(0,0,20,.30)'],karli_daglar:['rgba(190,120,255,.10)','rgba(0,0,20,.30)'],uzay_istasyonu:['rgba(0,230,255,.12)','rgba(0,0,24,.30)'],harabe:['rgba(130,180,255,.08)','rgba(0,0,10,.34)']
    };
    const [glow,shade]=themes[mapId]||themes.orman;
    const g=ctx.createRadialGradient(x+w*.5,h*.28,10,x+w*.5,h*.48,w*.72); g.addColorStop(0,glow);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(x,0,w,h);
    ctx.fillStyle=shade;ctx.fillRect(x,0,w,h);
  }
  function drawPlatformPanel(p, accent){
    const grad=ctx.createLinearGradient(p.x,p.y,p.x,p.y+p.h);grad.addColorStop(0,'rgba(45,54,68,.96)');grad.addColorStop(1,'rgba(10,16,24,.98)');ctx.fillStyle=grad;ctx.fillRect(p.x,p.y,p.w,p.h);
    ctx.fillStyle=accent;ctx.fillRect(p.x,p.y,p.w,3);ctx.fillStyle='rgba(255,255,255,.07)';ctx.fillRect(p.x,p.y+3,p.w,1);
    ctx.strokeStyle='rgba(255,255,255,.08)';ctx.lineWidth=1;for(let x=p.x+18;x<p.x+p.w;x+=38){ctx.beginPath();ctx.moveTo(x,p.y+5);ctx.lineTo(x,p.y+p.h-4);ctx.stroke();}
    if(p.type==='crate'){ctx.strokeStyle='rgba(255,255,255,.16)';ctx.strokeRect(p.x+5,p.y+5,p.w-10,p.h-10);}
    if(p.type==='tower'){ctx.fillStyle='rgba(0,0,0,.22)';ctx.fillRect(p.x+8,p.y+8,p.w-16,p.h-16);}
    if(p.type==='bridge'){ctx.fillStyle='rgba(0,0,0,.22)';for(let x=p.x+10;x<p.x+p.w-6;x+=28)ctx.fillRect(x,p.y+8,8,Math.max(4,p.h-14));}
  }
  function drawPlatforms(map){
    (map.platforms||[]).forEach(p=>{const accent=p.type==='crate'?'#ffcf5a':p.type==='bridge'?'#00e7ff':p.type==='tower'?'#bb8cff':'#5fe6ff';drawPlatformPanel(p,accent);});
  }
  function weaponImage(id){ return WEAPONS[id]?.[1] ? img(WEAPONS[id][1]) : null; }
  function drawWeaponSprite(im,x,y,w,h,kind,flip=false){
    if(!im || !im.complete || !im.naturalWidth) return;
    const filters={gold:'saturate(1.4) brightness(1.2)',fire:'sepia(1) saturate(4) hue-rotate(-25deg)',ice:'saturate(.7) hue-rotate(145deg) brightness(1.1)',dark:'grayscale(.6) brightness(.55)',neon:'saturate(2) hue-rotate(100deg) brightness(1.15)',smg:'saturate(.9) brightness(1.05)'};
    ctx.save();ctx.imageSmoothingEnabled=false;ctx.filter=filters[kind]||'none';if(flip){ctx.translate(x+w,y);ctx.scale(-1,1);ctx.drawImage(im,0,0,w,h);}else ctx.drawImage(im,x,y,w,h);ctx.restore();
  }
  function drawPickups(){
    state.pickups.forEach(d=>{if(d.state!=='ready'&&d.state!=='falling')return;const w=WEAPONS[d.weapon];if(!w)return;const im=weaponImage(d.weapon);const phase=Math.sin(performance.now()/220+d.x*.01)*3;drawWeaponSprite(im,d.x-34,d.y-20+phase,68,38,w[2],false);ctx.save();ctx.textAlign='center';ctx.font='700 9px Arial';ctx.fillStyle='#eefaff';ctx.shadowColor='#000';ctx.shadowBlur=5;ctx.fillText(`${w[0]}  •  ${d.state==='ready'?'E':'↓'}`,d.x,d.y-30);ctx.restore();});
  }
  function drawBullets(){state.bullets.forEach(b=>{const c=b.team==='A'?'#66e8ff':'#ff6880';ctx.save();ctx.fillStyle=c;ctx.shadowColor=c;ctx.shadowBlur=14;ctx.beginPath();ctx.arc(Number(b.x),Number(b.y),Number(b.radius||4),0,Math.PI*2);ctx.fill();ctx.restore();});}
  function charFrame(p){
    const action=(p.attackUntil||0)>Date.now()+state.serverOffset?'shoot':((p.hitUntil||0)>Date.now()+state.serverOffset?'hit':(Math.abs(p.vy)>100&&!p.grounded?'jump':(Math.abs(p.vx)>60?'run':'idle')));
    const frame=Math.floor(performance.now()/120)%6;
    const rows={idle:0,run:0,jump:1,shoot:2,hit:3}; const row=rows[action]??0; return {x:frame*16,y:row*16,w:16,h:16};
  }
  function drawPlayerGlow(p){const c=p.team==='A'?'#37e8ff':'#ff5278';ctx.save();ctx.globalAlpha=.20;ctx.shadowColor=c;ctx.shadowBlur=18;ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(p.x,p.y-40,20,30,0,0,Math.PI*2);ctx.fill();ctx.restore();}
  function drawPlayers(){
    const tNow=Date.now()+state.serverOffset;
    for(const p of state.renderPlayers.values()){
      if(Number(p.deadUntil||0)>tNow) continue;
      const im=img(CHARACTER_SHEETS[p.team==='B'?'B':'A']);const f=charFrame(p);const w=64,h=64;drawPlayerGlow(p);
      if(im.complete&&im.naturalWidth){ctx.save();ctx.translate(p.x,p.y-4);if((p.facing||1)<0)ctx.scale(-1,1);ctx.imageSmoothingEnabled=false;ctx.drawImage(im,f.x,f.y,f.w,f.h,-w/2,-h,w,h);ctx.globalCompositeOperation='source-atop';ctx.fillStyle=p.team==='B'?'rgba(255,60,100,.30)':'rgba(0,185,255,.26)';ctx.fillRect(-w/2,-h,w,h);ctx.restore();}
      ctx.textAlign='center';ctx.font='700 10px Arial';ctx.fillStyle=p.team==='A'?'#d7fbff':'#ffd6df';ctx.shadowColor='#000';ctx.shadowBlur=5;ctx.fillText((p.bot?'BOT • ':'')+String(p.name||'Oyuncu'),p.x,p.y-h-10);ctx.shadowBlur=0;
      ctx.fillStyle='rgba(0,0,0,.62)';ctx.fillRect(p.x-24,p.y-h-3,48,5);ctx.fillStyle=p.team==='A'?'#51e4ff':'#ff557a';ctx.fillRect(p.x-24,p.y-h-3,48*Math.max(0,Math.min(1,Number(p.hp||0)/100)),5);
      if(p.weapon&&WEAPONS[p.weapon]){const imw=weaponImage(p.weapon);const kind=WEAPONS[p.weapon][2];const ww=p.weapon==='roketatar'||p.weapon==='karanlik_silah'?70:58;const hh=30;drawWeaponSprite(imw,p.x+(p.facing||1)*16-ww/2,p.y-52,ww,hh,kind,(p.facing||1)<0);}
    }
  }
  function drawFx(){
    state.fx.forEach(f=>{let x=f.x,y=f.y;const p=f.playerId?state.renderPlayers.get(String(f.playerId)):null;if(p){x=p.x;y=p.y-42;}if(!Number.isFinite(x)||!Number.isFinite(y))return;const a=Math.max(.1,Math.min(1,(f.until-performance.now())/500));ctx.save();ctx.globalAlpha=a;ctx.strokeStyle=f.kind==='hit'?'#fff2a6':f.kind==='death'?'#ff5473':'#64efff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,18+(1-a)*20,0,Math.PI*2);ctx.stroke();ctx.lineWidth=2;for(let i=0;i<8;i++){const ang=i*Math.PI/4;const r=12+(1-a)*25;ctx.beginPath();ctx.moveTo(x+Math.cos(ang)*r,y+Math.sin(ang)*r);ctx.lineTo(x+Math.cos(ang)*(r+10),y+Math.sin(ang)*(r+10));ctx.stroke();}ctx.restore();});
  }

  document.querySelectorAll('.sa51-mode-card').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
  $('playBtn')?.addEventListener('click',connect);
  $('fullscreenBtn')?.addEventListener('click',toggleFullscreen);
  $('backLobbyBtn')?.addEventListener('click',backLobby);
  $('spectatorNext')?.addEventListener('click',()=>{
    const arr=[...state.renderPlayers.values()].filter(p=>Number(p.deadUntil||0)<=Date.now()+state.serverOffset && String(p.id)!==String(state.localId)); if(!arr.length)return; const i=Math.max(0,arr.findIndex(p=>String(p.id)===String(state.spectatorTarget))); state.spectatorTarget=String(arr[(i+1)%arr.length].id);
  });
  $('chatToggleBtn')?.addEventListener('click',()=>toggleChat(true)); $('chatShowBtn')?.addEventListener('click',()=>toggleChat(false)); $('emojiBtn')?.addEventListener('click',()=>{ $('emojiPicker').hidden=!$('emojiPicker').hidden; }); $('clearChatBtn')?.addEventListener('click',()=>{$('chatMessages').replaceChildren();});
  $('chatForm')?.addEventListener('submit',e=>{e.preventDefault();sendChat();});
  $('chatTabs')?.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;state.activeChannel=b.dataset.channel||'all';document.querySelectorAll('.sa51-chat-tabs button').forEach(x=>x.classList.toggle('active',x===b));});
  window.addEventListener('keydown',e=>{ if(['INPUT','TEXTAREA'].includes(e.target.tagName))return; if(e.code==='Escape'&&document.fullscreenElement){document.exitFullscreen().catch(()=>{});return;} if(e.repeat&&['KeyF','KeyE'].includes(e.code))return;setKey(e.code,true);});
  window.addEventListener('keyup',e=>{ if(['INPUT','TEXTAREA'].includes(e.target.tagName))return;setKey(e.code,false);});
  canvas.addEventListener('pointermove',e=>pointerAim(e));
  canvas.addEventListener('pointerdown',e=>{ if(e.pointerType==='touch'){ pointerAim(e); state.input.shoot=true; } });
  canvas.addEventListener('pointerup',e=>{ if(e.pointerType==='touch'){ state.input.shoot=false; } });
  bindTouch('touchLeft','left');bindTouch('touchRight','right');bindTouch('touchJump','jump');bindTouch('touchShoot','shoot'); $('touchPickup')?.addEventListener('pointerdown',e=>{e.preventDefault();send({t:'pickup'});});
  $('touchDrop')?.addEventListener('pointerdown',e=>{e.preventDefault();send({t:'drop_weapon'});});
  window.addEventListener('blur',()=>{state.input.left=false;state.input.right=false;state.input.jump=false;state.input.shoot=false;});
  window.addEventListener('orientationchange',()=>{ if(window.innerWidth>window.innerHeight) $('rotateHint').hidden=true; else $('rotateHint').hidden=false; });
  setInterval(sendInput,50);
  setInterval(()=>{if(state.connected)send({t:'ping',clientTime:Date.now()});},5000);
  setInterval(()=>{ if(state.paused){const left=Math.max(0,state.halfUntil-performance.now());state.pauseRemainingMs=left;$('halfCountdown').textContent=String(Math.max(1,Math.ceil(left/1000)));} },100);
  window.addEventListener('beforeunload',()=>{try{state.socket?.close(1000,'sayfa');}catch(_){}});

  buildLobby(); setMode('normal'); setStatus('HAZIR',true); requestAnimationFrame(draw);
})();
