(() => {
'use strict';
window.__SA_GAME_BOOTED = true;
const canvas = document.getElementById('oyun');
if (!canvas) throw new Error('Canvas #oyun bulunamadı.');
const ctx = canvas.getContext('2d');
canvas.width=1280; canvas.height=720;
ctx.imageSmoothingEnabled = true;
if (!ctx) throw new Error('Canvas 2D motoru kullanılamıyor.');

let token=''; try { token=localStorage.getItem('stickarena_token')||''; } catch(e) {}
const guestMode=!token;
const qs=new URLSearchParams(location.search);
const GAME_MODE=qs.get('mod')==='klan'?'clan':'normal';
let selectedOpponentMode=(qs.get('rakip')==='bot'?'bot':'real');
const TEAM_SIZE=GAME_MODE==='clan'?10:5, MAX_PLAYERS=TEAM_SIZE*2, MATCH=900;
const W=3200,H=720,G=620,API='api.php',VERSION='5.15.2';
const ASSET_VERSION='5.15.2';
const FIXED_DT=1/60, MAX_FRAME_DELTA=.10, NET_HEARTBEAT_MS=140, REMOTE_POLL_MS=260, SCORE_POLL_MS=180, KILLFEED_POLL_MS=220;
const MOVE_CFG={speed:470,accel:6200,brake:8200,jump:640,gravity:1750,netSnap:360};
const AUDIO_FILES={pistol:'pistol.wav',m4a1:'m4a1.wav',awp:'awp.wav',uzi:'uzi.wav',mp5:'mp5.wav',ak47:'ak47.wav',deagle:'deagle.wav',vector:'vector.wav',p90:'p90.wav',shotgun:'shotgun.wav',rocket:'rocket.wav',hit:'hit.wav',kill:'explosion.wav',reload:'reload.wav'};
const AUDIO_PATH='assets/audio/classic/';
const AUTO_MAP_INTERVAL=180; // 3 dakika
const MAP_ORDER=['col_bolgesi','sehir_insaati','uzay_istasyonu','askeri_us','orman','gece_ormani','sehir_gece','liman','harabe','karli_daglar'];
const MAPS={
 col_bolgesi:{ad:'DUNE SECTOR',img:'assets/sprites/maps/v55/col_bolgesi.jpg'},
 sehir_insaati:{ad:'MEGACITY VANTAGE',img:'assets/sprites/maps/v55/sehir_insaati.jpg'},
 uzay_istasyonu:{ad:'ORBITAL DOCK',img:'assets/sprites/maps/v55/uzay_istasyonu.jpg'},
 askeri_us:{ad:'BLACKSITE 09',img:'assets/sprites/maps/v55/askeri_us.jpg'},
 orman:{ad:'VERDANT CORE',img:'assets/sprites/maps/v55/orman.jpg'},
 gece_ormani:{ad:'NIGHTFALL GROVE',img:'assets/sprites/maps/v55/gece_ormani.jpg'},
 sehir_gece:{ad:'NEON DISTRICT',img:'assets/sprites/maps/v55/sehir_gece.jpg'},
 liman:{ad:'PORT VANTA',img:'assets/sprites/maps/v55/liman.jpg'},
 harabe:{ad:'RUINED SECTOR',img:'assets/sprites/maps/v55/harabe.jpg'},
 karli_daglar:{ad:'FROSTLINE',img:'assets/sprites/maps/v55/karli_daglar.jpg'}
};
const CHARACTER_FILES={red:'red.png',blue:'blue.png',gold:'gold.png'};
const TEAM_SPAWN_ZONES={A:{xMin:170,xMax:430,y:592},B:{xMin:3040,xMax:3160,y:592}};
const WEAPON_DROP_TTL=40;
const BOT_ACCURACY=0.62;
const BOT_MIN_AIM_ERROR=0.045;
const BOT_MAX_AIM_ERROR=0.115;
const CHARACTER_RENDER_SIZE=180;
const CHARACTER_GROUND_OFFSET=28;
function getSpawnPoint(team){const z=TEAM_SPAWN_ZONES[team==='B'?'B':'A'];return {x:rnd(z.xMin,z.xMax),y:z.y};}
function normalizeCharacterId(id,team){const k=String(id||'').trim().toLowerCase();if(['gold','altin','goldkarakter'].includes(k))return 'gold';if(['blue','mavi'].includes(k))return 'blue';if(['red','kirmizi'].includes(k))return 'red';return team==='B'?'blue':'red';}
const WEAPONS={
 m4a1:{ad:'M4A1',damage:34,cooldown:155,range:1850,img:'m4a1.png',color:'#d8ecff',sound:'m4a1',ammo:30},
 awp:{ad:'AWP',damage:90,cooldown:1000,range:2600,img:'awp.png',color:'#c7d8ff',sound:'awp',ammo:8},
 rpg:{ad:'RPG',damage:100,cooldown:1150,range:1900,img:'rpg.png',color:'#ff765d',sound:'rocket',ammo:5},
 uzi:{ad:'UZI',damage:22,cooldown:90,range:1250,img:'uzi.png',color:'#d4e4ef',sound:'uzi',ammo:32},
 mp5:{ad:'MP5',damage:24,cooldown:105,range:1450,img:'mp5.png',color:'#99b9cf',sound:'mp5',ammo:30},
 ak47:{ad:'AK-47',damage:36,cooldown:165,range:1750,img:'ak47.png',color:'#c5ae83',sound:'ak47',ammo:30},
 shotgun:{ad:'POMPALI',damage:65,cooldown:650,range:850,img:'shotgun.png',color:'#ffb37d',sound:'shotgun',ammo:8},
 pistol:{ad:'TABANCA',damage:28,cooldown:260,range:1250,img:'pistol.png',color:'#d8ecff',sound:'pistol',ammo:15},
 deagle:{ad:'DESERT EAGLE',damage:55,cooldown:420,range:1450,img:'deagle.png',color:'#f2d36c',sound:'deagle',ammo:7},
 vector:{ad:'VECTOR',damage:20,cooldown:80,range:1200,img:'vector.png',color:'#8fd9ff',sound:'vector',ammo:30},
 p90:{ad:'P90',damage:21,cooldown:92,range:1350,img:'p90.png',color:'#a5c8da',sound:'p90',ammo:30}
};
const WEAPON_SIZES={m4a1:[108,34],awp:[138,29],rpg:[128,34],uzi:[82,30],mp5:[92,31],ak47:[106,34],shotgun:[110,32],pistol:[66,28],deagle:[74,30],vector:[84,30],p90:[98,31]};
const DROP_ITEMS=Object.keys(WEAPONS);
const MAX_HP=100,MAX_AMMO=32,RESPAWN_DELAY=10,SPAWN_PROTECTION_MS=3000;
const KILL_XP=100,MAX_LEVEL=100,XP_PER_LEVEL=100,LEVEL_POPUP_MS=3000;
const WEAPON_DAMAGE=8;
const DEFAULT_PLATFORMS=[{x:0,y:620,w:720,h:40},{x:780,y:565,w:280,h:30},{x:850,y:470,w:450,h:35},{x:1200,y:350,w:230,h:28},{x:1420,y:430,w:380,h:35},{x:1600,y:250,w:230,h:28},{x:1840,y:360,w:220,h:28},{x:1980,y:540,w:520,h:35},{x:2180,y:420,w:250,h:30},{x:2500,y:330,w:240,h:28},{x:2700,y:450,w:500,h:35},{x:1050,y:280,w:260,h:30},{x:620,y:220,w:220,h:28}];
let currentMap='col_bolgesi',mapPlatforms=DEFAULT_PLATFORMS,startedAt=0,finished=false,roomId='',remoteReady=false,remoteConnecting=false,lastRemoteTry=0,lastSync=0,lastVotePoll=0,shootCooldown=0,lastAutoMapRound=-1;
let serverScoreA=0,serverScoreB=0,spectatorTargetId=0,spectatorSince=0;
let gameRafId=0,lastFrameAt=0,lastRenderAt=0,mapSurfaceId='',mapSurface=null,cameraX=0;
let lobbyId='',lobbyPolling=false,lobbyJoined=false,matchStarted=false,paused=false,serverRemaining=MATCH,lastChatPoll=0,lastRemoteStatePoll=0,chatLastId=0,lastAdminAnnouncementChatId=0,teamSwapped=false,selectedTeam='A';
let localNetCorrectionX=0,localNetCorrectionY=0;
let adminGamemode=false;
let lastAnnouncementId=0;
let movementBlocked=false;
let teamSwapPending=false,teamSwapNoticeUntil=0,matchEndNoticeUntil=0;
let syncInFlight=false,scorePollInFlight=false,lastScorePoll=0,lastScoreRevision=-1,scoreboardOpen=false,lastKillFeedPoll=0,lastKillFeedId=0,killFeedCache=[];
let keys={left:false,right:false,up:false,down:false,attack:false}; let mouse={x:canvas.width/2,y:canvas.height/2,down:false,active:false};
let equipment={karakter:'red',silah:null,efekt:'yok'};
let progressUiReady=false,levelPopupTimer=0,lastHudUiAt=0,lastScoreHudAt=0;
let players=[],bullets=[],particles=[],messages=[],pickups=[];
let nextDropAt=0,lastDeathSeq=0,deathOverlaySeq=0;
let mutedPlayers=new Set(); try{JSON.parse(localStorage.getItem('sa_muted_players')||'[]').forEach(x=>mutedPlayers.add(Number(x)))}catch(e){}
let deathOverlayUntil=0; let soundReady=false;
const audioBank={}; let audioBankReady=false; let chatHidden=false; let systemChat=[]; let lastSystemMsg=''; let lastSystemAt=0; let lastChatRows=[];
const images={chars:{},weapons:{},maps:{},fx:{}};
function loadImage(src){const im=new Image();im.decoding='async';im.loading='eager';im.crossOrigin='anonymous';im.onload=()=>{if(src.includes('/maps/')){mapSurfaceId='';}};im.onerror=()=>{im.__saFailed=true;};im.src=src+(src.includes('?')?'&':'?')+'v='+ASSET_VERSION;return im;}
Object.entries(CHARACTER_FILES).forEach(([k,v])=>images.chars[k]=loadImage('assets/sprites/characters/v518/'+v));
Object.entries(WEAPONS).forEach(([k,v])=>images.weapons[k]=loadImage('assets/sprites/items/v518/'+v.img));
Object.entries(MAPS).forEach(([k,v])=>images.maps[k]=loadImage(v.img));
['muzzle','impact','explosion','smoke'].forEach(k=>images.fx[k]=loadImage('assets/sprites/fx/v55/'+k+'.png'));


function getMapSurface(){
  const id=currentMap;
  const img=images.maps[id];
  if(!img) return null;
  if(mapSurfaceId===id && mapSurface) return mapSurface;
  if(!img.complete || !img.naturalWidth || !img.naturalHeight) return null;
  const surface=document.createElement('canvas');
  surface.width=W; surface.height=H;
  const sctx=surface.getContext('2d');
  if(!sctx) return null;
  sctx.imageSmoothingEnabled=true;
  sctx.imageSmoothingQuality='high';
  sctx.clearRect(0,0,W,H);
  const scale=Math.max(W/img.naturalWidth,H/img.naturalHeight);
  const dw=img.naturalWidth*scale, dh=img.naturalHeight*scale;
  sctx.drawImage(img,(W-dw)/2,(H-dh)/2,dw,dh);
  const g=sctx.createLinearGradient(0,0,0,H);
  g.addColorStop(0,'rgba(3,12,20,.10)');
  g.addColorStop(1,'rgba(2,8,14,.28)');
  sctx.fillStyle=g; sctx.fillRect(0,0,W,H);
  mapSurfaceId=id; mapSurface=surface;
  return surface;
}

function rnd(a,b){return Math.random()*(b-a)+a}
function levelFromXp(xp){return Math.min(MAX_LEVEL,1+Math.floor(Math.max(0,Number(xp)||0)/XP_PER_LEVEL));}
function xpIntoLevel(xp){const n=Math.max(0,Number(xp)||0);if(levelFromXp(n)>=MAX_LEVEL)return XP_PER_LEVEL;return n%XP_PER_LEVEL;}
function ensureProgressUI(){
  if(progressUiReady)return;
  progressUiReady=true;
  if(!document.getElementById('saProgressStyle')){
    const st=document.createElement('style');st.id='saProgressStyle';
    st.textContent=`#saXpHud{position:fixed;left:22px;bottom:96px;width:260px;padding:10px 12px;border:1px solid rgba(90,220,255,.25);border-radius:12px;background:linear-gradient(180deg,rgba(4,16,25,.96),rgba(3,10,17,.92));box-shadow:0 12px 30px rgba(0,0,0,.32),0 0 24px rgba(53,213,255,.08);backdrop-filter:blur(8px);z-index:1200;pointer-events:none;font-family:Inter,Arial,sans-serif;color:#eafaff}.sa-xp-head{display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.sa-xp-level{font-size:18px;font-weight:900;color:#fff}.sa-xp-meta{color:#8fb5c5;font-size:10px}.sa-xp-bar{height:6px;margin-top:8px;border-radius:99px;background:#132a34;overflow:hidden}.sa-xp-fill{height:100%;width:0;background:linear-gradient(90deg,#28dfff,#78f4c5);box-shadow:0 0 12px rgba(40,223,255,.35);transition:width .25s ease}.sa-xp-popup{position:fixed;left:50%;top:38%;transform:translate(-50%,-50%) scale(.86);min-width:360px;padding:24px 34px;border:1px solid rgba(106,232,255,.42);border-radius:18px;background:linear-gradient(145deg,rgba(4,19,30,.97),rgba(2,8,14,.96));box-shadow:0 22px 80px rgba(0,0,0,.58),0 0 50px rgba(42,218,255,.16);z-index:5000;text-align:center;color:#fff;opacity:0;transition:opacity .2s ease,transform .2s ease;font-family:Inter,Arial,sans-serif;pointer-events:none}.sa-xp-popup.show{opacity:1;transform:translate(-50%,-50%) scale(1)}.sa-xp-popup .eyebrow{font-size:11px;font-weight:900;letter-spacing:.25em;color:#79e8ff}.sa-xp-popup .title{margin-top:8px;font-size:32px;font-weight:950;letter-spacing:.04em}.sa-xp-popup .level{margin-top:6px;font-size:56px;line-height:1;color:#fff;text-shadow:0 0 24px rgba(60,223,255,.35)}.sa-xp-popup .gain{margin-top:10px;font-size:13px;color:#a7c7d3;font-weight:700}`;
    document.head.appendChild(st);
  }
  const hud=document.createElement('div');hud.id='saXpHud';hud.innerHTML=`<div class="sa-xp-head"><span>İLERLEME</span><span class="sa-xp-level" id="saXpLevel">LVL 1</span></div><div class="sa-xp-meta" id="saXpMeta">0 XP</div><div class="sa-xp-bar"><div class="sa-xp-fill" id="saXpFill"></div></div>`;document.body.appendChild(hud);
  const pop=document.createElement('div');pop.id='saLevelPopup';pop.className='sa-xp-popup';pop.innerHTML=`<div class="eyebrow">STICK ARENA • LEVEL UP</div><div class="title">SEVİYE ATLADIN!</div><div class="level" id="saLevelNumber">2</div><div class="gain" id="saLevelGain">+100 XP</div>`;document.body.appendChild(pop);
}
function updateProgressUi(){ensureProgressUI();const xp=Math.max(0,Number(me.xp)||0);const level=Math.max(1,Math.min(MAX_LEVEL,Number(me.level)||levelFromXp(xp)));const lv=document.getElementById('saXpLevel');const meta=document.getElementById('saXpMeta');const fill=document.getElementById('saXpFill');if(lv)lv.textContent='LVL '+level;if(meta)meta.textContent=level>=MAX_LEVEL?xp+' XP • MAX LEVEL':xp+' XP • '+xpIntoLevel(xp)+' / '+XP_PER_LEVEL+' XP';if(fill)fill.style.width=(level>=MAX_LEVEL?'100':String(Math.min(100,(xpIntoLevel(xp)/XP_PER_LEVEL)*100)))+'%';}
function showLevelUp(level,gained=KILL_XP){ensureProgressUI();const pop=document.getElementById('saLevelPopup');const num=document.getElementById('saLevelNumber');const gain=document.getElementById('saLevelGain');if(!pop)return;if(num)num.textContent=String(level);if(gain)gain.textContent='+'+gained+' XP • Yeni seviye açıldı';pop.classList.remove('show');void pop.offsetWidth;pop.classList.add('show');clearTimeout(levelPopupTimer);levelPopupTimer=setTimeout(()=>pop.classList.remove('show'),LEVEL_POPUP_MS);}
function applyProgress(r,showPopup=true){if(!r)return;const oldLevel=Math.max(1,Number(me.level)||levelFromXp(me.xp||0));if(r.xp_total!==undefined)me.xp=Math.max(0,Number(r.xp_total));if(r.level!==undefined)me.level=Math.max(1,Math.min(MAX_LEVEL,Number(r.level)));else me.level=levelFromXp(me.xp);updateProgressUi();if(showPopup&&(!r.level_up?me.level>oldLevel:!!r.level_up))showLevelUp(me.level,Number(r.xp_gained||KILL_XP));}

const LEGACY_WEAPON_MAP={tabanca:'pistol',tufek:'m4a1',makineli_tufek:'mp5',pompal_tufek:'shotgun',roketatar:'rpg',keskin_nisanci:'awp',karbon_silah:'vector',karanlik_silah:'p90',neon_silah:'vector',altin_silah:'deagle',alev_silah:'rpg',buz_silah:'awp'};
function normalizeWeaponId(id){const key=String(id||'').trim();return WEAPONS[key]?key:(LEGACY_WEAPON_MAP[key]||'pistol');}
function ammoForWeapon(id){return Number(WEAPONS[normalizeWeaponId(id)]?.ammo||15);}
function rayTarget(p,angle){
  const ux=Math.cos(angle),uy=Math.sin(angle);
  let best=null,bestAlong=Infinity;
  const range=(WEAPONS[normalizeWeaponId(p.weapon)]?.range||1600)+420;
  for(const q of players){
    if(!q||q===p||q.team===p.team||q.respawn>0||q.hp<=0) continue;
    const qx=q.x-p.x;
    const qy=(q.y-74)-(p.y-74);
    const along=qx*ux+qy*uy;
    if(along<0||along>range) continue;
    const perp=Math.abs(qx*uy-qy*ux);
    const allow=q.bot?170:155;
    if(perp<=allow&&along<bestAlong){
      best=q;
      bestAlong=along;
    }
  }
  return best;
}
function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}

function isAdminRole(role){const v=String(role??'').trim().toLowerCase();return ['admin','1','yonetici','yönetici','administrator','superadmin','root'].includes(v);}
function ensureAdminAnnouncementUI(){
  if(document.getElementById('saAdminAnnouncement'))return document.getElementById('saAdminAnnouncement');
  const st=document.createElement('style');st.id='saAdminAnnouncementStyle';
  st.textContent=`#saAdminAnnouncement{position:fixed;left:50%;top:98px;transform:translate(-50%,-8px) scale(.98);width:min(760px,calc(100vw - 28px));padding:11px 16px 13px;border:1px solid rgba(255,205,93,.48);border-radius:12px;background:linear-gradient(180deg,rgba(17,18,25,.96),rgba(8,10,16,.94));box-shadow:0 16px 44px rgba(0,0,0,.4),0 0 26px rgba(255,201,76,.12);z-index:4800;color:#fff;font-family:Inter,Arial,sans-serif;opacity:0;pointer-events:none;transition:opacity .18s ease,transform .18s ease;backdrop-filter:blur(10px)}#saAdminAnnouncement.show{opacity:1;transform:translate(-50%,0) scale(1)}#saAdminAnnouncement .sa-admin-ann-head{display:flex;align-items:center;gap:8px;font-size:10px;font-weight:950;letter-spacing:.16em;text-transform:uppercase;color:#ffd96b}#saAdminAnnouncement .sa-admin-ann-text{margin-top:5px;font-size:14px;line-height:1.45;font-weight:750;color:#f4f8ff;white-space:pre-wrap;overflow-wrap:anywhere}#saAdminAnnouncement .sa-admin-ann-close{position:absolute;right:9px;top:7px;width:24px;height:24px;border:0;border-radius:8px;background:transparent;color:#8f9cad;font-size:16px;cursor:pointer}#saAdminAnnouncement .sa-admin-ann-close:hover{background:rgba(255,255,255,.07);color:#fff}@media(max-width:700px){#saAdminAnnouncement{top:82px;padding:10px 13px 12px}#saAdminAnnouncement .sa-admin-ann-text{font-size:13px}}`;
  document.head.appendChild(st);
  const el=document.createElement('div');el.id='saAdminAnnouncement';el.innerHTML=`<button class="sa-admin-ann-close" aria-label="Duyuruyu kapat">×</button><div class="sa-admin-ann-head">📢 YÖNETİCİ DUYURUSU</div><div class="sa-admin-ann-text"></div>`;
  document.body.appendChild(el);el.querySelector('.sa-admin-ann-close')?.addEventListener('click',()=>el.classList.remove('show'));return el;
}
function positionAdminAnnouncement(){const el=document.getElementById('saAdminAnnouncement');if(!el)return;const panel=document.getElementById('scoreboardPanel');if(panel&&!panel.hidden){const r=panel.getBoundingClientRect();const top=Math.max(70,Math.min(window.innerHeight-100,r.bottom+10));el.style.top=Math.round(top)+'px';}else{el.style.top=window.innerWidth<700?'82px':'98px';}}
function showAdminAnnouncement(text,ms=5200){const msg=String(text??'').trim();if(!msg)return;const el=ensureAdminAnnouncementUI();positionAdminAnnouncement();const t=el.querySelector('.sa-admin-ann-text');if(t)t.textContent=msg;el.classList.remove('show');void el.offsetWidth;el.classList.add('show');clearTimeout(window.__saAdminAnnTimer);window.__saAdminAnnTimer=setTimeout(()=>el.classList.remove('show'),ms);try{audioInit();tone(680,.12,'sine',.045,150);}catch(_){}}
window.addEventListener('resize',()=>{if(document.getElementById('saAdminAnnouncement')?.classList.contains('show'))positionAdminAnnouncement();});
function isSpawnProtected(p){const v=Number(p?.spawnProtectedUntil||p?.spawn_protected_until_ms||0);if(!v)return false;return v>100000000000?v>Date.now():v>performance.now();}
function renderSystemFeed(){const el=document.getElementById('mesajlar');if(el)el.innerHTML=messages.map(x=>'<div>'+esc(x)+'</div>').join('')}
function renderChat(rows=[]){
  const el=document.getElementById('chatMessages'); if(!el)return;
  const serverRows=(rows||[]).filter(x=>!mutedPlayers.has(Number(x.kullanici_id||0))).map(x=>{
    const uid=Number(x.kullanici_id||0);
    const admin=isAdminRole(x.yetki)||(x.admin===true);
    const verified=!!x.dogrulanmis||admin;
    const clan=x.klan_ad?`<span class="clan">[${esc(x.klan_ad)}]</span>`:'';
    const badge=admin?'<span class="verify" title="Yönetici">★</span> ':(verified?'<span class="verify" title="Doğrulanmış oyuncu">✓</span> ':'');
    return {type:'user',id:Number(x.id||0),html:`<div class="sa-chat-message ${admin?'admin':''}" data-uid="${uid}"><div class="sa-chat-line"><b>${badge}${esc(x.kullanici_adi||'Oyuncu')}</b>${clan}: ${esc(x.mesaj)}</div><button class="sa-chat-user-action" data-user="${uid}" data-name="${esc(x.kullanici_adi||'Oyuncu')}" title="Oyuncu seçenekleri">⋯</button></div>`};
  });
  const systemRows=systemChat.map((x,i)=>({type:'system',id:'s'+i,html:`<div class="sa-chat-message system"><span>•</span> ${esc(x)}</div>`}));
  const all=[...systemRows,...serverRows];
  el.innerHTML=all.slice(-60).map(x=>x.html).join(''); el.scrollTop=el.scrollHeight;
  el.querySelectorAll('.sa-chat-user-action').forEach(b=>b.onclick=()=>openChatUserMenu(Number(b.dataset.user),b.dataset.name));
}
function persistMutes(){localStorage.setItem('sa_muted_players',JSON.stringify([...mutedPlayers]));}
function openChatUserMenu(uid,name){if(!uid)return;document.getElementById('saChatUserMenu')?.remove();const box=document.createElement('div');box.id='saChatUserMenu';box.className='sa-chat-user-menu';box.innerHTML=`<strong>${esc(name)}</strong><button data-a="mute">🔇 Sessize al</button><button data-a="unmute">🔊 Sesi aç</button>${me.admin?'<hr><button data-a="gmute">⛔ 10 dk sohbet engeli</button><button data-a="ban">🚫 60 dk ban</button><button data-a="verify">✓ Doğrula</button><button data-a="unverify">✕ Doğrulamayı kaldır</button>':''}<button data-a="close">Kapat</button>`;document.body.appendChild(box);box.querySelectorAll('button').forEach(btn=>btn.onclick=async()=>{const a=btn.dataset.a;if(a==='mute'){mutedPlayers.add(uid);persistMutes();renderChat(lastChatRows);box.remove();return}if(a==='unmute'){mutedPlayers.delete(uid);persistMutes();renderChat(lastChatRows);box.remove();return}if(a==='close'){box.remove();return}if(!me.admin)return;const map={gmute:['mute',10],ban:['ban',60],verify:['verify',0],unverify:['unverify',0]};const cfg=map[a];const r=await api('chat_kullanici_islem',{kullanici_id:uid,islem:cfg[0],sure_dk:cfg[1]});addMsg(r.ok?r.mesaj:'Moderasyon başarısız • '+(r.mesaj||''));box.remove();if(r.ok)await updateChat();});}
function clearChatWindow(){systemChat=[];lastChatRows=[];const el=document.getElementById('chatMessages');if(el)el.innerHTML='';}
function toggleChatVisibility(){chatHidden=!chatHidden;const box=document.getElementById('gameChat');if(box)box.classList.toggle('chat-hidden',chatHidden);const b=document.getElementById('chatToggleBtn');if(b)b.textContent=chatHidden?'💬':'🙈';if(b)b.title=chatHidden?'Sohbeti göster':'Sohbeti gizle';}
function setupEmoji(){
 const p=document.getElementById('emojiPicker'),b=document.getElementById('emojiBtn'),i=document.getElementById('chatInput');
 if(!p||!b||!i)return;
 const emojis=['😀','😂','😍','😎','🔥','💀','💯','👍','👎','❤️','⚡','🎯','🏆','😈','🤝','👏','😮','😢','🤣','🥶','🤖','👑','🚀','💥'];
 p.innerHTML=emojis.map(e=>`<button type="button" aria-label="${e}">${e}</button>`).join('');
 const close=()=>{p.hidden=true;p.classList.remove('is-open');p.style.display='none';b.setAttribute('aria-expanded','false');};
 const open=()=>{if(chatHidden)return;p.hidden=false;p.classList.add('is-open');p.style.display='grid';b.setAttribute('aria-expanded','true');};
 close();
 b.onclick=(e)=>{e.preventDefault();e.stopPropagation();p.classList.contains('is-open')?close():open();};
 p.addEventListener('click',e=>e.stopPropagation());
 document.addEventListener('click',e=>{if(!p.contains(e.target)&&e.target!==b)close();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
 p.querySelectorAll('button').forEach(x=>x.onclick=()=>{i.value=(i.value||'')+x.textContent;i.focus();close();});
 document.getElementById('clearChatBtn')?.addEventListener('click',clearChatWindow);
 document.getElementById('chatToggleBtn')?.addEventListener('click',()=>{close();toggleChatVisibility();});
 document.querySelector('.sa-game-chat-head')?.addEventListener('click',()=>{if(chatHidden)toggleChatVisibility();});
}
function addMsg(t){const now=Date.now();if(t===lastSystemMsg&&now-lastSystemAt<1500)return;lastSystemMsg=t;lastSystemAt=now;messages.unshift(t);messages=messages.slice(0,7);systemChat.push(t);systemChat=systemChat.slice(-20);renderSystemFeed();renderChat(lastChatRows||[])}
function setStatus(t){const el=document.getElementById('durum');if(el)el.textContent=t}
function weapon(){const id=normalizeWeaponId(equipment.silah);return WEAPONS[id]||WEAPONS.pistol}
function enemyOf(t){return t==='A'?'B':'A'}
function aliveEnemies(t){return players.filter(p=>p.team===enemyOf(t)&&p.respawn<=0)}
function nearestEnemy(p){let best=null,bestD=Infinity;for(const q of players){if(!q||q===p||q.team===p.team||q.respawn>0||q.hp<=0)continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<bestD){bestD=d;best=q;}}return best;}
function spawn(team,i){return {id:i,name:team==='A'?'Müttefik '+(i-1):'Rakip '+(i-TEAM_SIZE),team,x:team==='A'?rnd(100,1150):rnd(2200,3100),y:rnd(260,500),vx:0,vy:0,facing:team==='A'?1:-1,hp:MAX_HP,kills:0,deaths:0,ground:false,respawn:0,lastShot:0,lastAttack:0,walkPhase:Math.random()*Math.PI*2,weapon:null,ammo:0,character:team==='A'?'red':'blue',efekt:team==='A'?equipment.efekt:'yok'}}
let me={id:0,name:'Sen',team:'A',x:300,y:500,vx:0,vy:0,facing:1,hp:MAX_HP,kills:0,deaths:0,ground:false,respawn:0,lastShot:0,lastAttack:0,walkPhase:0,weapon:null,ammo:0,character:'red',efekt:'yok',xp:0,level:1};
players=[me];for(let i=2;i<=TEAM_SIZE;i++)players.push(spawn('A',i));for(let i=TEAM_SIZE+1;i<=MAX_PLAYERS;i++)players.push(spawn('B',i));

async function api(action,body){try{const r=await fetch(API+'?action='+action,{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token,'X-Access-Token':'Bearer '+token},body:JSON.stringify(body||{})});const tx=await r.text();let x;try{x=JSON.parse(tx)}catch(e){const clean=String(tx||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();return {ok:false,mesaj:'HTTP '+r.status+' geçersiz JSON'+(clean?' • '+clean.slice(0,220):'')}}if(!x.ok)console.warn('[StickArena]',action,x.mesaj);return x}catch(e){return {ok:false,mesaj:e.message}}}
async function loadEquipment(){if(guestMode)return;const x=await api('envanter',{});if(x.ok){equipment=x.donanim||equipment;equipment.silah=normalizeWeaponId(equipment.silah);equipment.karakter=normalizeCharacterId(equipment.karakter,me.team);me.character=equipment.karakter;me.efekt=equipment.efekt||'yok';players.forEach((p,i)=>{if(i)p.character=normalizeCharacterId(equipment.karakter,p.team),p.efekt=equipment.efekt||p.efekt});}}
function audioInit(){
  if(soundReady)return;
  try{window.__saAudio=new (window.AudioContext||window.webkitAudioContext)();soundReady=true;window.__saAudio.resume();initAudioBank();}catch(e){}
}
function initAudioBank(){if(audioBankReady)return;audioBankReady=true;Object.entries(AUDIO_FILES).forEach(([key,file])=>{const a=new Audio(AUDIO_PATH+file+'?v='+ASSET_VERSION);a.preload='auto';a.volume=key==='kill'?.55:.72;audioBank[key]=a;try{a.load()}catch(e){}});}
function playAudioFile(name,volume=1){const base=audioBank[name];if(!base)return false;try{const a=base.cloneNode(true);a.volume=Math.max(0,Math.min(1,(base.volume||.72)*volume));a.currentTime=0;const pr=a.play();if(pr?.catch)pr.catch(()=>{});return true;}catch(e){return false}}
function tone(freq,duration,type='square',gain=.045,slide=0){if(!soundReady)return;const ac=window.__saAudio,o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.setValueAtTime(freq,ac.currentTime);if(slide)o.frequency.linearRampToValueAtTime(Math.max(40,freq+slide),ac.currentTime+duration);g.gain.setValueAtTime(gain,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+duration);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+duration)}
function sfx(name){audioInit();if(playAudioFile(name))return;const m={jump:[300,.05,'triangle',.025,120],vote:[520,.12,'sine',.035,180],swap:[260,.28,'triangle',.06,420],pickup:[520,.12,'sine',.06,700]};const a=m[name]||[520,.05,'square',.025,-140];tone(...a)}
function makeParticle(x,y,color,life=.35,count=8,power=180){for(let i=0;i<count;i++)particles.push({x,y,vx:rnd(-power,power),vy:rnd(-power,power),life,color})}
function effectColor(p){return p.efekt==='efekt_ates'?'#ff7048':p.efekt==='efekt_buz'?'#8cecff':p.efekt==='efekt_neon'?'#67f7ff':null}
function attackBurst(p,x,y){const c=effectColor(p)||((WEAPONS[normalizeWeaponId(p.weapon)]||WEAPONS.pistol).color);makeParticle(x,y,c,.3,10,170);if(p.efekt==='efekt_ates'){for(let i=0;i<5;i++)particles.push({x,y,vx:rnd(-100,100),vy:rnd(-240,-80),life:.5,color:'#ffb14d'})}else if(p.efekt==='efekt_buz'){for(let i=0;i<7;i++)particles.push({x:x+rnd(-8,8),y:y+rnd(-8,8),vx:rnd(-80,80),vy:rnd(-80,80),life:.65,color:'#d7fbff'})}else if(p.efekt==='efekt_neon'){for(let i=0;i<8;i++)particles.push({x:x+rnd(-12,12),y:y+rnd(-12,12),vx:rnd(-140,140),vy:rnd(-140,140),life:.4,color:'#67f7ff'})}}
async function loadCurrentUser(){
 if(guestMode){setStatus('GİRİŞ GEREKLİ');addMsg('Oyuna katılmak için önce giriş yapmalısın.');return false;}
 const x=await api('me',{});if(!x.ok)return false;
 const u=x.kullanici||{};me.id=Number(u.id||0);window.SA_ME_ID=me.id;me.name=u.kullanici_adi||'Oyuncu';me.admin=isAdminRole(u.yetki)||u.admin===true;me.dogrulanmis=!!u.dogrulanmis;me.clan=x.klan?.ad||null;me.clanTag=x.klan?.etiket||null;me.xp=Math.max(0,Number(u.xp||0));me.level=Math.max(1,Math.min(MAX_LEVEL,Number(u.seviye||levelFromXp(me.xp))));ensureProgressUI();updateProgressUi();return true;
}
function renderMapCards(){const box=document.getElementById('mapCards');if(!box)return;box.innerHTML=Object.entries(MAPS).map(([id,m])=>`<button class="sa-map-card" data-map="${id}"><img src="${m.img}?v=${ASSET_VERSION}" alt="${esc(m.ad)}"><span>${esc(m.ad)}</span><b>HARİTAYI SEÇ</b></button>`).join('');box.querySelectorAll('[data-map]').forEach(b=>b.addEventListener('click',()=>openTeamSelector(b.dataset.map)));}
function renderLobbyPlayers(list){const el=document.getElementById('lobbyPlayers');if(!el)return;el.innerHTML=(list||[]).map(p=>`<span class="sa-lobby-player">${(p.dogrulanmis||p.admin)?'<b class="verify">✓</b> ':''}${esc(p.name||'Oyuncu')}${p.klan?` <small>[${esc(p.klan) }]</small>`:''}</span>`).join('');}
function openTeamSelector(mapId){
 let box=document.getElementById('teamSelector');
 if(!box){box=document.createElement('div');box.id='teamSelector';box.className='sa-team-selector';document.body.appendChild(box);}
 box.innerHTML=`<div class="sa-team-dialog"><span class="sa-eyebrow">STICK ARENA / TAKIM SEÇİMİ</span><h2>${esc(MAPS[mapId]?.ad||mapId)}</h2><p>Haritayı seçtin. Maça hangi takımda başlayacağını seç.</p><div class="sa-team-options"><button data-team="A" class="sa-team red"><strong>KIRMIZI TAKIM</strong><small>Oyuncu tarafı</small></button><button data-team="B" class="sa-team blue"><strong>MAVİ TAKIM</strong><small>Oyuncu tarafı</small></button></div><button id="teamCancel" class="sa-lobby-cancel">VAZGEÇ</button></div>`;
 box.querySelectorAll('[data-team]').forEach(b=>b.onclick=()=>{selectedTeam=b.dataset.team;box.remove();joinLobby(mapId,selectedTeam)});
 document.getElementById('teamCancel').onclick=()=>box.remove();
}
function showLobbyInviteCode(code){const wrap=document.getElementById('lobbyInviteDisplay'),val=document.getElementById('lobbyInviteValue');if(!wrap||!val)return;if(code){val.textContent=String(code).toUpperCase();wrap.hidden=false;}else{wrap.hidden=true;}const quick=document.getElementById('lobbyInviteCopy');if(quick)quick.hidden=!code;}
async function copyLobbyCode(){const code=(document.getElementById('lobbyInviteValue')?.textContent||'').trim();if(!code||code==='--------')return;try{await navigator.clipboard.writeText(code);addMsg('LOBİ KODU KOPYALANDI • '+code);}catch(_){addMsg('LOBİ KODU • '+code+' (manuel kopyala)');}}
function showLobbyNotice(message, status='LOBİ BİLGİSİ'){
 const el=document.getElementById('lobbyStatus');if(el)el.textContent=message;
 setStatus(status);
}
async function joinLobbyByCode(){
 if(lobbyJoined||matchStarted)return;
 const input=document.getElementById('lobbyInviteCode');
 const code=(input?.value||'').trim().toUpperCase();
 if(code.length!==8){showLobbyNotice('8 karakterli geçerli bir lobi kodu gir.','LOBI KODU');return;}
 audioInit();
 selectedOpponentMode='real';
 document.querySelectorAll('#opponentSelector [data-opponent]').forEach(b=>b.classList.toggle('is-selected',b.dataset.opponent==='real'));
 const r=await api('web_lobi_katil',{mod:GAME_MODE,harita:currentMap,takim:selectedTeam,rakip_turu:'real',davet_kodu:code});
 if(!r.ok){
   lobbyId='';lobbyJoined=false;lobbyPolling=false;
   showLobbyInviteCode('');
   showLobbyNotice(r.mesaj||'Lobi kodu geçersiz veya süresi dolmuş.','LOBI KODU');
   return;
 }
 lobbyId=r.lobi;lobbyJoined=true;
 showLobbyInviteCode(r.davet_kodu||code);
 document.getElementById('cancelLobby').style.display='block';
 document.getElementById('aktifHarita').textContent=r.harita_ad;
 document.getElementById('oda').textContent=r.lobi;
 const op=document.getElementById('oyuncular');if(op)op.textContent=(r.oyuncu||0)+'/'+(r.max||MAX_PLAYERS);
 renderLobbyPlayers(r.oyuncular||[]);
 showLobbyNotice('LOBİYE KATILINDI • '+code,'LOBİ BEKLENİYOR');
 pollLobby();
}
async function joinLobby(mapId,team='A'){
 if(lobbyJoined||matchStarted)return; audioInit();
 document.querySelectorAll('.sa-map-card').forEach(x=>x.classList.toggle('selected',x.dataset.map===mapId));
 const r=await api('web_lobi_katil',{mod:GAME_MODE,harita:mapId,takim:team,rakip_turu:selectedOpponentMode});
 if(!r.ok){showLobbyNotice(r.mesaj||'Lobiye katılınamadı.','LOBİ HATASI');return;}
 lobbyId=r.lobi;lobbyJoined=true;showLobbyInviteCode(r.davet_kodu||'');
 document.getElementById('cancelLobby').style.display='block';
 document.getElementById('aktifHarita').textContent=r.harita_ad;
 document.getElementById('oda').textContent=r.lobi;
 renderLobbyPlayers(r.oyuncular||[]);
 const op=document.getElementById('oyuncular');if(op)op.textContent=(r.oyuncu||0)+'/'+(r.max||MAX_PLAYERS);
 showLobbyNotice(selectedOpponentMode==='bot'?'BOT OPERASYONU hazırlanıyor • tek oyuncu + yapay zekâ rakipleri.':'GERÇEK OYUNCU LOBİSİ oluşturuldu • aynı harita ve modu seçen oyuncular eşleşecek.','LOBİ BEKLENİYOR');
 pollLobby();
}
async function pollLobby(){
 if(!lobbyJoined||matchStarted||lobbyPolling)return;
 lobbyPolling=true;
 try{
   const r=await api('web_lobi_durum',{lobi:lobbyId});
   if(!r.ok){
     lobbyPolling=false;lobbyJoined=false;showLobbyInviteCode('');
     document.getElementById('cancelLobby').style.display='none';
     showLobbyNotice(r.mesaj||'Lobi artık aktif değil.','LOBİ KAPANDI');
     return;
   }
   if(r.durum==='suresi_doldu'){
     lobbyPolling=false;lobbyJoined=false;showLobbyInviteCode('');
     document.getElementById('cancelLobby').style.display='none';
     document.getElementById('lobbyPlayers').innerHTML='';
     const op=document.getElementById('oyuncular');if(op)op.textContent='0/'+(r.max||MAX_PLAYERS);
     showLobbyNotice('Lobi süresi doldu. Yeni bir lobi oluşturabilirsin.','LOBİ SÜRESİ DOLDU');
     return;
   }
   renderLobbyPlayers(r.oyuncular||[]);
   const op=document.getElementById('oyuncular');if(op)op.textContent=(r.oyuncu||0)+'/'+(r.max||MAX_PLAYERS);
   document.getElementById('lobbyStatus').textContent=r.durum==='bekliyor'?`MAÇ HAZIRLANIYOR • ${Math.max(0,r.kalan)} saniye • ${r.oyuncu||0} oyuncu katıldı`:'MAÇ BAŞLADI • Yeni oyuncu alınmıyor';
   if(r.durum==='basladi'){lobbyPolling=false;startMatchFromLobby(r);}
   else setTimeout(()=>{lobbyPolling=false;pollLobby()},350);
 }catch(e){
   lobbyPolling=false;
   showLobbyNotice('Lobi bağlantısı geçici olarak kesildi. Tekrar deneniyor…','LOBİ BAĞLANTISI');
   setTimeout(()=>pollLobby(),1200);
 }
}
function startMatchFromLobby(r){
 const savedXp=Math.max(0,Number(me.xp||0));
 const savedLevel=Math.max(1,Math.min(MAX_LEVEL,Number(me.level||levelFromXp(savedXp))));
 matchStarted=true;scoreboardOpen=false;lastKillFeedId=0;killFeedCache=[];chatLastId=0;lastAdminAnnouncementChatId=0;lastAnnouncementId=0;document.body.classList.add('sa-match-active');lobbyJoined=false;roomId=r.oda;teamSwapped=false;lastAutoMapRound=0;currentMap=r.harita;mapPlatforms=layoutFor(currentMap);startedAt=performance.now();serverRemaining=MATCH;remoteReady=true;selectedOpponentMode=r.rakip_turu==='bot'?'bot':'real';adminGamemode=!!r.admin_gamemode;setStatus('CANLI • '+(r.mod==='clan'?'10v10 KLAN':'5v5 NORMAL')+' • '+(selectedOpponentMode==='bot'?'BOT OPERASYONU':'GERÇEK OYUNCU'));document.getElementById('oda').textContent=roomId;document.getElementById('aktifHarita').textContent=r.harita_ad;document.getElementById('lobbyScreen').style.display='none';canvas.style.display='block';const mapHud=document.getElementById('mapRotationHud');if(mapHud)mapHud.style.display='block';const mapHudName=document.getElementById('mapRotationName');if(mapHudName)mapHudName.textContent=MAPS[currentMap]?.ad||currentMap;document.getElementById('gameHint').style.display='none';document.getElementById('gameChat').style.display='flex';const leaveBtn=document.getElementById('cancelLobby');if(leaveBtn){leaveBtn.style.display='block';leaveBtn.textContent='MAÇTAN AYRIL';}
 const source=(r.oyuncular||[]);players=[];let mine=null;
 for(const rp of source){const bot=!rp.real||!!rp.bot;const p={id:Number(rp.id),name:rp.name||'Oyuncu',team:rp.team==='B'?'B':'A',x:Number(rp.x||300),y:Number(rp.y||500),vx:Number(rp.vx||0),vy:Number(rp.vy||0),facing:rp.team==='B'?-1:1,hp:Number(rp.hp??MAX_HP),kills:Number(rp.kills||0),deaths:Number(rp.deaths||0),ground:false,respawn:Number(rp.respawn||0),lastShot:0,lastAttack:0,walkPhase:0,character:normalizeCharacterId(rp.character,rp.team==='B'?'B':'A'),weapon:normalizeWeaponId(rp.weapon||'pistol'),ammo:Number(rp.ammo||MAX_AMMO),efekt:rp.efekt||'yok',admin:!!rp.admin,dogrulanmis:!!rp.dogrulanmis,klan:rp.klan||null,klanTag:rp.klan_etiket||null,real:!bot,bot,netX:Number(rp.x||300),netY:Number(rp.y||500),netVx:Number(rp.vx||0),netVy:Number(rp.vy||0),combat_at:Number(rp.combat_at||0),deathSeq:Number(rp.death_seq||0),spawnProtectedUntil:Number(rp.spawn_protected_until_ms||0),_netAt:performance.now(),_lastAckX:Number(rp.x||300),_lastAckY:Number(rp.y||500)};players.push(p);if(p.id===me.id)mine=p;}
 if(mine){me=mine;me.xp=Math.max(0,Number(savedXp));me.level=Math.max(1,Math.min(MAX_LEVEL,Number(savedLevel)));me.character=normalizeCharacterId(equipment.karakter,me.team);me.weapon=normalizeWeaponId(me.weapon||equipment.silah||'pistol');me.ammo=me.ammo||ammoForWeapon(me.weapon);me.efekt=equipment.efekt||me.efekt;if(adminGamemode){me.weapon=me.weapon||'pistol';me.ammo=999999;me.hp=MAX_HP;}}else{addMsg('Oyuncu kaydı alınamadı. Maç güvenli biçimde sonlandırıldı.');return finish();}
 addMsg('MAÇ BAŞLADI • '+(selectedOpponentMode==='bot'?'Yapay zekâ botları sunucu durumu ile senkron.':'Gerçek oyuncu eşleşmesi aktif.') );sfx('vote');reset();renderScoreboard();pollKillFeed(true);if(gameRafId)cancelAnimationFrame(gameRafId);let accumulator=0;lastFrameAt=performance.now();lastRenderAt=0;const loop=(now)=>{try{const elapsed=Math.min(MAX_FRAME_DELTA,Math.max(0,(now-lastFrameAt)/1000));lastFrameAt=now;accumulator+=elapsed;let steps=0;while(accumulator>=FIXED_DT&&steps<6){try{update(FIXED_DT);}catch(err){console.error('[StickArena] update hatası',err);}accumulator-=FIXED_DT;steps++;}if(steps>=6)accumulator=0;const renderInterval=1000/60;if(now-lastRenderAt>=renderInterval-0.5){try{draw();}catch(err){console.error('[StickArena] draw hatası',err);}lastRenderAt=now;}}catch(frameErr){console.error('[StickArena] frame hatası',frameErr);}finally{gameRafId=requestAnimationFrame(loop)}};try{draw();}catch(err){console.error('[StickArena] ilk render hatası',err);}gameRafId=requestAnimationFrame(loop);
 window.SA_ME_ID=Number(me.id||0);if(window.SAVoiceChat?.start)window.SAVoiceChat.start({oda:roomId,team:me.team,meId:Number(me.id||0)});
}
function spawnBot(team,id){
  const p=spawn(team,id);
  p.real=false;p.admin=false;p.klan=null;
  p.name=team==='A'?'BOT • Müttefik':'BOT • Rakip';
  const arsenal=Object.keys(WEAPONS);
  p.weapon=arsenal[Math.floor(Math.random()*arsenal.length)]||'pistol';
  p.ammo=ammoForWeapon(p.weapon);
  p.aiShotJitter=rnd(.88,1.16);
  p.aiStrafe=Math.random()<.5?-1:1;
  p.aiAccuracy=BOT_ACCURACY*rnd(.90,1.08);
  p.aiAimError=0;
  p.aiNextJump=performance.now()+rnd(800,2200);
  return p;
}
function applyMap(id){if(!MAPS[id]||id===currentMap)return;currentMap=id;mapPlatforms=layoutFor(id);
  const mapEl=document.getElementById('aktifHarita');if(mapEl)mapEl.textContent=MAPS[id].ad+' • OTOMATİK';const hud=document.getElementById('mapRotationHud');const hn=document.getElementById('mapRotationName');if(hud)hud.style.display='block';if(hn)hn.textContent=MAPS[id].ad;
  // Harita değişiminde eski platform koordinatında kalıp düşmeyi önle: oyuncuları güvenli başlangıç bölgelerine taşı.
  players.forEach(p=>{if(p.respawn<=0){p.x=p.team==='A'?rnd(120,650):rnd(2550,3050);p.y=420;p.vx=0;p.vy=0;}});
  addMsg('HARİTA DEĞİŞTİ • '+MAPS[id].ad+' • Yeni arena aktif.');sfx('vote');makeParticle(me.x,me.y,'#72e6ff',.7,30,360)}
const MAP_LAYOUTS={"col_bolgesi":[{"x":0,"y":640,"w":560,"h":50,"tur":"zemin"},{"x":620,"y":555,"w":260,"h":28,"tur":"kopru"},{"x":950,"y":455,"w":340,"h":28,"tur":"kopru"},{"x":1340,"y":565,"w":220,"h":30,"tur":"kutu"},{"x":1580,"y":385,"w":470,"h":28,"tur":"kopru"},{"x":2100,"y":500,"w":250,"h":30,"tur":"kutu"},{"x":2410,"y":330,"w":360,"h":28,"tur":"kopru"},{"x":2810,"y":545,"w":390,"h":45,"tur":"zemin"},{"x":1120,"y":285,"w":230,"h":26,"tur":"kutu"},{"x":1970,"y":235,"w":280,"h":26,"tur":"kopru"}],"sehir_insaati":[{"x":0,"y":645,"w":500,"h":45,"tur":"zemin"},{"x":560,"y":545,"w":260,"h":30,"tur":"kutu"},{"x":850,"y":435,"w":420,"h":28,"tur":"kopru"},{"x":1330,"y":575,"w":250,"h":30,"tur":"kutu"},{"x":1640,"y":455,"w":350,"h":28,"tur":"kopru"},{"x":2050,"y":335,"w":250,"h":28,"tur":"kutu"},{"x":2360,"y":500,"w":320,"h":28,"tur":"kopru"},{"x":2740,"y":420,"w":460,"h":45,"tur":"zemin"},{"x":1110,"y":250,"w":220,"h":26,"tur":"kutu"}],"uzay_istasyonu":[{"x":0,"y":645,"w":620,"h":45,"tur":"zemin"},{"x":730,"y":530,"w":290,"h":28,"tur":"kopru"},{"x":1080,"y":400,"w":300,"h":30,"tur":"kutu"},{"x":1450,"y":545,"w":460,"h":28,"tur":"kopru"},{"x":1990,"y":415,"w":260,"h":30,"tur":"kutu"},{"x":2320,"y":295,"w":390,"h":28,"tur":"kopru"},{"x":2720,"y":520,"w":480,"h":45,"tur":"zemin"},{"x":1290,"y":230,"w":250,"h":26,"tur":"kutu"}],"askeri_us":[{"x":0,"y":645,"w":580,"h":45,"tur":"zemin"},{"x":690,"y":535,"w":280,"h":30,"tur":"kutu"},{"x":1010,"y":430,"w":390,"h":28,"tur":"kopru"},{"x":1450,"y":565,"w":240,"h":30,"tur":"kutu"},{"x":1740,"y":375,"w":450,"h":28,"tur":"kopru"},{"x":2240,"y":500,"w":270,"h":30,"tur":"kutu"},{"x":2550,"y":305,"w":370,"h":28,"tur":"kopru"},{"x":2950,"y":540,"w":250,"h":45,"tur":"zemin"},{"x":1240,"y":265,"w":220,"h":26,"tur":"kutu"}],"orman":[{"x":0,"y":645,"w":640,"h":45,"tur":"zemin"},{"x":740,"y":520,"w":300,"h":28,"tur":"kutu"},{"x":1080,"y":410,"w":430,"h":28,"tur":"kopru"},{"x":1570,"y":565,"w":250,"h":30,"tur":"kutu"},{"x":1880,"y":445,"w":380,"h":28,"tur":"kopru"},{"x":2290,"y":335,"w":280,"h":30,"tur":"kutu"},{"x":2600,"y":510,"w":420,"h":28,"tur":"kopru"},{"x":3030,"y":590,"w":170,"h":40,"tur":"zemin"},{"x":1290,"y":260,"w":220,"h":26,"tur":"kutu"}],"gece_ormani":[{"x":0,"y":645,"w":520,"h":45,"tur":"zemin"},{"x":600,"y":520,"w":250,"h":30,"tur":"kutu"},{"x":900,"y":395,"w":370,"h":28,"tur":"kopru"},{"x":1300,"y":550,"w":250,"h":30,"tur":"kutu"},{"x":1590,"y":335,"w":430,"h":28,"tur":"kopru"},{"x":2080,"y":475,"w":240,"h":30,"tur":"kutu"},{"x":2380,"y":365,"w":370,"h":28,"tur":"kopru"},{"x":2790,"y":520,"w":410,"h":45,"tur":"zemin"},{"x":1460,"y":225,"w":240,"h":26,"tur":"kutu"}],"sehir_gece":[{"x":0,"y":645,"w":580,"h":45,"tur":"zemin"},{"x":660,"y":530,"w":250,"h":30,"tur":"kutu"},{"x":970,"y":420,"w":360,"h":28,"tur":"kopru"},{"x":1360,"y":305,"w":230,"h":30,"tur":"kutu"},{"x":1640,"y":495,"w":430,"h":28,"tur":"kopru"},{"x":2140,"y":390,"w":250,"h":30,"tur":"kutu"},{"x":2450,"y":300,"w":390,"h":28,"tur":"kopru"},{"x":2870,"y":540,"w":330,"h":45,"tur":"zemin"},{"x":1170,"y":235,"w":220,"h":26,"tur":"kutu"}],"liman":[{"x":0,"y":645,"w":680,"h":45,"tur":"zemin"},{"x":770,"y":535,"w":300,"h":30,"tur":"kutu"},{"x":1120,"y":440,"w":390,"h":28,"tur":"kopru"},{"x":1540,"y":560,"w":240,"h":30,"tur":"kutu"},{"x":1830,"y":345,"w":450,"h":28,"tur":"kopru"},{"x":2320,"y":480,"w":250,"h":30,"tur":"kutu"},{"x":2620,"y":315,"w":380,"h":28,"tur":"kopru"},{"x":3000,"y":560,"w":200,"h":45,"tur":"zemin"},{"x":2000,"y":235,"w":240,"h":26,"tur":"kutu"}],"harabe":[{"x":0,"y":645,"w":550,"h":45,"tur":"zemin"},{"x":620,"y":545,"w":250,"h":30,"tur":"kutu"},{"x":910,"y":455,"w":390,"h":28,"tur":"kopru"},{"x":1350,"y":570,"w":250,"h":30,"tur":"kutu"},{"x":1650,"y":395,"w":430,"h":28,"tur":"kopru"},{"x":2120,"y":515,"w":250,"h":30,"tur":"kutu"},{"x":2410,"y":395,"w":410,"h":28,"tur":"kopru"},{"x":2820,"y":525,"w":380,"h":45,"tur":"zemin"},{"x":1110,"y":270,"w":230,"h":26,"tur":"kutu"}],"karli_daglar":[{"x":0,"y":645,"w":600,"h":45,"tur":"zemin"},{"x":670,"y":535,"w":290,"h":30,"tur":"kutu"},{"x":1020,"y":425,"w":390,"h":28,"tur":"kopru"},{"x":1470,"y":565,"w":240,"h":30,"tur":"kutu"},{"x":1760,"y":355,"w":430,"h":28,"tur":"kopru"},{"x":2240,"y":475,"w":250,"h":30,"tur":"kutu"},{"x":2540,"y":295,"w":390,"h":28,"tur":"kopru"},{"x":2970,"y":535,"w":230,"h":45,"tur":"zemin"},{"x":1280,"y":235,"w":240,"h":26,"tur":"kutu"}]};
function layoutFor(id){return (MAP_LAYOUTS[id]||MAP_LAYOUTS.col_bolgesi).map(p=>({...p}));}
async function voteStatus(){return;}
function showVote(){return;}
function renderScoreHud(){const a=Math.max(0,Number(serverScoreA||0)),b=Math.max(0,Number(serverScoreB||0));const se=document.getElementById('skor');if(se)se.textContent=a+' — '+b;const ms=document.getElementById('mapRotationScore');if(ms)ms.textContent=a+' — '+b;const ta=document.getElementById('scoreTeamA');if(ta)ta.textContent=a;const tb=document.getElementById('scoreTeamB');if(tb)tb.textContent=b;}

function weaponKillfeedLabel(id){
  const map={pistol:'9MM',m4a1:'M4A1',awp:'AWP',rpg:'RPG-7',uzi:'UZI',mp5:'MP5',ak47:'AK-47',shotgun:'M870',deagle:'DEAGLE',vector:'VECTOR',p90:'P90',tabanca:'9MM',tufek:'M4A1',makineli_tufek:'MP5',pompal_tufek:'M870',roketatar:'RPG-7',keskin_nisanci:'AWP',karbon_silah:'VECTOR',karanlik_silah:'P90',neon_silah:'VECTOR',altin_silah:'DEAGLE',alev_silah:'RPG-7',buz_silah:'AWP'};
  return map[id]||'WEAPON';
}
function renderKillFeed(){
  const el=document.getElementById('killFeed'); if(!el)return;
  const rows=killFeedCache.slice(-6);
  el.innerHTML=rows.map(x=>{
    const kc=x.killer_team==='B'?'team-b':'team-a';
    const vc=(x.target_id===Number(me?.id||0))?'victim-self':'';
    return `<div class="sa-kill-entry ${kc} ${vc}"><strong class="sa-kf-name">${esc(x.killer_name)}</strong><span class="sa-kf-weapon">${esc(weaponKillfeedLabel(x.weapon))}</span><b class="sa-kf-target">${esc(x.target_name)}</b></div>`;
  }).join('');
}
async function pollKillFeed(force=false){
  if(!matchStarted||finished||!roomId)return;
  const now=performance.now();if(!force&&now-lastKillFeedPoll<KILLFEED_POLL_MS)return;lastKillFeedPoll=now;
  try{
    const r=await api('web_mac_killfeed',{oda:roomId});if(!r.ok||!Array.isArray(r.olaylar))return;
    const incoming=r.olaylar.slice().sort((a,b)=>Number(a.id)-Number(b.id));
    if(lastKillFeedId===0){killFeedCache=incoming.slice(-6);lastKillFeedId=Number(r.son_id||incoming.at(-1)?.id||0);renderKillFeed();return;}
    const fresh=incoming.filter(x=>Number(x.id)>lastKillFeedId);
    if(fresh.length){killFeedCache=[...killFeedCache,...fresh].slice(-6);lastKillFeedId=Math.max(lastKillFeedId,...fresh.map(x=>Number(x.id)||0));renderKillFeed();}
  }catch(e){console.debug('[StickArena] killfeed poll',e)}
}

function renderScoreboard(){const panel=document.getElementById('scoreboardPanel');if(!panel)return;const title=document.getElementById('scoreboardMode');if(title)title.textContent=selectedOpponentMode==='bot'?'BOT OPERASYONU':'GERÇEK OYUNCU';const a=document.getElementById('scoreboardScoreA'),b=document.getElementById('scoreboardScoreB');if(a)a.textContent=String(serverScoreA);if(b)b.textContent=String(serverScoreB);const list=document.getElementById('scoreboardRows');if(!list)return;const rows=[...players].filter(p=>p.real||p.bot).sort((x,y)=>x.team.localeCompare(y.team)||Number(y.kills||0)-Number(x.kills||0)||Number(y.deaths||0)-Number(x.deaths||0));list.innerHTML=rows.map(p=>`<div class=\"sa-score-row ${p.team==='A'?'team-a':'team-b'}\"><span>${p.team==='A'?'K':'M'}</span><strong>${esc(p.name)}</strong><b>${Number(p.kills||0)}</b><small>${Number(p.deaths||0)}</small></div>`).join('');panel.hidden=!scoreboardOpen;}
async function syncMatch(){
  if(!matchStarted||finished||!remoteReady||!roomId||syncInFlight)return;
  const now=performance.now(); if(now-lastSync<300)return; lastSync=now; syncInFlight=true;
  try{
    const remain=paused?serverRemaining:Math.max(0,serverRemaining);
    const owned=players.filter(p=>p===me||p.bot);
    const statePlayers=owned.map(p=>({id:p.id,name:p.name,team:p.team,x:Math.round(p.x),y:Math.round(p.y),vx:Math.round(p.vx||0),vy:Math.round(p.vy||0),hp:Math.max(0,Math.round(p.hp)),kills:p.kills,deaths:p.deaths,respawn:Math.max(0,Math.round(p.respawn*10)/10),character:p.character,weapon:p.weapon||null,ammo:Number(p.ammo||0),efekt:p.efekt,admin:!!p.admin,dogrulanmis:!!p.dogrulanmis,klan:p.klan||null,klan_etiket:p.klanTag||null,deathSeq:Number(p.deathSeq||0),respawnAt:Number(p._serverRespawnAt||0)/1000,real:!!p.real,bot:!!p.bot,combat_at:Number(p.combat_at||0)}));
    const liveBullets=bullets.slice(0,100).map(b=>({x:Math.round(b.x),y:Math.round(b.y),team:b.team,kind:b.kind,owner:Number(b.owner||0)}));
    const r=await api('web_mac_heartbeat',{oda:roomId,kalan:remain,players:statePlayers,bullets:liveBullets,map:{id:currentMap,genislik:W,yukseklik:H,platformlar:mapPlatforms}});
    if(!r.ok)return;
    if(r.players&&Array.isArray(r.players)){
      for(const rp of r.players){
        const p=players.find(q=>Number(q.id)===Number(rp.id));
        if(p&&p!==me&&p.real)applyRemotePlayerState(rp);
        else if(p&&p.bot){p.netX=Number(rp.x??p.x);p.netY=Number(rp.y??p.y);p._netAt=performance.now();p.hp=Number(rp.hp??p.hp);p.kills=Number(rp.kills??p.kills);p.deaths=Number(rp.deaths??p.deaths);p.weapon=rp.weapon||null;p.ammo=Number(rp.ammo||0);p.deathSeq=Number(rp.deathSeq??rp.death_seq??p.deathSeq??0);}
      }
    }
    if(r.admin_gamemode!==undefined)adminGamemode=!!r.admin_gamemode;if(r.scoreA!==undefined)serverScoreA=Number(r.scoreA);if(r.scoreB!==undefined)serverScoreB=Number(r.scoreB);if(r.score_rev!==undefined)lastScoreRevision=Number(r.score_rev);serverRemaining=Number(r.server_remaining??serverRemaining);renderScoreHud();renderScoreboard();
    if(r.map?.id)applyMap(r.map.id);if(r.team_swap_pending&&!teamSwapPending){teamSwapPending=true;teamSwapNoticeUntil=performance.now()+5000;paused=true;addMsg('TAKIMLAR 5 SANİYE İÇİNDE DEĞİŞECEK.');}if(r.duraklatildi!==undefined&&!teamSwapPending)paused=!!r.duraklatildi;if(r.team_swapped&&!teamSwapped){teamSwapPending=false;teamSwapNoticeUntil=0;applyTeamSwap(r.players||[],r.scoreA,r.scoreB);paused=false;}
    const mineState=r.players?.find?.(q=>Number(q.id)===Number(me.id));if(mineState&&Number(mineState.hp)<=0&&me.hp>0){me.hp=0;me.respawn=Math.max(RESPAWN_DELAY,Number(mineState.respawn||RESPAWN_DELAY));me.weapon=null;me.ammo=0;me.deathSeq=Number(mineState.deathSeq||me.deathSeq||1);deathOverlaySeq=me.deathSeq;deathOverlayUntil=performance.now()+RESPAWN_DELAY*1000;}
  }finally{syncInFlight=false;}
}

function applyTeamSwap(statePlayers,scoreA,scoreB){
 if(!Array.isArray(statePlayers))return;
 for(const rp of statePlayers){const p=players.find(q=>Number(q.id)===Number(rp.id));if(p){p.team=rp.team==='B'?'B':'A';p.x=Number(rp.x??p.x);p.y=Number(rp.y??p.y);p.hp=Number(rp.hp??p.hp);p.kills=Number(rp.kills||0);p.deaths=Number(rp.deaths||0);p.weapon=rp.weapon||null;p.ammo=Number(rp.ammo||0);}}
 const mine=players.find(p=>Number(p.id)===Number(me.id));if(mine)me=mine;
 teamSwapped=true;
 teamSwapPending=false;
 teamSwapNoticeUntil=0;
 serverScoreA=Number(scoreA||0);serverScoreB=Number(scoreB||0);renderScoreHud();
 setStatus('TAKIMLAR DEĞİŞTİ • '+(me.team==='A'?'KIRMIZI':'MAVİ')+' TAKIM');
 addMsg('7:30 kaldı • KIRMIZI ve MAVİ takımlar yer değiştirdi.');sfx('swap');
}
async function pollRemoteState(){
 if(!matchStarted||!roomId)return;const now=performance.now();if(now-lastRemoteStatePoll<500)return;lastRemoteStatePoll=now;
 try{const r=await api('web_mac_durum',{oda:roomId});if(!r.ok)return;paused=!!r.mac.duraklatildi;adminGamemode=!!(r.mac.admin_gamemode??adminGamemode);serverScoreA=Number(r.mac.skor?.A??serverScoreA);serverScoreB=Number(r.mac.skor?.B??serverScoreB);renderScoreHud();renderScoreboard();serverRemaining=Number(r.mac.kalan||serverRemaining);if(r.mac.map?.id)applyMap(r.mac.map.id);
  if(r.mac.state?.players){for(const rp of r.mac.state.players){const p=players.find(q=>Number(q.id)===Number(rp.id));if(!p)continue;if(Number(rp.id)===Number(me.id)){
    const hpBefore=me.hp,serverHp=Math.max(0,Number(rp.hp??me.hp));me.hp=serverHp;me.respawn=Math.max(0,Number(rp.respawn||0));me.deaths=Math.max(me.deaths,Number(rp.deaths||0));me._serverDeathSeq=Number(rp.deathSeq??rp.death_seq??me._serverDeathSeq??0);me.spawnProtectedUntil=Number(rp.spawnProtectedUntil??rp.spawn_protected_until_ms??me.spawnProtectedUntil??0);
    const nx=Number(rp.x??me.x),ny=Number(rp.y??me.y),err=Math.hypot(nx-me.x,ny-me.y);if(err>MOVE_CFG.netSnap){me.x=nx;me.y=ny;me.vx=Number(rp.vx||0);me.vy=Number(rp.vy||0);localNetCorrectionX=0;localNetCorrectionY=0;}else{localNetCorrectionX=0;localNetCorrectionY=0;}
    if(serverHp<=0&&hpBefore>0){me.weapon=null;me.ammo=0;deathOverlaySeq=me._serverDeathSeq||deathOverlaySeq+1;deathOverlayUntil=performance.now()+RESPAWN_DELAY*1000;addMsg('ÖLDÜN • 10 saniye sonra yeniden doğacaksın. İzleme modu aktif.');}
  }else if(p.real)applyRemotePlayerState(rp);else if(p.bot){p.spawnProtectedUntil=Number(rp.spawnProtectedUntil??rp.spawn_protected_until_ms??p.spawnProtectedUntil??0);}}}
  if(Number(r.mac.takim_degisti)===2&&!teamSwapPending){teamSwapPending=true;teamSwapNoticeUntil=performance.now()+5000;paused=true;addMsg('7:30 kaldı • TAKIMLAR 5 SANİYE İÇİNDE DEĞİŞECEK. BOL ŞANSLAR DİLERİZ!');setStatus('TAKIM DEĞİŞİMİ • 5 SANİYE');}
  if(Number(r.mac.takim_degisti)===1&&!teamSwapped)applyTeamSwap(r.mac.state?.players||[],r.mac.skor?.A,r.mac.skor?.B);
  const po=document.getElementById('pauseOverlay');if(po){if(paused){po.style.display='grid';po.innerHTML=teamSwapPending?'<div><strong>TAKIMLAR DEĞİŞİYOR</strong><span>Maç 5 saniyeliğine duraklatıldı. Takımlar skorlarıyla birlikte yer değiştirecek.</span></div>':'<div><strong>MAÇ YÖNETİCİ TARAFINDAN DURAKLATILDI</strong><span>Admin oyunu yeniden başlatana kadar hareket ve süre bekletildi.</span></div>';}else{po.style.display='none';}}
  const op=document.getElementById('oyuncular');if(op)op.textContent=(r.mac.oyuncular||players.length)+'/'+MAX_PLAYERS;if(!paused&&serverRemaining>=0)startedAt=performance.now()-(MATCH-serverRemaining)*1000;updateChat(r.mac.chat||[]);
 }catch(e){console.debug('[StickArena] state poll',e)}}
async function pollScoreboard(){
 if(!matchStarted||finished||!roomId||scorePollInFlight)return;const now=performance.now();if(now-lastScorePoll<300)return;lastScorePoll=now;scorePollInFlight=true;
 try{const r=await api('web_mac_scoreboard',{oda:roomId});if(!r.ok)return;const incomingRev=Number(r.score_rev??lastScoreRevision);if(incomingRev>=lastScoreRevision)lastScoreRevision=incomingRev;serverScoreA=Math.max(0,Number(r.scoreA??0));serverScoreB=Math.max(0,Number(r.scoreB??0));serverScoreA=Math.max(0,serverScoreA);serverScoreB=Math.max(0,serverScoreB);const byId=new Map((r.oyuncular||[]).map(x=>[Number(x.id),x]));for(const p of players){const x=byId.get(Number(p.id));if(x){p.kills=Number(x.kills||0);p.deaths=Number(x.deaths||0);p.team=x.team==='B'?'B':'A';}}renderScoreHud();renderScoreboard();}finally{scorePollInFlight=false;}
}

async function updateChat(preloaded){let rows=preloaded;if(!rows){const r=await api('web_chat_liste',{oda:roomId});if(!r.ok)return;rows=r.liste||[];}const list=Array.isArray(rows)?rows:[];for(const row of list.slice().sort((a,b)=>Number(a.id||0)-Number(b.id||0))){const id=Number(row.id||0);if(id>chatLastId){chatLastId=id;if((row.admin===true||isAdminRole(row.yetki))&&id>lastAdminAnnouncementChatId){lastAdminAnnouncementChatId=id;showAdminAnnouncement(row.mesaj||'Yönetici mesajı');}}}lastChatRows=list;renderChat(lastChatRows);}
async function pollAnnouncements(){if(!matchStarted||finished||!roomId)return;try{const r=await api('web_duyurular_aktif',{oda:roomId,since_id:lastAnnouncementId});if(!r.ok||!Array.isArray(r.liste))return;for(const a of r.liste){const id=Number(a.id||0);if(id<=lastAnnouncementId)continue;lastAnnouncementId=Math.max(lastAnnouncementId,id);const text=String(a.icerik||'').trim();showAdminAnnouncement(text||String(a.baslik||'Yönetici Duyurusu'));addMsg('📢 DUYURU • '+String(a.baslik||'')+' • '+text);}}catch(e){}}
setInterval(()=>{if(matchStarted&&roomId){updateChat().catch(()=>{});pollAnnouncements().catch(()=>{});}},1000);
function hitPlatform(p){for(const q of mapPlatforms){if(p.x>q.x-20&&p.x<q.x+q.w+20&&p.y+28>=q.y&&p.y+28<=q.y+q.h+30&&p.vy>=0){p.y=q.y-28;p.vy=0;p.ground=true;return true}}return false}
function spawnDroppedItem(id,type,x,y,ownerId=0,launch=true){
  pickups.push({id,type,x,y,vy:launch?-120:35,vx:launch?rnd(-45,45):rnd(-15,15),landed:false,ttl:WEAPON_DROP_TTL,spawnedAt:performance.now(),ownerId:Number(ownerId||0),pickupBlockedUntil:performance.now()+850});
}
function spawnDrop(){
  const id=DROP_ITEMS[Math.floor(Math.random()*DROP_ITEMS.length)];
  spawnDroppedItem(id,'weapon',W/2+rnd(-140,140),70,0,false);
}
function dropHeldItem(p){
  if(p.respawn>0||!p.weapon)return;
  const id=p.weapon;
  spawnDroppedItem(id,'weapon',p.x+((p.facing||1)*18),Math.max(90,p.y-35),p.id,true);
  p.weapon=null;p.ammo=0;
  if(p===me)addMsg('SİLAH ATILDI • '+(WEAPONS[id]?.ad||'Silah'));
  sfx('pickup');
}
function updateDrops(dt){
  if(!matchStarted||paused||finished)return;
  if(!nextDropAt)nextDropAt=performance.now()+12000;
  if(performance.now()>=nextDropAt){spawnDrop();nextDropAt=performance.now()+22000;addMsg('HARİTA MERKEZİ • Yeni ekipman düştü.');}
  for(let i=pickups.length-1;i>=0;i--){
    const d=pickups[i];d.ttl-=dt;if(d.ttl<=0){pickups.splice(i,1);continue;}
    if(!d.landed){d.vy+=220*dt;d.x+=(d.vx||0)*dt;d.y+=d.vy*dt;d.x=Math.max(40,Math.min(W-40,d.x));
      const support=mapPlatforms.filter(q=>d.x>q.x-10&&d.x<q.x+q.w+10&&q.y>d.y).sort((a,b)=>a.y-b.y)[0];
      const floor=support?support.y-22:G-45;
      if(d.y>=floor){d.y=floor;d.vy=0;d.vx*=.25;d.landed=true;}
    }
    let winner=null,best=Infinity;
    for(const p of players){if(p.respawn>0)continue;if(Number(d.ownerId||0)===Number(p.id)&&performance.now()<Number(d.pickupBlockedUntil||0))continue;const dist=Math.hypot(p.x-d.x,(p.y-18)-d.y);if(dist<48&&dist<best){best=dist;winner=p;}}
    /* Oyuncunun elinde çalışan bir silah varsa yerdeki silahı alma.
     * Yalnızca silahsız/şarjörü bitmiş oyuncu pickup alabilir. */
    if(winner && !winner.weapon && Number(winner.ammo||0)<=0){
      winner.weapon=normalizeWeaponId(d.id);
      winner.ammo=ammoForWeapon(winner.weapon);
      if(winner===me)addMsg('SİLAH ALINDI • '+(WEAPONS[d.id]?.ad||'Silah'));
      sfx('pickup');pickups.splice(i,1);
    }
  }
}
async function sendCombatHit(target,spec,kind,attackerOverride=null,retry=0){
  const attacker=attackerOverride||me;if(!attacker)return;
  try{
    const action=attacker.bot?'web_bot_saldiri':'web_saldiri';const payload=attacker.bot?{oda:roomId,attacker_id:Number(attacker.id),target_id:Number(target.id),facing:Number(attacker.facing||1),attacker_x:Number(attacker.x||0),attacker_y:Number(attacker.y||0),target_x:Number(target.x||0),target_y:Number(target.y||0)}:{oda:roomId,target_id:Number(target.id),facing:Number(attacker.facing||1),attacker_x:Number(attacker.x||0),attacker_y:Number(attacker.y||0),target_x:Number(target.x||0),target_y:Number(target.y||0)};
    const r=await api(action,payload);if(!r.ok){if(retry<1&&roomId&&target&&target.respawn<=0){setTimeout(()=>sendCombatHit(target,spec,kind,attacker, retry+1),70);}return;}
    const p=players.find(q=>Number(q.id)===Number(r.target_id));if(p){p.hp=Number(r.hp??p.hp);p.respawn=Number(r.respawn||0);p.deaths=Number(r.deaths??p.deaths);p.deathSeq=Number(r.death_seq ?? p.deathSeq ?? 0);p.spawnProtectedUntil=Number(r.spawn_protected_until_ms??p.spawnProtectedUntil??0);p._serverRespawnAt=Number(r.respawn_at||0)*1000 || (p.hp<=0?performance.now()+RESPAWN_DELAY*1000:0);p.deathSpectateUntil=p._serverRespawnAt;if(p.hp<=0){p.weapon=null;p.ammo=0;}}
    const killer=players.find(q=>Number(q.id)===Number(r.killer_id||attacker.id));if(attacker===me){if(r.ammo!==undefined)me.ammo=Number(r.ammo);if(r.weapon!==undefined)me.weapon=r.weapon||null;}serverScoreA=Number(r.scoreA??serverScoreA);serverScoreB=Number(r.scoreB??serverScoreB);if(killer&&r.killer_kills!==undefined)killer.kills=Number(r.killer_kills);renderScoreHud();renderScoreboard();if(r.killed){sfx('kill');addMsg((attacker.bot?'BOT ': 'SEN ')+'VURDU • '+(p?.name||'hedef'));}else sfx('hit');
  }catch(e){console.warn('[StickArena] combat sync',e)}
}

async function applyDeathResponse(r){
  if(!r||!r.ok)return;
  serverScoreA=Number(r.scoreA??serverScoreA);serverScoreB=Number(r.scoreB??serverScoreB);lastScoreRevision=Number(r.score_rev??lastScoreRevision);
  const p=players.find(q=>Number(q.id)===Number(r.target_id||me.id));
  if(p){
    if(r.protected){p.spawnProtectedUntil=Number(r.spawn_protected_until_ms||p.spawnProtectedUntil||0);return;}
    p.hp=0;
    p.respawn=Math.max(RESPAWN_DELAY,Number(r.respawn||RESPAWN_DELAY));
    p.deaths=Math.max(Number(p.deaths||0),Number(r.deaths||0));
    p.deathSeq=Number(r.death_seq||p.deathSeq||1);
    p._serverRespawnAt=Number(r.respawn_at||0)*1000 || (performance.now()+RESPAWN_DELAY*1000);
    p.spawnProtectedUntil=Number(r.spawn_protected_until_ms||0);
    p.deathSpectateUntil=p._serverRespawnAt;
    p.weapon=null;
    p.ammo=0;
    if(p===me){
      deathOverlaySeq=p.deathSeq;
      deathOverlayUntil=p._serverRespawnAt;
    }
  }
  renderScoreHud();renderScoreboard();
}
async function reportEnvironmentDeath(p){
  if(!p||!roomId||p._envDeathPending)return; p._envDeathPending=true;
  try{const r=await api('web_player_death',{oda:roomId,cause:'environment',death_seq:Number(p.deathSeq||0)+1});await applyDeathResponse(r);}catch(e){}finally{setTimeout(()=>{p._envDeathPending=false;},400);}
}
async function reportBotEnvironmentDeath(p){
  if(!p||!roomId||p._envDeathPending)return; p._envDeathPending=true;
  try{const r=await api('web_bot_death',{oda:roomId,target_id:Number(p.id),cause:'environment',death_seq:Number(p.deathSeq||0)+1});await applyDeathResponse(r);}catch(e){}finally{setTimeout(()=>{p._envDeathPending=false;},400);}
}
function attack(p){if(p.respawn>0||paused||!p.weapon||p.ammo<=0)return;shoot(p);}
function movePlayer(p,dt){
  if(p.respawn>0){
    p.respawn=Math.max(0,p.respawn-dt);
    const waitMs=Number(p._serverRespawnAt||0)-performance.now();
    if(waitMs>0){p.respawn=Math.max(p.respawn,waitMs/1000);return;}
    if(p.respawn<=0){
      const sp=getSpawnPoint(p.team);p.hp=MAX_HP;p.weapon='pistol';p.ammo=ammoForWeapon('pistol');p.deathSpectateUntil=0;p._serverRespawnAt=0;p.y=sp.y;p.x=sp.x;p.vx=0;p.vy=0;p.ground=false;p.spawnProtectedUntil=performance.now()+SPAWN_PROTECTION_MS;
      if(p===me){deathOverlayUntil=0;localNetCorrectionX=0;localNetCorrectionY=0;}
    }
    return;
  }
  let dir=0;
  if(p===me){
    if(keys.left)dir-=1;if(keys.right)dir+=1;
  }else{
    const pickup = (!p.weapon || p.ammo<=0) ? pickups.reduce((best,d)=>{const dd=Math.hypot(d.x-p.x,d.y-p.y);return !best||dd<best.d?{d:dd,obj:d}:best;},null) : null;
    const t=nearestEnemy(p);
    if(pickup && pickup.obj){
      const dx=pickup.obj.x-p.x;
      const dist=Math.abs(dx);
      if(dist>48)dir=Math.sign(dx);
      else dir=0;
      if(Math.abs(pickup.obj.y-p.y)>100&&p.ground&&performance.now()>=(p.aiNextJump||0)){p.vy=-MOVE_CFG.jump;p.ground=false;p.aiNextJump=performance.now()+rnd(900,1800);}
    }else if(t){
      const dx=t.x-p.x, dist=Math.abs(dx);
      if(dist>300)dir=Math.sign(dx);
      else if(dist<135)dir=-(Math.sign(dx)||p.aiStrafe||1);
      else dir=p.aiStrafe||1;
      if(Math.random()<0.006)p.aiStrafe*=-1;
      if(Math.abs(t.y-p.y)>120&&p.ground&&performance.now()>=(p.aiNextJump||0)){p.vy=-MOVE_CFG.jump;p.ground=false;p.aiNextJump=performance.now()+rnd(1000,2100);}
    }
  }
  const speed=p===me?MOVE_CFG.speed:360;
  const target=dir*speed;
  const accel=dir?MOVE_CFG.accel:MOVE_CFG.brake;
  const delta=target-p.vx;
  const step=Math.sign(delta)*Math.min(Math.abs(delta),accel*dt);
  p.vx+=step;
  if(Math.abs(p.vx)<0.5)p.vx=0;
  if(dir!==0)p.facing=dir>0?1:-1;
  const moving=Math.abs(p.vx)>12;
  p.walkPhase=(p.walkPhase||0)+(moving?Math.abs(p.vx)*dt*0.032:dt*0.12);
  p.vy+=MOVE_CFG.gravity*dt;
  p.x+=p.vx*dt;p.y+=p.vy*dt;
  p.x=Math.max(28,Math.min(W-28,p.x));
  p.ground=hitPlatform(p)||p.y>=G-28;
  if(p.ground&&p.y>G-28){p.y=G-28;p.vy=0;}
  if(p===me&&keys.up&&p.ground){p.vy=-MOVE_CFG.jump;p.ground=false;keys.up=false;sfx('jump');}if(p===me&&keys.down&&!p.ground)p.vy+=900*dt;
  if(p!==me&&p.ground&&Math.random()<.012){p.vy=-MOVE_CFG.jump*.84;p.ground=false;}
  if(p.y>H+100){
    if(p===me&&adminGamemode){const sp=getSpawnPoint(me.team);me.x=sp.x;me.y=sp.y;me.vx=0;me.vy=0;me.hp=MAX_HP;return;}
    if(isSpawnProtected(p)){
      const sp=getSpawnPoint(p.team);p.x=sp.x;p.y=sp.y;p.vx=0;p.vy=0;p.ground=false;return;
    }
    if(roomId){
      if(p===me)reportEnvironmentDeath(p);
      else if(p.bot&&selectedOpponentMode==='bot')reportBotEnvironmentDeath(p);
    }
    kill(p,null,null,true);return;
  }
}
function aimFor(p){if(p===me&&mouse.active){const spectating=me.respawn>0;const liveTargets=players.filter(p=>p!==me&&p.real&&p.respawn<=0);if(spectating&&liveTargets.length){if(!spectatorTargetId||!liveTargets.some(p=>Number(p.id)===Number(spectatorTargetId)))spectatorTargetId=Number(liveTargets[0].id);const sp=liveTargets.find(p=>Number(p.id)===Number(spectatorTargetId))||liveTargets[0];spectatorTargetId=Number(sp.id);}const camTarget=spectating&&liveTargets.length?(liveTargets.find(p=>Number(p.id)===Number(spectatorTargetId))||liveTargets[0]):me;const desiredCam=Math.max(0,Math.min(W-canvas.width,camTarget.x-canvas.width/2));const cam=Math.round(cameraX+(desiredCam-cameraX)*.35);return {x:mouse.x+cam,y:mouse.y}}const t=nearestEnemy(p);return t?{x:t.x,y:t.y-20}:{x:p.x+1,y:p.y-20}}
async function authoritativeShot(p, angle, targetId=null){
  if(!roomId||!p||!p.weapon)return;
  const targetObj=targetId?players.find(q=>Number(q.id)===Number(targetId)):null;
  try{
    const action=p.bot?'web_bot_ates':'web_ates';
    const body={oda:roomId,target_id:targetId?Number(targetId):0,angle:Number(angle),attacker_x:Number(p.x||0),attacker_y:Number(p.y||0)};
    if(p.bot)body.attacker_id=Number(p.id);
    let r=await api(action,body);
    if(!r.ok){
      // Eski DB şemalarında web_ates/score_rev uyumsuzluğu varsa legacy saldırı
      // endpoint'ine kontrollü fallback yap. Böylece atış tamamen kaybolmaz.
      const fallbackAction=p.bot?'web_bot_saldiri':'web_saldiri';
      const fallbackBody={oda:roomId,target_id:targetId?Number(targetId):0,facing:Number(p.facing||1),attacker_x:Number(p.x||0),attacker_y:Number(p.y||0),target_x:Number(targetId&&targetObj?.x||0),target_y:Number(targetId&&targetObj?.y||0)};
      if(p.bot){fallbackBody.attacker_id=Number(p.id);}
      const fb=await api(fallbackAction,fallbackBody);
      if(fb.ok) {
        r=fb;
      } else {
        // Hedef konumu eşleşmediyse sunucunun kendi ray/hit taramasını dene.
        const retryBody={...body,target_id:0};
        if(p.bot) retryBody.attacker_id=Number(p.id);
        const retry=await api(action,retryBody);
        if(retry.ok) r=retry;
        else {if(r.mesaj&&!p.bot)addMsg('ATIŞ SENKRONU • '+r.mesaj); return;}
      }
    }
    p.ammo=Number(r.ammo??p.ammo); if(r.weapon!==undefined)p.weapon=r.weapon||null;
    if(r.target_id){const victim=players.find(q=>Number(q.id)===Number(r.target_id));if(victim){victim.hp=Number(r.hp??victim.hp);victim.respawn=Number(r.respawn??victim.respawn);victim.deaths=Number(r.deaths??victim.deaths);victim.deathSeq=Number(r.death_seq??victim.deathSeq);victim.spawnProtectedUntil=Number(r.spawn_protected_until_ms??victim.spawnProtectedUntil??0);if(r.killed){victim.weapon=null;victim.ammo=0;}}}
    const killer=players.find(q=>Number(q.id)===Number(r.killer_id||p.id));if(killer&&r.killer_kills!==undefined){killer.kills=Number(r.killer_kills);}
    serverScoreA=Number(r.scoreA??serverScoreA);serverScoreB=Number(r.scoreB??serverScoreB);lastScoreRevision=Number(r.score_rev??lastScoreRevision);
    if(p===me && r.xp_total!==undefined) applyProgress(r,true);
    renderScoreHud();renderScoreboard();if(r.killed)pollKillFeed(true);if(r.hit)sfx('hit');if(r.killed)sfx('kill');
  }catch(e){console.debug('[StickArena] authoritative shot',e)}
}
function shoot(p){
  if(p.respawn>0||!p.weapon||p.ammo<=0)return;
  const w=WEAPONS[p.weapon]||WEAPONS.pistol,now=performance.now();
  if(p===me){if(!keys.attack&&!mouse.down)return;if(now<shootCooldown)return;shootCooldown=now+w.cooldown;}
  else if(now-(p.lastShot||0)<Math.max(140,w.cooldown*rnd(.9,1.25)))return;
  /* Botlar hedefi bulamıyorsa asla ateş etmez; böylece yere mermi harcamazlar. */
  const target = p.bot ? nearestEnemy(p) : (rayTarget(p,base)||nearestEnemy(p));
  if(p.bot && !target)return;

  let a=target ? {x:target.x,y:target.y-20} : aimFor(p);
  let dx=a.x-p.x,dy=a.y-(p.y-42),d=Math.hypot(dx,dy)||1;if(d>w.range+250)return;
  let base=Math.atan2(dy,dx);

  /* Bot isabet oranını düşür: her atışta kontrollü açı hatası + bazı miss atışları.
   * Kritik nokta: bot sunucuya target_id göndermiyor; server kendi raycast'i ile
   * bu hatalı nişanın gerçekten isabet edip etmediğini belirliyor. */
  if(p.bot){
    const accuracy=Math.max(.45,Math.min(.85,Number(p.aiAccuracy||BOT_ACCURACY)));
    const miss=Math.random()>accuracy;
    const magnitude=rnd(BOT_MIN_AIM_ERROR,BOT_MAX_AIM_ERROR)*(miss?1.8:1);
    const sign=Math.random()<.5?-1:1;
    base+=sign*magnitude;
    p.facing=Math.cos(base)>=0?1:-1;
  }else{
    p.facing=dx>=0?1:-1;
  }

  const spread=p.weapon==='shotgun'?0.075:(p.bot?0.018:0.01);
  const count=p.weapon==='shotgun'?5:1;
  for(let n=0;n<count;n++){const ang=base+(n-(count-1)/2)*spread;const speed=p.weapon==='rpg'?760:1450;bullets.push({x:p.x+p.facing*28,y:p.y-48,vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,team:p.team,owner:p.id,life:1.5,damage:w.damage,kind:p.weapon,shotAngle:ang});}
  if(!adminGamemode||p!==me){p.ammo=Math.max(0,p.ammo-1);}p.lastShot=now;sfx(w.sound);attackBurst(p,p.x+p.facing*31,p.y-48);

  /* Gerçek oyuncu: server-side target lock + raycast fallback.
   * Bot: sadece açı gönder, server raycast yaparak gerçekten vurup vurmadığını seçsin. */
  if(p===me)authoritativeShot(p,base,target?.id||0);
  else if(p.bot)authoritativeShot(p,base,0);

  if(p.ammo===0){p.weapon=null;if(p===me)addMsg('ŞARÖR BİTTİ • Yeni silah al.');}
}
function kill(victim,killerTeam,killerId,force=false){
  if(isSpawnProtected(victim))return;
  if(!force&&(victim.respawn>0||victim.hp<=0))return;
  if(!force&&victim.respawn>0)return;
  const wasDead=victim.respawn>0;
  victim.hp=0;victim.deaths=wasDead?victim.deaths:(victim.deaths||0)+1;victim.respawn=RESPAWN_DELAY;victim._serverRespawnAt=performance.now()+RESPAWN_DELAY*1000;victim.deathSeq=(victim.deathSeq||0)+1;victim.deathSpectateUntil=victim._serverRespawnAt;victim.weapon=null;victim.ammo=0;
  const killer=killerId?players.find(p=>Number(p.id)===Number(killerId)):null;if(killer){killer.kills++;renderScoreboard();sfx('kill')}
  sfx('kill');makeParticle(victim.x,victim.y-22,'#ff526d',.7,34,340);for(let i=0;i<12;i++){const a=Math.random()*Math.PI*2;particles.push({x:victim.x,y:victim.y-22,vx:Math.cos(a)*rnd(80,260),vy:Math.sin(a)*rnd(80,260)-90,life:.8,color:i%2?'#ffb14d':'#ff526d',size:rnd(3,7)});}
  if(victim===me&&deathOverlaySeq!==victim.deathSeq){deathOverlaySeq=victim.deathSeq;deathOverlayUntil=performance.now()+RESPAWN_DELAY*1000;addMsg('ÖLDÜN • 10 saniye sonra yeniden doğacaksın.')}
}
function killFromServer(victim,killerTeam,killerId){
  if(victim._serverDeathSeq===victim.deathSeq&&victim.respawn>0)return;
  victim._serverDeathSeq=victim.deathSeq=(victim.deathSeq||0)+1;victim.hp=0;victim.respawn=RESPAWN_DELAY;victim._serverRespawnAt=performance.now()+RESPAWN_DELAY*1000;victim.deathSpectateUntil=victim._serverRespawnAt;victim.weapon=null;victim.ammo=0;
  const killer=killerId?players.find(q=>Number(q.id)===Number(killerId)):null;if(killer){killer.kills=Math.max(killer.kills||0,(killer===me?me.kills:killer.kills||0));}
  sfx('kill');makeParticle(victim.x,victim.y,'#ff5e78',.55,26,280);
  if(victim===me){deathOverlaySeq=victim.deathSeq;deathOverlayUntil=performance.now()+RESPAWN_DELAY*1000;addMsg('ÖLDÜN • 10 saniye sonra yeniden doğacaksın. İzleme modu aktif. Keyifli oyunlar!');}
}
function applyRemotePlayerState(rp){
 const p=players.find(q=>Number(q.id)===Number(rp.id));if(!p)return;const incomingHp=Math.max(0,Number(rp.hp??p.hp));
 if(incomingHp<=0){const seq=Number(rp.deathSeq??rp.death_seq??0);if(p.respawn<=0||(seq&&seq!==Number(p._serverDeathSeq||0))){p.hp=0;p.respawn=Math.max(RESPAWN_DELAY,Number(rp.respawn||RESPAWN_DELAY));p._serverDeathSeq=seq||Number(p._serverDeathSeq||0)+1;p._serverRespawnAt=Number(rp.respawn_at||0)*1000 || performance.now()+RESPAWN_DELAY*1000;p.spawnProtectedUntil=Number(rp.spawn_protected_until_ms||0);if(p===me){deathOverlaySeq=p._serverDeathSeq;deathOverlayUntil=performance.now()+RESPAWN_DELAY*1000;addMsg('ÖLDÜN • 10 saniye sonra yeniden doğacaksın. İzleme modu aktif.');}else{sfx('kill');}}else p.hp=0;}else{p.hp=incomingHp;p.respawn=Math.max(0,Number(rp.respawn||0));p.spawnProtectedUntil=Number(rp.spawn_protected_until_ms||p.spawnProtectedUntil||0);}
 const nx=Number(rp.x??p.x),ny=Number(rp.y??p.y),now=performance.now();p.netX=nx;p.netY=ny;p.netVx=Number(rp.vx||0);p.netVy=Number(rp.vy||0);p._netAt=now;p._lastAckX=nx;p._lastAckY=ny;p.team=rp.team==='B'?'B':'A';p.weapon=rp.weapon||null;p.ammo=Number(rp.ammo||0);p.kills=Math.max(Number(p.kills||0),Number(rp.kills||0));p.deaths=Math.max(Number(p.deaths||0),Number(rp.deaths||0));
}

function smoothRemotePlayers(dt){
 const now=performance.now();
 for(const p of players){if(!p.real||p===me||p.respawn>0||p.netX==null)continue;const age=Math.min(0.08,Math.max(0,(now-(p._netAt||now))/1000));const tx=p.netX+(p.netVx||0)*age*0.35,ty=p.netY+(p.netVy||0)*age*0.35;const dx=tx-p.x,dy=ty-p.y,dist=Math.hypot(dx,dy);
   if(dist>260){p.x=tx;p.y=ty;}else{const rate=dist>90?28:18;const t=Math.min(1,dt*rate);p.x+=dx*t;p.y+=dy*t;}
   p.vx=(p.x-(p._prevSmoothX??p.x))/Math.max(dt,0.001);p.vy=(p.y-(p._prevSmoothY??p.y))/Math.max(dt,0.001);p._prevSmoothX=p.x;p._prevSmoothY=p.y;
   if(Math.abs(p.netVx)>12){p.facing=p.netVx>0?1:-1;p.walkPhase=(p.walkPhase||0)+Math.abs(p.netVx)*dt*0.042;}else{p.walkPhase=(p.walkPhase||0)+dt*0.35;}
 }
}

function update(dt){
  if(!matchStarted||finished)return;
  if(paused){const netNow=performance.now();if(netNow-lastSync>=NET_HEARTBEAT_MS)syncMatch();if(netNow-lastRemoteStatePoll>=REMOTE_POLL_MS)pollRemoteState();if(netNow-lastScorePoll>=SCORE_POLL_MS)pollScoreboard();return;}
  smoothRemotePlayers(dt);
  if(localNetCorrectionX||localNetCorrectionY){const k=Math.min(1,dt*14);me.x+=(localNetCorrectionX||0)*k;me.y+=(localNetCorrectionY||0)*k;localNetCorrectionX*=1-k;localNetCorrectionY*=1-k;}
  const elapsed=(performance.now()-startedAt)/1000;if(elapsed>=MATCH){finish();return;}
  movePlayer(me,dt);attack(me);updateDrops(dt);
  for(const p of players){if(p!==me){if(p.real)continue;movePlayer(p,dt);if(p.weapon&&p.ammo>0)shoot(p);}}
  for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];const prevX=b.x,prevY=b.y;b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;if(b.life<=0||b.x<0||b.x>W){bullets.splice(i,1);continue}
    let hit=null,best=Infinity;
    for(const p of players){if(p.respawn>0||p.team===b.team||Number(p.id)===Number(b.owner))continue;const px=p.x,py=(p.y-76);const vx=b.x-prevX,vy=b.y-prevY;const len2=vx*vx+vy*vy;const t=len2?Math.max(0,Math.min(1,((px-prevX)*vx+(py-prevY)*vy)/len2)):0;const cx=prevX+vx*t,cy=prevY+vy*t;const dist=Math.hypot(px-cx,py-cy);const radius=normalizeWeaponId(b.kind)==='shotgun'?78:68;if(dist<radius&&dist<best){best=dist;hit=p;}}
    if(hit){sfx('hit');const owner=players.find(p=>Number(p.id)===Number(b.owner));attackBurst(owner||me,b.x,b.y);if(normalizeWeaponId(b.kind)==='rpg')particles.push({x:b.x,y:b.y,vx:0,vy:0,life:.34,maxLife:.34,fx:'explosion'});bullets.splice(i,1);}}
  particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=(p.flash||p.fx)?0:600*dt;p.life-=dt});particles=particles.filter(p=>p.life>0);
  const remain=Math.max(0,Math.floor(MATCH-elapsed));
  const autoRound=Math.floor(elapsed/AUTO_MAP_INTERVAL);
  if(autoRound!==lastAutoMapRound){
    lastAutoMapRound=autoRound;
    if(autoRound>0){
      const idx=(MAP_ORDER.indexOf(currentMap)+1)%MAP_ORDER.length;
      applyMap(MAP_ORDER[idx]);
    }
  }
  serverRemaining=remain;const timeEl=document.getElementById('sure');if(timeEl)timeEl.textContent=String(Math.floor(remain/60)).padStart(2,'0')+':'+String(remain%60).padStart(2,'0');const nowHud=performance.now();if(nowHud-lastScoreHudAt>=100){renderScoreHud();lastScoreHudAt=nowHud;}const netNow=performance.now();if(netNow-lastSync>=NET_HEARTBEAT_MS)syncMatch();if(netNow-lastRemoteStatePoll>=REMOTE_POLL_MS)pollRemoteState();if(netNow-lastScorePoll>=SCORE_POLL_MS)pollScoreboard();if(netNow-lastKillFeedPoll>=KILLFEED_POLL_MS)pollKillFeed();updatePlayerHud();
}
function updatePlayerHud(){
  const now=performance.now();
  if(now-lastHudUiAt<80)return;
  lastHudUiAt=now;
  updateProgressUi();
  const hp=document.getElementById('playerHpFill');if(hp)hp.style.width=Math.max(0,Math.min(100,(me.hp/MAX_HP)*100))+'%';
  const ht=document.getElementById('playerHpText');if(ht)ht.textContent='HP: '+Math.max(0,Math.ceil(me.hp));
  const nm=document.getElementById('playerHudName');if(nm)nm.textContent=me.name||'Oyuncu';
  const eq=document.getElementById('playerLoadout');
  if(eq){
    const wid=normalizeWeaponId(me.weapon);
    const max=ammoForWeapon(wid);
    const wn=document.getElementById('playerWeaponName');
    const ac=document.getElementById('playerAmmoCount');
    if(wn)wn.textContent=me.weapon?(WEAPONS[wid]?.ad||'SİLAH'):'SİLAH YOK';
    if(ac)ac.textContent=me.weapon?(me.ammo+'/'+max):'0/0';
  }
}
function teamColor(team){return team==='B'?'#54d7ff':'#ff5a73';}
function mixedColor(hexA,hexB,t){const a=hexA.replace('#',''),b=hexB.replace('#','');const ar=parseInt(a.slice(0,2),16),ag=parseInt(a.slice(2,4),16),ab=parseInt(a.slice(4,6),16);const br=parseInt(b.slice(0,2),16),bg=parseInt(b.slice(2,4),16),bb=parseInt(b.slice(4,6),16);const f=v=>Math.round(v).toString(16).padStart(2,'0');return '#'+f(ar*(1-t)+br*t)+f(ag*(1-t)+bg*t)+f(ab*(1-t)+bb*t);}
function drawCharacter(p){
  const glow=p.team==='A'?'#ff405f':'#27dfff';
  const requested=normalizeCharacterId(p.character,p.team);
  const key=requested==='gold'?'gold':(p.team==='A'?'red':'blue');
  const im=images.chars[key];
  const moving=Math.min(1,Math.abs(p.vx||0)/MOVE_CFG.speed);
  const phase=p.walkPhase||0;
  const bob=moving?Math.sin(phase*1.65)*1.2:0;
  const sway=moving?Math.sin(phase*1.9)*0.018:0;
  const size=CHARACTER_RENDER_SIZE;

  // p.y karakterin fizik tabanının 28px üzerindedir.
  // Sprite'ın alt kenarı doğrudan platform yüksekliğine oturtulur.
  const footY=p.y+CHARACTER_GROUND_OFFSET;

  ctx.save();
  ctx.translate(p.x,footY+bob);
  ctx.scale(p.facing<0?-1:1,1);
  ctx.rotate(sway);

  if(im?.complete&&im.naturalWidth){
    ctx.shadowColor=glow;
    ctx.shadowBlur=14;
    ctx.drawImage(im,-size/2,-size,size,size);
  }else{
    ctx.shadowColor=glow;
    ctx.shadowBlur=10;
    ctx.strokeStyle=glow;
    ctx.lineWidth=5;
    ctx.lineCap='round';
    ctx.beginPath();
    ctx.arc(0,-145,18,0,Math.PI*2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0,-126);ctx.lineTo(0,-78);
    ctx.moveTo(0,-112);ctx.lineTo(28,-90);
    ctx.moveTo(0,-112);ctx.lineTo(-28,-90);
    ctx.moveTo(0,-78);ctx.lineTo(30,-25);
    ctx.moveTo(0,-78);ctx.lineTo(-30,-25);
    ctx.stroke();
  }

  ctx.restore();
  drawHeldWeapon(p,glow);
}

function drawHeldWeapon(p,teamColor){
  if(!p.weapon)return;

  const id=normalizeWeaponId(p.weapon);
  const im=images.weapons[id];
  const w=WEAPONS[id]||WEAPONS.pistol;
  const size=WEAPON_SIZES[id]||[82,30];
  const aim=aimFor(p);

  // Eller yaklaşık olarak sprite'ın gövde merkezinde.
  const handX=p.x+(p.facing||1)*34;
  const handY=p.y-78;

  let angle=Math.atan2(
    aim.y-handY,
    aim.x-handX
  );

  if(Math.cos(angle)*(p.facing||1)<0){
    angle=Math.PI+angle;
  }

  ctx.save();
  ctx.translate(handX,handY);
  ctx.scale(p.facing<0?-1:1,1);

  const localAngle=
    p.facing<0
      ?Math.atan2(-Math.sin(angle),Math.cos(angle))
      :angle;

  ctx.rotate(localAngle);
  ctx.shadowColor=teamColor;
  ctx.shadowBlur=12;

  if(im?.complete&&im.naturalWidth){
    const gripOffset=Math.max(10,size[0]*.18);
    ctx.drawImage(
      im,
      -gripOffset,
      -size[1]/2,
      size[0],
      size[1]
    );
  }else{
    ctx.fillStyle=w.color;
    ctx.fillRect(
      0,-4,
      size[0]*.72,
      8
    );
  }

  ctx.restore();
}

function draw(){ctx.clearRect(0,0,canvas.width,canvas.height);const spectating=me.respawn>0;const liveTargets=players.filter(p=>p!==me&&p.real&&p.respawn<=0);if(spectating&&liveTargets.length){if(!spectatorTargetId||!liveTargets.some(p=>Number(p.id)===Number(spectatorTargetId)))spectatorTargetId=Number(liveTargets[0].id);const sp=liveTargets.find(p=>Number(p.id)===Number(spectatorTargetId))||liveTargets[0];spectatorTargetId=Number(sp.id);}const camTarget=spectating&&liveTargets.length?(liveTargets.find(p=>Number(p.id)===Number(spectatorTargetId))||liveTargets[0]):me;const desiredCam=Math.max(0,Math.min(W-canvas.width,camTarget.x-canvas.width/2));cameraX+= (desiredCam-cameraX)*Math.min(1,1-Math.pow(0.001,1/60));const cam=Math.round(cameraX);ctx.save();ctx.translate(-cam,0);ctx.fillStyle='#071522';ctx.fillRect(cam,0,canvas.width,H);const surface=getMapSurface();if(surface){ctx.globalAlpha=.94;ctx.drawImage(surface,0,0,W,H);ctx.globalAlpha=1}const grd=ctx.createLinearGradient(cam,0,cam,H);grd.addColorStop(0,'rgba(7,27,45,.15)');grd.addColorStop(1,'rgba(8,19,31,.55)');ctx.fillStyle=grd;ctx.fillRect(cam,0,canvas.width,H);for(const p of mapPlatforms){ctx.save();ctx.strokeStyle='rgba(131,235,255,.10)';ctx.lineWidth=1;ctx.setLineDash([6,8]);ctx.strokeRect(p.x+1,p.y+1,Math.max(0,p.w-2),Math.max(0,p.h-2));ctx.setLineDash([]);ctx.restore();}ctx.fillStyle='rgba(4,10,15,.10)';ctx.fillRect(0,G,W,H-G);for(const b of bullets){const w=WEAPONS[normalizeWeaponId(b.kind)]||WEAPONS.pistol;const trail=normalizeWeaponId(b.kind)==='rpg'?28:42;ctx.save();ctx.strokeStyle=w.color;ctx.shadowColor=w.color;ctx.shadowBlur=normalizeWeaponId(b.kind)==='rpg'?16:8;ctx.lineWidth=normalizeWeaponId(b.kind)==='awp'?3:2;ctx.globalAlpha=.92;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x-b.vx*trail/1200,b.y-b.vy*trail/1200);ctx.stroke();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(b.x,b.y,normalizeWeaponId(b.kind)==='rpg'?5:2.5,0,Math.PI*2);ctx.fill();ctx.restore();}
for(const p of particles){if(p.fx){const fim=images.fx[p.fx];ctx.save();ctx.globalAlpha=Math.max(.05,p.life/(p.maxLife||.2));if(fim?.complete&&fim.naturalWidth){const sz=p.fx==='explosion'?88:64;ctx.drawImage(fim,p.x-sz/2,p.y-sz/2,sz,sz);}ctx.restore();continue;}if(p.flash){ctx.save();ctx.globalAlpha=Math.max(0,p.life/(p.maxLife||.1));ctx.shadowColor=p.color;ctx.shadowBlur=18;ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,Math.max(2,(p.size||10)*p.life/(p.maxLife||.1)),0,Math.PI*2);ctx.fill();ctx.restore();}}for(const d of pickups){ctx.save();ctx.translate(d.x,d.y);ctx.shadowBlur=18;ctx.shadowColor=(WEAPONS[normalizeWeaponId(d.id)]?.color||'#fff');ctx.fillStyle='#0b1d28';ctx.beginPath();ctx.arc(0,0,24,0,Math.PI*2);ctx.fill();const im=images.weapons[d.id];if(im?.complete&&im.naturalWidth)ctx.drawImage(im,-24,-24,48,48);ctx.fillStyle='#eaffff';ctx.font='700 10px Arial';ctx.textAlign='center';ctx.fillText('SİLAH',0,38);ctx.restore();}
for(const p of particles){if(p.flash||p.fx)continue;ctx.globalAlpha=Math.max(0,p.life*2);ctx.fillStyle=p.color;ctx.fillRect(p.x,p.y,p.size||5,p.size||5);ctx.globalAlpha=1}for(const p of players){
  if(p.respawn>0)continue;
  const protectedNow=isSpawnProtected(p);
  if(protectedNow){ctx.save();const pulse=1+Math.sin(performance.now()/90)*.06;ctx.translate(p.x,p.y-86);ctx.scale(pulse,pulse);ctx.strokeStyle='rgba(255,220,116,.95)';ctx.shadowColor='#ffd66c';ctx.shadowBlur=20;ctx.lineWidth=4;ctx.globalAlpha=.82;ctx.beginPath();ctx.arc(0,0,68+Math.sin(performance.now()/120)*5,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=.17;ctx.fillStyle='#ffd66c';ctx.beginPath();ctx.arc(0,0,68,0,Math.PI*2);ctx.fill();ctx.restore();}
  drawCharacter(p);
  const labelY=p.y-170;
  const clanY=p.y-186;
  const hpY=p.y-154;
  ctx.textAlign='center';
  ctx.font=p===me?'800 13px Arial':'700 12px Arial';
  ctx.fillStyle='#f4fcff';
  ctx.shadowColor='#000';
  ctx.shadowBlur=5;
  ctx.fillText((p.dogrulanmis||p.admin?'✓ ':'')+(p.name||'Oyuncu'),p.x,labelY);
  if(p.klan){
    ctx.fillStyle=p.team==='A'?'#ff9aae':'#8beaff';
    ctx.font='700 10px Arial';
    ctx.fillText('['+p.klan+']',p.x,clanY);
  }
  ctx.shadowBlur=0;
  ctx.fillStyle='#18232c';
  ctx.fillRect(p.x-25,hpY,50,5);
  ctx.fillStyle=p.team==='A'?'#ff5b78':'#4ddfff';
  ctx.fillRect(p.x-25,hpY,50*(Math.max(0,p.hp)/MAX_HP),5);
}ctx.restore();

if(deathOverlayUntil>performance.now()){const left=Math.max(0,Math.ceil((deathOverlayUntil-performance.now())/1000));ctx.save();ctx.fillStyle='rgba(1,6,11,.62)';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.textAlign='center';ctx.fillStyle='#ff6f86';ctx.font='900 62px Inter,Arial';ctx.fillText('ÖLDÜN',canvas.width/2,282);ctx.fillStyle='#eafaff';ctx.font='700 22px Inter,Arial';ctx.fillText(left+' saniye sonra yeniden doğacaksın',canvas.width/2,325);ctx.fillStyle='#83dfff';ctx.font='600 15px Inter,Arial';ctx.fillText('İzleme modu aktif • takım arkadaşını izliyorsun',canvas.width/2,356);ctx.restore();}
if(teamSwapPending){const left=Math.max(0,Math.ceil((teamSwapNoticeUntil-performance.now())/1000));ctx.save();ctx.fillStyle='rgba(3,10,17,.78)';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.textAlign='center';ctx.fillStyle='#8feaff';ctx.font='900 42px Inter,Arial';ctx.fillText('TAKIMLAR DEĞİŞİYOR',canvas.width/2,270);ctx.fillStyle='#fff';ctx.font='800 28px Inter,Arial';ctx.fillText(Math.max(0,left)+' saniye',canvas.width/2,315);ctx.font='600 18px Inter,Arial';ctx.fillStyle='#9bc6d5';ctx.fillText('Bol şanslar dileriz!',canvas.width/2,350);ctx.restore();}
if(finished){const left=Math.max(0,Math.ceil((matchEndNoticeUntil-performance.now())/1000));ctx.fillStyle='rgba(3,10,17,.86)';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#9beaff';ctx.textAlign='center';ctx.font='900 48px Inter,Arial';ctx.fillText('MAÇ SONA ERDİ',canvas.width/2,260);ctx.font='700 22px Inter,Arial';ctx.fillStyle='#eafaff';ctx.fillText('Tekrar yeni bir harita seçerek başlayabilirsin.',canvas.width/2,310);ctx.font='800 18px Inter,Arial';ctx.fillStyle='#79dfff';ctx.fillText(Math.max(0,left)+' saniye',canvas.width/2,350)}
updatePlayerHud();}
function finish(){if(finished)return;finished=true;document.body.classList.remove('sa-match-active');setStatus('MAÇ SONA ERDİ');addMsg('MAÇ SONA ERDİ • 5 saniye sonra yeni bir harita seçerek tekrar başlayabilirsin.');matchEndNoticeUntil=performance.now()+5000;if(remoteReady){api('web_mac_bitir',{oda:roomId}).then(r=>{const row=(r?.oyuncular||[]).find(x=>Number(x.kullanici_id)===Number(me.id));if(row){const before=Math.max(1,Number(me.level)||levelFromXp(me.xp||0));me.xp=Math.max(0,Number(row.xp_toplam??me.xp));me.level=Math.max(1,Math.min(MAX_LEVEL,Number(row.seviye??levelFromXp(me.xp))));updateProgressUi();if(me.level>before)showLevelUp(me.level,Number(row.xp||0));}}).catch(()=>{});}setTimeout(()=>location.reload(),5000)}
function reset(){
  finished=false;bullets=[];particles=[];pickups=[];nextDropAt=0;shootCooldown=0;deathOverlayUntil=0;localNetCorrectionX=0;localNetCorrectionY=0;mapSurfaceId='';mapSurface=null;cameraX=0;
  players.forEach((p)=>{
    if(!Number.isFinite(p.x)||!Number.isFinite(p.y)){const sp=getSpawnPoint(p.team);p.x=sp.x;p.y=sp.y;}
    p.vx=0;p.vy=0;p.facing=p.team==='A'?1:-1;p.hp=Number.isFinite(p.hp)?p.hp:MAX_HP;p.respawn=Math.max(0,Number(p.respawn||0));
    p.kills=Number(p.kills||0);p.deaths=Number(p.deaths||0);
    p.weapon=normalizeWeaponId(p.weapon||(p===me?equipment.silah:'pistol'));p.ammo=Number.isFinite(Number(p.ammo))&&Number(p.ammo)>0?Number(p.ammo):ammoForWeapon(p.weapon);
    p.character=normalizeCharacterId(p.character,p.team);p.walkPhase=Number(p.walkPhase||0);p.netX=p.x;p.netY=p.y;p._prevSmoothX=p.x;p._prevSmoothY=p.y;
  });
  renderScoreHud();renderScoreboard();
}
async function boot(){
  try{
    renderMapCards();
    const ok=await loadCurrentUser();
    if(!ok){document.getElementById('lobbyStatus').textContent='Oyuna katılmak için giriş yapmalısın.';return;}
    await loadEquipment();
    setupEmoji();
    document.querySelectorAll('#opponentSelector [data-opponent]').forEach(btn=>btn.addEventListener('click',()=>{selectedOpponentMode=btn.dataset.opponent==='bot'?'bot':'real';document.querySelectorAll('#opponentSelector [data-opponent]').forEach(x=>x.classList.toggle('is-selected',x===btn));addMsg('EŞLEŞME TÜRÜ • '+(selectedOpponentMode==='bot'?'BOTLARA KARŞI':'GERÇEK OYUNCULAR'));}));
    document.getElementById('lobbyMode').textContent=GAME_MODE==='clan'?'10v10 KLAN':'5v5 NORMAL';
    document.getElementById('cancelLobby').onclick=async()=>{
      if(matchStarted){await leaveMatch();return;}
      const leaving=lobbyId;
      if(leaving) await api('web_lobi_iptal',{lobi:leaving});
      lobbyId='';lobbyJoined=false;lobbyPolling=false;showLobbyInviteCode('');document.getElementById('cancelLobby').style.display='none';
      document.getElementById('lobbyStatus').textContent='Bir harita seçerek yeni lobi oluştur.';document.getElementById('lobbyPlayers').innerHTML='';
    setStatus('HARİTA SEÇİMİ');
    };
    document.getElementById('chatForm').addEventListener('submit',async e=>{
      e.preventDefault();e.stopPropagation();const input=document.getElementById('chatInput');const msg=input.value.trim();
      if(!msg||!roomId)return;
      const gmMatch=msg.match(/^(?:\/|!|)(?:gamemode|gm)\s+([01])$/i);
      if(me.admin&&gmMatch){
        const mode=Number(gmMatch[1])===1?1:0;
        const gm=await api('admin_gamemode',{oda:roomId,mode});
        if(gm.ok){adminGamemode=!!gm.enabled;addMsg('GAMEMODE • '+(adminGamemode?'ÖLÜMSÜZ + SINIRSIZ MERMİ':'KAPALI'));showAdminAnnouncement(adminGamemode?'GAMEMODE 1 AKTİF • Yönetici ölümsüz + sınırsız mermi.':'GAMEMODE KAPATILDI');}else{addMsg('GAMEMODE AYARI BAŞARISIZ • '+(gm.mesaj||'Sunucu hatası'));showAdminAnnouncement('GAMEMODE AYARLANAMADI • '+(gm.mesaj||'Sunucu hatası'),3800);}
        input.value='';input.blur();return;
      }
      const annMatch=msg.match(/^(?:\/|!|)(?:duyuru|announce|broadcast)\s+(.+)$/i);
      if(me.admin&&annMatch){
        const text=annMatch[1].trim();
        if(text){const an=await api('admin_duyuru_yayinla',{oda:roomId,baslik:'Yönetici Duyurusu',icerik:text});if(an.ok){const cid=Number(an.chat_id||0);if(cid){chatLastId=Math.max(chatLastId,cid);lastAdminAnnouncementChatId=Math.max(lastAdminAnnouncementChatId,cid);}lastAnnouncementId=Math.max(lastAnnouncementId,Number(an.id||0));showAdminAnnouncement(text);addMsg('📢 DUYURU YAYINLANDI');}else{addMsg('DUYURU GÖNDERİLEMEDİ • '+(an.mesaj||''));showAdminAnnouncement('DUYURU GÖNDERİLEMEDİ • '+(an.mesaj||''),3800);}}
        input.value='';input.blur();return;
      }
      const r=await api('web_chat_gonder',{oda:roomId,mesaj:msg});if(r.ok){input.value='';if(r.kayit){lastChatRows=[...(lastChatRows||[]),r.kayit].slice(-80);chatLastId=Math.max(chatLastId,Number(r.kayit.id||0));renderChat(lastChatRows);if(r.kayit.admin||isAdminRole(r.kayit.yetki)){lastAdminAnnouncementChatId=Math.max(lastAdminAnnouncementChatId,Number(r.kayit.id||0));showAdminAnnouncement(r.kayit.mesaj||msg);}}input.focus();await updateChat();}else{addMsg('Sohbet gönderilemedi • '+(r.mesaj||'Sunucu hatası'));input.focus();}
    });
    setStatus('HARİTA SEÇİMİ');
  }catch(e){
    console.error(e);
    const d=document.getElementById('durum');if(d)d.textContent='OYUN MOTORU HATASI';
    const m=document.getElementById('mesajlar');if(m)m.innerHTML='<div style="color:#ff8fa3">'+esc(e.message||e)+'</div>';
    fetch('api.php?action=client_log',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({olay:'JS_RUNTIME_HATASI',detay:String(e.stack||e)})}).catch(()=>{});
  }
}
canvas.tabIndex=0;canvas.setAttribute('aria-label','Stick Arena oyun alanı');canvas.addEventListener('pointerdown',()=>{try{canvas.focus({preventScroll:true});}catch(_){try{canvas.focus();}catch(__){}}});canvas.addEventListener('mousemove',e=>{const r=canvas.getBoundingClientRect();mouse.x=(e.clientX-r.left)*canvas.width/r.width;mouse.y=(e.clientY-r.top)*canvas.height/r.height;mouse.active=true});
canvas.addEventListener('mousedown',e=>{audioInit();e.preventDefault();mouse.down=true;if(e.button===0)keys.attack=true});
window.addEventListener('mouseup',()=>{mouse.down=false;keys.attack=false});
function clearMovementKeys(){keys.left=false;keys.right=false;keys.up=false;keys.down=false;keys.attack=false;mouse.down=false;}
window.addEventListener('blur',clearMovementKeys);window.addEventListener('pagehide',clearMovementKeys);
window.addEventListener('keydown',e=>{
  const code=e.code||'';
  const movementCode=['KeyA','KeyD','KeyW','KeyS','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'];
  if(e.target&&(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))){
    if(matchStarted&&movementCode.includes(code)){
      e.preventDefault();
      try{e.target.blur();}catch(_){}
    }else{return;}
  }
  audioInit();
  if(code==='Tab'&&matchStarted){e.preventDefault();scoreboardOpen=true;renderScoreboard();return;}
  if(['KeyA','KeyD','KeyW','KeyS','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space','KeyR','KeyF'].includes(code))e.preventDefault();
  if(code==='KeyA'||code==='ArrowLeft')keys.left=true;
  if(code==='KeyD'||code==='ArrowRight')keys.right=true;
  if(code==='KeyW'||code==='ArrowUp')keys.up=true;
  if(code==='KeyS'||code==='ArrowDown')keys.down=true;
  if(code==='Space')keys.attack=true;
  if(code==='KeyF')dropHeldItem(me);
  if(code==='Escape'&&matchStarted){e.preventDefault();leaveMatch();return;}
  if(code==='KeyR'&&finished)location.reload();
});
window.addEventListener('keyup',e=>{
  if((e.code||'')==='Tab'&&scoreboardOpen){scoreboardOpen=false;renderScoreboard();return;}
  const code=e.code||'';
  if(code==='KeyA'||code==='ArrowLeft')keys.left=false;
  if(code==='KeyD'||code==='ArrowRight')keys.right=false;
  if(code==='KeyW'||code==='ArrowUp')keys.up=false;
  if(code==='KeyS'||code==='ArrowDown')keys.down=false;
  if(code==='Space')keys.attack=false;
});
async function leaveMatch(){
  if(!roomId)return;
  if(!confirm('Maçtan ayrılmak istediğine emin misin?'))return;
  const oda=roomId;
  try{await api('web_mac_ayril',{oda});}catch(e){}
  matchStarted=false;finished=true;remoteReady=false;lobbyJoined=false;
  if(gameRafId){cancelAnimationFrame(gameRafId);gameRafId=0;}
  document.body.classList.remove('sa-match-active');
  const canvasEl=document.getElementById('oyun');if(canvasEl)canvasEl.style.display='none';
  const lobby=document.getElementById('lobbyScreen');if(lobby)lobby.style.display='';
  const btn=document.getElementById('cancelLobby');if(btn){btn.textContent='LOBİDEN AYRIL';btn.style.display='none';}
  roomId='';
  setStatus('HARİTA SEÇİMİ');
}
async function toggleFullscreen(){const target=document.querySelector('.game-stage-v30')||document.documentElement;try{if(!document.fullscreenElement){if(target.requestFullscreen)await target.requestFullscreen();else if(target.webkitRequestFullscreen)target.webkitRequestFullscreen();}else{if(document.exitFullscreen)await document.exitFullscreen();}}catch(e){addMsg('Tam ekran açılamadı • tarayıcı izin vermedi.')}}
document.getElementById('fullscreenBtn')?.addEventListener('click',toggleFullscreen);
document.getElementById('lobbyInviteCode')?.addEventListener('input',()=>{if((document.getElementById('lobbyInviteCode')?.value||'').trim())selectedOpponentMode='real';document.querySelectorAll('#opponentSelector [data-opponent]').forEach(x=>x.classList.toggle('is-selected',x.dataset.opponent==='real'))});
document.getElementById('lobbyInviteJoin')?.addEventListener('click',joinLobbyByCode);document.getElementById('lobbyInviteCode')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();joinLobbyByCode();}});document.getElementById('lobbyInviteCopy')?.addEventListener('click',copyLobbyCode);document.getElementById('lobbyInviteDisplayCopy')?.addEventListener('click',copyLobbyCode);document.getElementById('scoreboardClose')?.addEventListener('click',()=>{scoreboardOpen=false;renderScoreboard();});

function setupMobileControls(){const box=document.getElementById('mobileControls');if(!box)return;const bind=(id,key)=>{const b=document.getElementById(id);if(!b)return;const on=e=>{e.preventDefault();audioInit();keys[key]=true};const off=e=>{e.preventDefault();keys[key]=false};b.addEventListener('pointerdown',on);b.addEventListener('pointerup',off);b.addEventListener('pointercancel',off);b.addEventListener('pointerleave',off);};bind('mcLeft','left');bind('mcRight','right');bind('mcJump','up');bind('mcShoot','attack');}

document.addEventListener('fullscreenchange',()=>{const b=document.getElementById('fullscreenBtn');if(b)b.innerHTML=document.fullscreenElement?'⛶ <span>TAM EKRANDAN ÇIK</span>':'⛶ <span>TAM EKRAN</span>';document.body.classList.toggle('sa-fullscreen',!!document.fullscreenElement);});
window.addEventListener('beforeunload',()=>{if(remoteReady&&roomId&&navigator.sendBeacon){navigator.sendBeacon(API+'?action=web_mac_bitir',new Blob([JSON.stringify({oda:roomId})],{type:'application/json'}))}});
setupMobileControls();addMsg('Stick Arena v'+VERSION+' • '+(GAME_MODE==='clan'?'10v10 Klan Savaşı':'5v5 Normal Maç'));renderChat([]);
boot();
})();
