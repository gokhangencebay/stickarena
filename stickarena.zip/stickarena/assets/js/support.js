(() => {
  'use strict';
  const API = 'api.php';
  const TOKEN_KEY = 'stickarena_token';
  let activeTicket = null;
  let refreshTimer = null;

  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const token = () => { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (_) { return ''; } };
  const api = async (action, body = {}) => {
    try {
      const t = token();
      const r = await fetch(`${API}?action=${encodeURIComponent(action)}`, {
        method: 'POST', cache: 'no-store', headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${t}`,
          'X-Access-Token': `Bearer ${t}`
        }, body: JSON.stringify(body)
      });
      return await r.json();
    } catch (e) { return {ok:false, mesaj:e.message || 'Bağlantı kurulamadı.'}; }
  };
  const statusLabel = {acik:'Açık', beklemede:'Yanıt bekliyor', cozuldu:'Çözüldü'};
  const priorityLabel = {dusuk:'Düşük', normal:'Normal', yuksek:'Yüksek', acil:'Acil'};

  function openSupport() {
    const m = $('saSupportModal');
    if (!m) return;
    if (!token()) {
      const guest = $('saSupportGuest');
      if (guest) guest.hidden = false;
      const panel = $('saSupportApp');
      if (panel) panel.hidden = true;
    } else {
      const guest = $('saSupportGuest');
      if (guest) guest.hidden = true;
      const panel = $('saSupportApp');
      if (panel) panel.hidden = false;
      loadTickets();
    }
    m.classList.add('is-open'); document.body.classList.add('sa-modal-open'); clearInterval(refreshTimer); refreshTimer=setInterval(()=>{if(token()&&m.classList.contains('is-open'))loadTickets();},5000);
  }
  function closeSupport() { const m=$('saSupportModal'); if(m)m.classList.remove('is-open'); document.body.classList.remove('sa-modal-open'); activeTicket=null; clearInterval(refreshTimer); }

  function renderTickets(list) {
    const el = $('saSupportTickets'); if (!el) return;
    if (!list?.length) { el.innerHTML = '<div class="sa-support-empty"><b>Henüz destek talebiniz yok.</b><span>Karşılaştığınız sorunu ayrıntılı yazın; yönetim ekibi buradan yanıtlayacak.</span></div>'; return; }
    el.innerHTML = list.map(t => `
      <button class="sa-support-ticket ${Number(t.id)===Number(activeTicket)?'is-active':''}" data-ticket="${Number(t.id)}">
        <span class="sa-support-ticket-top"><b>#${Number(t.id)} · ${esc(t.konu)}</b><em class="status-${esc(t.durum)}">${esc(statusLabel[t.durum]||t.durum)}</em></span>
        <small>${esc(t.kategori)} · ${esc(priorityLabel[t.oncelik]||t.oncelik)} · ${esc(t.son_mesaj_tarihi||t.guncellenme||'')}</small>
        <span>${esc(t.son_mesaj||'Yeni destek talebi')}</span>${Number(t.okunmamis)>0?`<i class="sa-support-unread">${Number(t.okunmamis)}</i>`:''}
      </button>`).join('');
    el.querySelectorAll('[data-ticket]').forEach(b => b.addEventListener('click', () => openTicket(Number(b.dataset.ticket))));
  }

  async function loadTickets() {
    const r = await api('destek_ozet'); if (!r.ok) return setMessage(r.mesaj || 'Talepler yüklenemedi.');
    renderTickets(r.talepler || r.liste || []);
    if (activeTicket) await openTicket(activeTicket, false);
  }
  async function openTicket(id, scroll=true) {
    const r = await api('destek_talep_detay', {talep_id:id});
    if (!r.ok) return setMessage(r.mesaj || 'Talep açılamadı.');
    activeTicket = id;
    const info=$('saSupportTicketInfo'), thread=$('saSupportThread'), reply=$('saSupportReply');
    if(info) info.innerHTML=`<span class="sa-support-kicker">TALEP #${Number(r.talep.id)}</span><h3>${esc(r.talep.konu)}</h3><p>${esc(r.talep.kategori)} · ${esc(priorityLabel[r.talep.oncelik]||r.talep.oncelik)} · <b>${esc(statusLabel[r.talep.durum]||r.talep.durum)}</b></p>`;
    if(thread) thread.innerHTML=(r.mesajlar||[]).map(m=>`<article class="sa-support-msg ${m.gonderen_tipi==='admin'?'is-admin':'is-player'}"><header><b>${esc(m.gonderen_adi|| (m.gonderen_tipi==='admin'?'Yönetim':'Siz'))}</b><time>${esc(m.tarih)}</time></header><p>${esc(m.mesaj)}</p></article>`).join('');
    if(reply){reply.disabled=false; reply.placeholder=r.talep.durum==='cozuldu'?'Talep çözüldü. Yeni yanıtınızla otomatik yeniden açılır.':'Yanıtınızı yazın…';}
    const detail=$('saSupportDetail'); if(detail) detail.hidden=false;
    const latest=await api('destek_ozet'); renderTickets(latest.talepler || latest.liste || []);
    if(scroll && thread) thread.scrollTop=thread.scrollHeight;
  }
  function setMessage(msg) { const e=$('saSupportNotice'); if(e){e.textContent=msg;e.hidden=!msg;setTimeout(()=>{e.hidden=true},4000);} }

  async function createTicket(ev) {
    ev.preventDefault(); const form=ev.currentTarget; const data=Object.fromEntries(new FormData(form).entries());
    const btn=form.querySelector('button[type=submit]'); if(btn)btn.disabled=true;
    const r=await api('destek_talep_olustur',data);
    if(btn)btn.disabled=false;
    if(!r.ok)return setMessage(r.mesaj||'Talep oluşturulamadı.');
    form.reset(); setMessage('Destek talebiniz oluşturuldu.'); await loadTickets(); await openTicket(Number(r.talep_id));
  }
  async function sendReply() {
    if(!activeTicket)return; const e=$('saSupportReply'), msg=e?.value.trim(); if(!msg)return;
    e.disabled=true; const r=await api('destek_mesaj_gonder',{talep_id:activeTicket,mesaj:msg}); e.disabled=false;
    if(!r.ok)return setMessage(r.mesaj||'Yanıt gönderilemedi.'); e.value=''; await openTicket(activeTicket);
  }
  function bind() {
    document.querySelectorAll('[data-support-open]').forEach(x=>x.addEventListener('click',e=>{e.preventDefault();openSupport();}));
    $('saSupportClose')?.addEventListener('click',closeSupport);
    $('saSupportModal')?.addEventListener('click',e=>{if(e.target.id==='saSupportModal')closeSupport();});
    $('saSupportNewTicket')?.addEventListener('submit',createTicket);
    $('saSupportSend')?.addEventListener('click',sendReply);
    $('saSupportReply')?.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter')sendReply();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeSupport();});
    $('saSupportApp')?.addEventListener('click',e=>e.stopPropagation());
  }
  bind();
})();
