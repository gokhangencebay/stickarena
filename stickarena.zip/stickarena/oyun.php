<?php
require __DIR__.'/config.php';
?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
<meta name="theme-color" content="#02070b">
<meta name="description" content="Stick Arena — silah odaklı gerçek zamanlı tarayıcı arena oyunu.">
<meta name="robots" content="index,follow">
<title>Stick Arena — Weapon Arena 5.13.1</title>
<link rel="stylesheet" href="assets/css/app.css?v=5.13.0">
<link rel="stylesheet" href="assets/css/game-premium.css?v=5.13.1">
<script type="application/ld+json">{"@context":"https://schema.org","@type":"VideoGame","name":"Stick Arena","applicationCategory":"Game","genre":["Action","Shooter","Multiplayer"],"operatingSystem":"Web Browser","inLanguage":"tr-TR","description":"Tarayıcı üzerinden oynanan gerçek zamanlı silah odaklı arena oyunu."}</script>
</head>
<body class="gamebody">
<header class="gamebar">
  <a href="index.php" class="gamebrand" aria-label="Stick Arena"><span class="sa-neon-logo" data-text="STICK ARENA">STICK <i>ARENA</i></span></a>
  <span id="durum">HARİTA SEÇİMİ</span>
  <span id="mod"><?php echo (isset($_GET['mod'])&&$_GET['mod']==='klan')?'10v10 KLAN':'5v5 NORMAL'; ?></span>
  <span id="sure">15:00</span><span id="skor">0 — 0</span>
  <a href="index.php">ANASAYFA </a><a href="izle.php">CANLI MAÇ İZLE</a><a href="cikis.php" class="game-logout">ÇIKIŞ</a>
</header>

<main class="gamewrap game-v30-wrap">
<section class="game-stage game-stage-v30">
  <div id="lobbyScreen" class="sa-lobby-screen">
    <div class="sa-lobby-head">
      <div>
        <span class="sa-eyebrow">STICK ARENA / WEAPON OPERATIONS</span>
        <h1>ARENA'YI SEÇ.<br>CEPHANELİĞİ KUŞAN.</h1>
        <p>Haritanı seç, takımını belirle ve savaşa gir.  Hasar yalnızca ateşli/sci-fi silahlarla verilir.</p>
      </div>
      <div class="sa-mode-chip" id="lobbyMode">5v5 NORMAL</div>
    </div>
    <div id="mapCards" class="sa-map-cards"></div>
    <div class="sa-opponent-selector" id="opponentSelector"><div><span class="sa-eyebrow">EŞLEŞME TÜRÜ</span><strong>Rakibini seç</strong><small>Arkadaşlarınla gerçek oyuncu veya tek başına bot operasyonu.</small></div><button type="button" data-opponent="real" class="is-selected"><b>GERÇEK OYUNCU</b><small>Ortak lobi / arkadaşla oynama</small></button><button type="button" data-opponent="bot"><b>BOTLARA KARŞI</b><small>Tek kişilik yapay zekâ operasyonu</small></button></div>
    <div id="lobbyStatus" class="sa-lobby-status">Bir operasyon haritası seç.</div>
    <div class="sa-lobby-invite"><div><span class="sa-eyebrow">ARKADAŞ DAVETİ</span><strong>Gerçek oyuncu lobisine kod ile katıl</strong><small>Arkadaşın bu kodu kendi oyun ekranındaki alana girerek aynı odaya alınır.</small></div><div class="sa-lobby-invite-actions"><input id="lobbyInviteCode" maxlength="8" inputmode="text" autocomplete="off" placeholder="8 HANELİ KOD"><button type="button" id="lobbyInviteJoin">KODLA KATIL</button><button type="button" id="lobbyInviteCopy" hidden>KODU KOPYALA</button></div></div>
    <div id="lobbyInviteDisplay" class="sa-lobby-invite-display" hidden><span>LOBİ KODUN</span><strong id="lobbyInviteValue">--------</strong><button type="button" id="lobbyInviteDisplayCopy">KOPYALA</button></div>
    <div id="lobbyPlayers" class="sa-lobby-players"></div>
    <button id="cancelLobby" class="sa-lobby-cancel" style="display:none">LOBİDEN ÇIK</button>
  </div>

  <canvas id="oyun" width="1280" height="720" tabindex="0" style="display:none"></canvas>

  <div class="sa-game-controls">
    <button type="button" id="fullscreenBtn" class="sa-game-control" title="Tam ekran">⛶ <span>TAM EKRAN</span></button>
  </div>

  <div id="mapRotationHud" class="sa-game-map-rotation sa-scoreboard-v51" style="display:none"><span>LIVE SCOREBOARD</span><b id="mapRotationName">—</b><div class="sa-score-pair"><strong><i></i><em id="scoreTeamA">0</em></strong><small>—</small><strong><i></i><em id="scoreTeamB">0</em></strong></div></div>

  <div id="playerHud" class="sa-player-hud" aria-live="polite">
    <div class="sa-player-avatar">◎</div>
    <div class="sa-player-info">
      <strong id="playerHudName">Oyuncu</strong>
      <span id="playerHpText">HP: 100</span>
      <span id="playerHudTeam">KIRMIZI TAKIM</span>
      <div class="sa-hp-track"><i id="playerHpFill"></i></div>
      <small id="playerLoadout"><span class="sa-ammo-label">AMMO</span> <b id="playerWeaponName">9MM TABANCA</b> · <strong id="playerAmmoCount">15/15</strong></small>
    </div>
  </div>

  <div id="killFeed" class="sa-kill-feed" aria-live="polite" aria-label="Son öldürmeler"></div>
<div id="scoreboardPanel" class="sa-scoreboard-panel" hidden aria-live="polite">
  <div class="sa-scoreboard-head"><div><span class="sa-eyebrow">TAB · MATCH BOARD</span><strong>MAÇ SKOR TABLOSU</strong><small id="scoreboardMode">GERÇEK OYUNCU</small></div><button type="button" id="scoreboardClose">KAPAT</button></div>
  <div class="sa-scoreboard-totals"><div class="team-card team-a"><span>KIRMIZI</span><b id="scoreboardScoreA">0</b></div><div class="scoreboard-vs">VS</div><div class="team-card team-b"><span>MAVİ</span><b id="scoreboardScoreB">0</b></div></div>
  <div class="sa-scoreboard-labels"><span>TAKIM / OYUNCU</span><em>K</em><em>Ö</em></div>
  <div id="scoreboardRows" class="sa-scoreboard-rows"></div>
</div>


  <div id="gameChat" class="sa-game-chat" style="display:none">
    <div class="sa-game-chat-head"><strong>MAÇ SOHBETİ</strong><span id="chatOnline"></span></div>
    <div id="chatMessages" class="sa-chat-messages"></div>
    <div id="emojiPicker" class="sa-emoji-picker" hidden></div>
    <div class="sa-chat-tools">
      <button type="button" id="emojiBtn" title="Emoji">😊</button>
      <button type="button" id="clearChatBtn" title="Sohbeti temizle">⌫</button>
      <button type="button" id="chatToggleBtn" title="Sohbeti gizle">—</button>
      <span id="chatToolInfo">Oyuncuya tıklayarak moderasyon seçeneklerini aç.</span>
    </div>
    <form id="chatForm" autocomplete="off"><input id="chatInput" maxlength="180" autocomplete="off" placeholder="Mesaj yaz…"><button type="submit">GÖNDER</button></form>
  </div>

  <div id="pauseOverlay" class="sa-pause-overlay" style="display:none">
    <div><strong>MAÇ DURAKLATILDI</strong><span>Yönetici savaşı yeniden başlatana kadar hareket ve süre bekletildi.</span></div>
  </div>

  <div class="game-hint" id="gameHint" style="display:none">WASD / OKLAR: HAREKET · SPACE / SOL TIK: ATEŞ · F: SİLAH BIRAK · TAB: SKOR · V: BAS-KONUŞ · R: YENİDEN BAŞLAT</div>

  <div id="mobileControls" class="sa-mobile-controls" aria-label="Mobil oyun kontrolleri">
    <div class="mc-move"><button id="mcLeft">◀</button><button id="mcRight">▶</button></div>
    <div class="mc-actions"><button id="mcJump">⬆</button><button id="mcShoot">●</button></div>
  </div>

  <div id="mesajlar" style="display:none"></div>
</section>

<aside class="game-side game-side-v30">
  <h3>OTURUM</h3><div id="oda">LOBİ BEKLENİYOR</div>
  <h3>OYUNCU SAYISI</h3><div id="oyuncular">0/10</div>
  <h3>OPERASYON HARİTASI</h3><div id="aktifHarita">Seçilmedi</div>
  <h3>SAVAŞ KURALI</h3><div>SADECE SİLAH<br><small style="color:#587785">Yakın dövüş kapalı</small></div><h3>SES KANALI</h3><div class="voice-mini"><span id="voiceStatus">Mikrofon kapalı</span><button id="voiceEnable">MİKROFONU AÇ</button><button id="voiceKeyBtn">TUŞ: <b id="voicePttKey">V</b></button><i id="voicePttIndicator" class="voice-ptt-indicator" aria-label="Bas-konuş durumu"></i><span>Takım: <b id="voicePeerCount">0</b> kişi</span></div>
  <div class="game-side-actions">
    <button class="btn" onclick="location.href='depo.php'">DEPO &amp; DONANIM</button>
    <button class="btn" onclick="location.href='index.php'">CANLI MERKEZ</button>
  </div>
</aside>
</main>

<footer class="sa-game-footer">
  <div class="sa-game-footer-brand"><div class="sa-footer-orb"><span>SA</span></div><div><strong class="sa-neon-logo" data-text="STICK ARENA">STICK <i>ARENA</i></strong><span>WEAPON-ONLY ONLINE ARENA</span></div></div>
  <nav class="sa-game-footer-links" aria-label="Oyun bağlantıları"><a href="index.php">Ana Sayfa</a><a href="liderlik.php">Liderlik</a><a href="klan.php">Klanlar</a><a href="depo.php">Cephanelik</a><a href="magaza.php">Mağaza</a><a href="kurallar.php">Kurallar</a><a href="izle.php">Canlı Maçlar</a></nav>
  <div class="sa-game-footer-social" aria-label="Sosyal medya">
    <a href="https://discord.com/" target="_blank" rel="noopener noreferrer" aria-label="Discord"><span class="sa-social-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M19.5 5.1A16.1 16.1 0 0 0 15.7 4l-.5 1a13.9 13.9 0 0 0-6.2 0l-.5-1a16.2 16.2 0 0 0-3.9 1.1C2 8.9 1.3 12.7 1.6 16.5c1.6 1.2 3.2 2.1 4.8 2.7l1.2-1.6c-.7-.2-1.3-.5-1.9-.9l.5-.4c3.7 1.7 7.8 1.7 11.4 0l.5.4c-.6.4-1.2.7-1.9.9l1.2 1.6c1.6-.6 3.2-1.5 4.8-2.7.4-4.4-.7-8.1-2.7-11.4ZM8.9 14.6c-1.1 0-1.9-1-1.9-2.2s.9-2.2 1.9-2.2c1.1 0 1.9 1 1.9 2.2s-.8 2.2-1.9 2.2Zm6.2 0c-1.1 0-1.9-1-1.9-2.2s.9-2.2 1.9-2.2c1.1 0 1.9 1-1.9 1.9-1.9 0-1.9.9-1.9 2.2s.8 2.2 1.9 2.2Zm0 0Z"/></svg></span><span class="sa-social-name">Discord</span></a>
    <a href="https://x.com/" target="_blank" rel="noopener noreferrer" aria-label="X"><span class="sa-social-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M4 3h4.7l3.8 5.2L17.1 3H20l-6.2 7.1L20.5 21h-4.7l-4.3-5.9L6.1 21H3.3l6.5-7.5L4 3Z"/></svg></span><span class="sa-social-name">X</span></a>
    <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><span class="sa-social-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="17" height="17" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.4" cy="6.8" r="1.2" fill="currentColor"/></svg></span><span class="sa-social-name">Instagram</span></a>
  </div>
  <div class="sa-game-footer-meta"><span>Server Sürümü: v5 BETA</span><span>© 2026 Stick Arena • Online Game Community All right reserved.</span></div>
</footer>

<script>
window.STICKARENA_GAME_MODE=<?php echo json_encode(SA_GAME_MODE); ?>;
window.STICKARENA_GAME_SERVER=<?php echo json_encode(SA_GAME_SERVER); ?>;
window.STICKARENA_GAME_V30=true;
window.STICKARENA_WEAPON_ONLY=true;
window.addEventListener('error',function(e){
  if(window.__SA_GAME_BOOTED)return;
  var d=document.getElementById('durum');if(d)d.textContent='OYUN MOTORU HATASI';
  var m=document.getElementById('mesajlar');if(m)m.textContent='JavaScript hatası: '+String(e.message||'Bilinmeyen hata');
});
window.addEventListener('unhandledrejection',function(e){
  fetch('api.php?action=client_log',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({olay:'JS_PROMISE_HATASI',detay:String(e.reason||'Bilinmeyen promise hatası')})}).catch(function(){});
});
</script>
<script>window.SA_ME_ID=0;</script><script src="assets/js/voice-chat.js?v=5.13.1" defer></script><script src="assets/js/game-web.js?v=5.13.1" defer></script>
<noscript>Stick Arena için JavaScript etkin olmalıdır.</noscript>
</body>
</html>