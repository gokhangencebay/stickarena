<?php
declare(strict_types=1);
require __DIR__.'/config.php';require __DIR__.'/iyzico.php';
$token=trim($_POST['token']??$_GET['token']??'');
if($token===''){http_response_code(400);exit('Token bulunamadı.');}
$st=sa_db()->prepare("SELECT * FROM iyzico_siparisler WHERE token=? LIMIT 1");$st->execute([$token]);$order=$st->fetch();
if(!$order){http_response_code(404);exit('Sipariş bulunamadı.');}
try{$r=sa_iyzi_retrieve($token,$order['conversation_id']);$success=(($r['status']??'')==='success' && ($r['paymentStatus']??'')==='SUCCESS');
 $pdo=sa_db();$pdo->beginTransaction();
 $pdo->prepare("UPDATE iyzico_siparisler SET durum=?,yanit=?,guncellenme=NOW() WHERE id=?")->execute([$success?'basarili':'basarisiz',json_encode($r,JSON_UNESCAPED_UNICODE),$order['id']]);
 if($success){$q=$pdo->prepare("SELECT coin,elmas FROM sanal_urunler WHERE id=? AND aktif=1 LIMIT 1");$q->execute([$order['urun_id']]);$prod=$q->fetch();if($prod){$pdo->prepare("UPDATE kullanicilar SET coin=coin+?,elmas=elmas+? WHERE id=?")->execute([(int)$prod['coin'],(int)$prod['elmas'],$order['kullanici_id']]);}}
 $pdo->commit();
 header('Location: magaza.php?odeme='.($success?'basarili':'basarisiz'));exit;
}catch(Throwable $e){http_response_code(500);exit('Ödeme sonucu doğrulanamadı.');}
