<?php
declare(strict_types=1);
const SA_DB_HOST = 'titan.mbwsrv.com';
const SA_DB_NAME = 'markaxne_sticky';
const SA_DB_USER = 'markaxne_sticky';
const SA_DB_PASS = '+d!GN8%!2r^R';
const SA_JWT_SECRET = 'WEB_HOSTING_ILE_VPS_DE_AYNI_COK_UZUN_GIZLI_ANAHTAR';
const SA_GAME_MODE = 'web'; // web = VPS olmadan tarayıcıda geliştirme modu, vps = gerçek WebSocket sunucusu
const SA_GAME_SERVER = 'wss://gncby.com.tr';
const SA_GAME_HTTP_SERVER = 'https://gncby.com.tr';

function sa_db(): PDO {
    static $pdo=null;
    if($pdo===null){
        $pdo=new PDO(
            'mysql:host='.SA_DB_HOST.';dbname='.SA_DB_NAME.';charset=utf8mb4',
            SA_DB_USER,SA_DB_PASS,
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
        );
    }
    return $pdo;
}
function sa_crypt(string $plain): string { $key=hash('sha256',SA_JWT_SECRET,true); $iv=random_bytes(12); $tag=''; $cipher=openssl_encrypt($plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag); return 'enc:'.base64_encode($iv.$tag.$cipher); }
function sa_decrypt(string $value): string { if(strpos($value,'enc:')!==0)return $value; $raw=base64_decode(substr($value,4),true); if($raw===false||strlen($raw)<29)return ''; $key=hash('sha256',SA_JWT_SECRET,true); $iv=substr($raw,0,12);$tag=substr($raw,12,16);$cipher=substr($raw,28); $out=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag); return $out===false?'':$out; }
function sa_token(int $id,string $username): string {
    $header=rtrim(strtr(base64_encode(json_encode(['alg'=>'HS256','typ'=>'JWT'])), '+/','-_'),'=');
    $payload=rtrim(strtr(base64_encode(json_encode(['sub'=>$id,'username'=>$username,'iat'=>time(),'exp'=>time()+86400])), '+/','-_'),'=');
    $sig=rtrim(strtr(base64_encode(hash_hmac('sha256',$header.'.'.$payload,SA_JWT_SECRET,true)), '+/','-_'),'=');
    return $header.'.'.$payload.'.'.$sig;
}
function sa_auth(): ?array {
    $h=$_SERVER['HTTP_AUTHORIZATION']??($_SERVER['HTTP_X_ACCESS_TOKEN']??'');
    if($h!=='' && stripos($h,'Bearer ')!==0) $h='Bearer '.$h;
    if(!preg_match('/Bearer\s+(.+)/i',$h,$m)) return null;
    $p=explode('.',$m[1]); if(count($p)!==3)return null;
    [$head,$body,$sig]=$p;
    $check=rtrim(strtr(base64_encode(hash_hmac('sha256',$head.'.'.$body,SA_JWT_SECRET,true)), '+/','-_'),'=');
    if(!hash_equals($check,$sig))return null;
    $data=json_decode(base64_decode(strtr($body,'-_','+/')),true);
    if(!$data || ($data['exp']??0)<time())return null;
    return $data;
}
function sa_json($data,int $code=200):never {
    http_response_code($code); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data,JSON_UNESCAPED_UNICODE); exit;
}
