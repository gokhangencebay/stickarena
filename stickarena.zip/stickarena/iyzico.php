<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';

function sa_iyzi_settings(): array {
    $row = sa_db()->query("SELECT * FROM ayarlar_iyzico WHERE id=1 LIMIT 1")->fetch();
    if(!$row) return ['api_key'=>'','secret_key'=>'','base_url'=>'https://sandbox-api.iyzipay.com','aktif'=>0]; $row['secret_key']=sa_decrypt($row['secret_key']); return $row;
}
function sa_iyzi_auth(string $uri, string $apiKey, string $secretKey, string $body): string {
    $rnd = bin2hex(random_bytes(16));
    $payload = $uri.$body;
    $signature = hash_hmac('sha256', $rnd.$payload, $secretKey);
    $content = 'apiKey:'.$apiKey.'&randomKey:'.$rnd.'&signature:'.$signature;
    return 'IYZWSv2 '.base64_encode($content);
}
function sa_iyzi_request(string $path, array $data): array {
    $s=sa_iyzi_settings();
    if(empty($s['api_key']) || empty($s['secret_key']) || !$s['aktif']) throw new RuntimeException('iyzico ödeme sistemi aktif değil veya anahtarlar girilmemiş.');
    $body=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $url=rtrim($s['base_url'],'/').$path;
    $auth=sa_iyzi_auth($url,$s['api_key'],$s['secret_key'],$body);
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_HTTPHEADER=>['Authorization: '.$auth,'Content-Type: application/json','Accept: application/json']]);
    $raw=curl_exec($ch);$err=curl_error($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if($raw===false) throw new RuntimeException('iyzico bağlantı hatası: '.$err);
    $json=json_decode($raw,true);
    if(!is_array($json)) throw new RuntimeException('iyzico geçersiz yanıt verdi. HTTP '.$code);
    $json['_http_code']=$code;return $json;
}
function sa_iyzi_initialize(array $user,array $product,float $price,string $callback): array {
    $conversation='SA'.date('YmdHis').bin2hex(random_bytes(4));
    $firstName=trim((string)($user['ad']??''));
    $lastName=trim((string)($user['soyad']??''));
    $username=(string)($user['kullanici_adi']??'Oyuncu');
    $email=(string)($user['email']??'');
    $gsm=(string)($user['gsm']??$user['telefon']??'+905000000000');
    $tc=(string)($user['tc']??'11111111111');
    $adres=(string)($user['adres']??'Türkiye');
    $request=[
      'locale'=>'tr','conversationId'=>$conversation,'price'=>number_format($price,2,'.',''),'paidPrice'=>number_format($price,2,'.',''),
      'currency'=>'TRY','basketId'=>$conversation,'paymentGroup'=>'PRODUCT','callbackUrl'=>$callback,
      'enabledInstallments'=>[1,2,3,6,9],
      'buyer'=>['id'=>(string)($user['id']??0),'name'=>$firstName!==''?$firstName:$username,'surname'=>$lastName!==''?$lastName:'Oyuncu','gsmNumber'=>$gsm,'email'=>$email,'identityNumber'=>$tc,'registrationAddress'=>$adres,'city'=>'İstanbul','country'=>'Turkey','ip'=>$_SERVER['REMOTE_ADDR']??'127.0.0.1'],
      'billingAddress'=>['contactName'=>($firstName!==''?$firstName:$username).' '.($lastName!==''?$lastName:'Oyuncu'),'city'=>'İstanbul','country'=>'Turkey','address'=>$adres,'zipCode'=>'34000'],
      'shippingAddress'=>['contactName'=>($firstName!==''?$firstName:$username).' '.($lastName!==''?$lastName:'Oyuncu'),'city'=>'İstanbul','country'=>'Turkey','address'=>$adres,'zipCode'=>'34000'],
      'basketItems'=>[['id'=>(string)($product['id']??'urun'),'name'=>(string)($product['ad']??'Dijital ürün'),'category1'=>'Oyun','category2'=>$product['kategori']??'Dijital','itemType'=>'VIRTUAL','price'=>number_format($price,2,'.','')]]
    ];
    $result=sa_iyzi_request('/payment/iyzipos/checkoutform/initialize/auth/ecom',$request);
    if(($result['status']??'failure')!=='success') throw new RuntimeException(($result['errorMessage']??'iyzico ödeme başlatılamadı.'));
    return $result+['_conversation'=>$conversation];
}
function sa_iyzi_retrieve(string $token,string $conversation=''): array {
    return sa_iyzi_request('/payment/iyzipos/checkoutform/auth/ecom/detail',['locale'=>'tr','conversationId'=>$conversation,'token'=>$token]);
}
