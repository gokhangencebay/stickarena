<?php require __DIR__.'/config.php'; ?>
<!doctype html>
<html lang="tr">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Depo & Donanım — Stick Arena</title><link rel="stylesheet" href="assets/css/app.css?v=2.9"><link rel="stylesheet" href="assets/css/depo-2.9.css?v=2.9"><link rel="stylesheet" href="assets/css/premium-redesign.css?v=5.1"></head>
<body>
<nav class="sa-nav"><a class="brand-logo" href="index.php"><img src="assets/logo.png" alt="Stick Arena"></a><div><a href="index.php">ANA SAYFA</a><a href="oyun.php">OYNA</a><a href="magaza.php">MAĞAZA</a><a class="active" href="depo.php">DEPO</a><a href="liderlik.php">LİDERLİK</a></div></nav>
<main class="depo-wrap">
 <section class="depo-head"><div><span class="eyebrow">OYUNCU MERKEZİ</span><h1>DEPO & DONANIM</h1><p>Satın aldığın silahları, karakterleri ve saldırı efektlerini buradan kuşanabilir veya çıkarabilirsin.</p></div><a class="sa-btn ghost" href="magaza.php">MAĞAZAYA GİT</a></section>
 <div id="depoMsg" class="depo-msg"></div>
 <section class="loadout-grid">
  <article class="loadout-card"><span>KARAKTER</span><strong id="eqChar">Standart</strong><div class="preview"><img id="charPreview" src="assets/sprites/characters/v513/standart.png?v=5.13.0.0" alt="Karakter"></div><button class="sa-btn ghost" id="removeChar">STANDART KARAKTERE DÖN</button></article>
  <article class="loadout-card"><span>SİLAH</span><strong id="eqWeapon">Standart Tabanca</strong><div class="preview weapon-preview"><img id="weaponPreview" src="assets/sprites/items/v513/tabanca.png?v=5.13.0.0" alt="Silah"></div><button class="sa-btn ghost" id="removeWeapon">SİLAHI ÇIKAR</button></article>
  <article class="loadout-card"><span>SALDIRI EFEKTİ</span><strong id="eqEffect">Yok</strong><div class="effect-preview" id="effectPreview">✦</div><button class="sa-btn ghost" id="removeEffect">EFEKTİ ÇIKAR</button></article>
 </section>
 <section class="inventory-section"><div class="section-title"><div><span class="eyebrow">ENVANTER</span><h2>SAHİP OLDUKLARIN</h2></div><div class="tabs"><button class="tab active" data-filter="all">TÜMÜ</button><button class="tab" data-filter="silah">SİLAHLAR</button><button class="tab" data-filter="karakter">KARAKTERLER</button><button class="tab" data-filter="efekt">EFEKTLER</button></div></div><div id="inventory" class="inventory-grid"><div class="loading">Depo yükleniyor...</div></div></section>
</main>
<script src="assets/js/depo-2.9.js?v=2.9"></script>
</body></html>
