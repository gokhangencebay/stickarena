<?php require __DIR__.'/../config.php'; ?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Stick Arena 5.8 — Command Center</title>
<link rel="stylesheet" href="../assets/css/app.css?v=5.9">
<link rel="stylesheet" href="../assets/css/admin-5.4.css?v=5.9">
</head>
<body class="sa-admin-body">
<div class="sa-admin-app">
  <aside class="sa-admin-sidebar" id="saSidebar">
    <div class="sa-admin-brand">
      <a href="../index.php" aria-label="Stick Arena ana sayfa"><span class="sa-admin-logo">STICK <i>ARENA</i></span></a>
      <small>COMMAND CENTER · 5.7</small>
    </div>
    <div class="sa-system-card"><span><i class="status-dot"></i> OYUN AĞI</span><b id="sideServer">KONTROL</b><small>WebSocket/API · 60 FPS istemci</small></div>
    <nav class="sa-admin-nav">
      <a class="active" href="#dashboard"><span>01</span> Genel Bakış</a>
      <a href="#destek"><span>02</span> Destek Merkezi <em id="supportBadge">0</em></a>
      <a href="#oyuncular"><span>03</span> Oyuncular</a>
      <a href="#canli"><span>04</span> Canlı Operasyon</a>
      <a href="#telemetri"><span>05</span> Telemetri & Hatalar <em id="errorBadge">0</em></a>
      <a href="#guvenlik"><span>06</span> Güvenlik</a>
      <a href="#ekonomi"><span>07</span> Ekonomi</a>
      <a href="#icerik"><span>08</span> İçerik & Duyurular</a>
      <a href="#kurallar"><span>09</span> Kurallar</a>
      <a href="#ayarlar"><span>10</span> Sistem Ayarları</a>
    </nav>
    <div class="sa-admin-side-links"><a href="../index.php">↗ Siteye Dön</a><a href="../oyun.php">◉ Oyunu Aç</a><a href="../cikis.php" class="logout">Çıkış</a></div>
  </aside>

  <main class="sa-admin-main">
    <header class="sa-admin-topbar">
      <div class="sa-mobile-head"><button id="mobileToggle" class="icon-btn">☰</button><span class="sa-admin-logo">STICK <i>ARENA</i></span></div>
      <div><span class="eyebrow">LIVE CONTROL PLANE</span><h1>Operasyon Merkezi</h1><p>Oyuncu hizmetleri, maç ağı, destek, ekonomi ve güvenlik tek konsolda.</p></div>
      <div class="sa-top-actions"><span id="lastUpdate">—</span><button id="refreshAll" class="ghost-btn">↻ Yenile</button><a href="../index.php" class="primary-btn">Siteyi Gör</a></div>
    </header>

    <div class="sa-admin-content">
      <section id="dashboard" class="sa-section sa-hero-grid">
        <article class="sa-command-hero"><span class="eyebrow">SYSTEM STATUS</span><h2>STICK ARENA ağı hazır.</h2><p>Gerçek zamanlı maçlar, destek kuyrukları ve oyuncu yönetimi burada izlenir. Kritik işlemler kayıt altına alınır.</p><div class="hero-status"><div id="serverPill" class="server-pill"><i></i><b>Kontrol ediliyor</b></div><span id="errorSummary">—</span></div></article>
        <article class="sa-live-clock"><span>SERVER CLOCK</span><strong id="serverClock">--:--:--</strong><small>Europe / Istanbul</small></article>
      </section>

      <section class="metric-grid">
        <article class="metric-card"><span>TOPLAM OYUNCU</span><strong id="totalPlayers">—</strong><small>Kayıtlı hesap</small></article>
        <article class="metric-card cyan"><span>CANLI OYUNCU</span><strong id="activePlayers">—</strong><small>Heartbeat</small></article>
        <article class="metric-card blue"><span>AKTİF MAÇ</span><strong id="activeMatches">—</strong><small>5v5 / 10v10</small></article>
        <article class="metric-card amber"><span>BEKLEYEN DESTEK</span><strong id="openTickets">—</strong><small id="unreadTickets">— okunmamış</small></article>
        <article class="metric-card red"><span>TEKNİK OLAY</span><strong id="errorCount">—</strong><small>Son kayıtlar</small></article>
      </section>

      <section id="destek" class="sa-section sa-support-admin-section">
        <div class="section-head"><div><span class="eyebrow">PLAYER CARE</span><h2>Destek Merkezi <span id="supportHealth" class="support-health">KONTROL</span></h2><p>Oyuncuların ana sayfadan açtığı talepleri konuşma görünümünde yönetin.</p></div><div class="filter-pills"><button data-support-filter="">Tümü</button><button data-support-filter="acik">Açık</button><button data-support-filter="beklemede">Yanıt bekleyen</button><button data-support-filter="cozuldu">Çözülen</button></div></div>
        <div class="support-workspace"><div class="support-system-banner"><strong>CANLI DESTEK KUYRUĞU</strong><span>Oyuncu mesajları sunucudan anlık çekilir. Yanıt verdiğinizde talep otomatik olarak oyuncunun paneline düşer.</span></div>
          <div class="support-queue"><div class="queue-toolbar"><input id="supportSearch" placeholder="Talep no, oyuncu, e-posta veya konu…"><button id="supportReload" class="ghost-btn">↻</button></div><div id="supportQueueList" class="support-queue-list"><div class="empty-state">Destek kuyruğu yükleniyor…</div></div></div>
          <div class="support-conversation">
            <div id="supportEmpty" class="support-empty-state"><div class="support-orbit">?</div><h3>Bir destek talebi seçin</h3><p>Sol taraftan bir talep açın. Mesaj geçmişi, oyuncu bilgileri ve durum burada görüntülenir.</p></div>
            <div id="supportConversation" class="support-conversation-inner" hidden>
              <header class="support-conversation-head"><div id="supportTicketInfo"></div><div class="conversation-actions"><select id="supportStatus"><option value="acik">Açık</option><option value="beklemede">Yanıt bekliyor</option><option value="cozuldu">Çözüldü</option></select></div></header>
              <div id="supportThread" class="support-thread"></div>
              <div class="support-reply"><textarea id="supportReply" placeholder="Oyuncuya yanıt yazın… (Ctrl + Enter gönderir)"></textarea><button id="supportSend" class="primary-btn">Yanıtı Gönder</button></div>
            </div>
          </div>
        </div>
      </section>

      <section id="oyuncular" class="sa-section panel-block"><div class="section-head"><div><span class="eyebrow">ACCOUNT OPERATIONS</span><h2>Oyuncu Yönetimi</h2><p>Bakiye, doğrulama ve geçici moderasyon işlemleri.</p></div><div class="inline-filters"><input id="userSearch" placeholder="Kullanıcı adı, e-posta veya ID"><select id="userRoleFilter"><option value="">Tüm roller</option><option value="admin">Admin</option><option value="oyuncu">Oyuncu</option></select></div></div><div class="table-wrap"><table><thead><tr><th>ID</th><th>Oyuncu</th><th>Rol</th><th>Rating</th><th>G / M</th><th>K / Ö</th><th>Coin / Elmas</th><th>Durum</th><th>İşlem</th></tr></thead><tbody id="users"></tbody></table></div></section>

      <section id="canli" class="sa-section panel-block"><div class="section-head"><div><span class="eyebrow">MATCH OPERATIONS</span><h2>Canlı Operasyon</h2><p>Aktif lobiler, maçlar, skorlar ve yönetici kontrolleri.</p></div><span class="live-badge"><i></i> 3 sn otomatik yenileme</span></div><div class="live-overview-grid"><div id="liveSummary" class="live-summary-card">Veri alınıyor…</div><div id="quickMatches" class="quick-match-card">—</div></div><div id="adminMatches" class="match-ops-list"></div></section>

      <section id="telemetri" class="sa-section panel-block"><div class="section-head"><div><span class="eyebrow">OBSERVABILITY</span><h2>Telemetri & Hatalar</h2><p>PHP, API, oyun ve güvenlik loglarını filtreleyin.</p></div><div class="inline-filters"><input id="errorSearch" placeholder="Olay, detay, oyuncu, IP"><select id="errorType"><option value="">Tüm olaylar</option><option value="HATA">HATA</option><option value="API_">API</option><option value="OYUN_">OYUN</option><option value="JS_">JS</option></select><button id="clearErrors" class="danger-btn">Temizle</button></div></div><div id="errorlist" class="error-stream"></div></section>

      <section id="guvenlik" class="sa-section panel-block"><div class="section-head"><div><span class="eyebrow">SECURITY</span><h2>Güvenlik Olayları</h2><p>Şüpheli davranış, moderasyon ve güvenlik skorları.</p></div></div><div id="securitylist"></div></section>

      <section id="ekonomi" class="sa-section"><div class="section-head"><div><span class="eyebrow">ECONOMY CONTROL</span><h2>Ekonomi & Ödeme</h2><p>Maç ödülleri, sanal ürünler ve iyzico ayarları.</p></div></div><div class="dual-panel-grid">
        <article class="panel-block mini-panel"><h3>Maç / Klan Ödülleri</h3><div class="form-grid"><label>Normal süre<input id="normal_sure" type="number"></label><label>1. XP<input id="n1xp" type="number"></label><label>1. Coin<input id="n1coin" type="number"></label><label>Takım XP<input id="ntxp" type="number"></label><label>Takım Coin<input id="ntcoin" type="number"></label><label>Klan kazanan XP<input id="kxp" type="number"></label><label>Klan kazanan Coin<input id="kcoin" type="number"></label><label>Klan kaybeden XP<input id="lkxp" type="number"></label><label>Klan kaybeden Coin<input id="lkcoin" type="number"></label></div><button class="primary-btn" id="saveRewards">Kaydet</button></article>
        <article class="panel-block mini-panel"><h3>iyzico</h3><div class="form-grid"><label>Ortam<select id="iyzi_env"><option value="sandbox">Sandbox</option><option value="live">Live</option></select></label><label>API Key<input id="iyzi_key"></label><label>Secret Key<input id="iyzi_secret" type="password" autocomplete="new-password"></label><label class="check-row"><input id="iyzi_active" type="checkbox"> Ödeme aktif</label></div><span id="iyziStatus" class="status-chip">—</span><button class="primary-btn" id="saveIyzico">Kaydet</button></article>
      </div><article class="panel-block mini-panel"><div class="section-head compact"><h3>Sanal Ürünler</h3></div><div class="form-grid product-editor"><input id="pid" placeholder="Ürün ID"><input id="pad" placeholder="Ürün adı"><input id="pacik" placeholder="Açıklama"><input id="pfiyat" type="number" step="0.01" placeholder="Fiyat TL"><input id="pcoin" type="number" placeholder="Coin"><input id="pelmas" type="number" placeholder="Elmas"><label class="check-row"><input id="paktif" type="checkbox" checked> Aktif</label><button class="primary-btn" id="saveProduct">Ürün Kaydet</button></div><div id="productlist" class="compact-list"></div></article></section>

      <section id="icerik" class="sa-section"><div class="section-head"><div><span class="eyebrow">COMMUNITY</span><h2>İçerik & Duyurular</h2><p>Oyuncu portalındaki duyuruları yönetin.</p></div></div><article class="panel-block mini-panel"><div class="form-grid announcement-editor"><input id="did" type="number" placeholder="ID (düzenlemede)"><input id="dbaslik" placeholder="Başlık"><select id="dtur"><option value="bilgi">Bilgi</option><option value="etkinlik">Etkinlik</option><option value="guncelleme">Güncelleme</option><option value="uyari">Uyarı</option></select><label class="check-row"><input id="daktif" type="checkbox" checked> Aktif</label><label class="check-row"><input id="dsabit" type="checkbox"> Sabitle</label><textarea id="dicerik" placeholder="Duyuru içeriği"></textarea><button class="primary-btn" id="saveAnnouncement">Duyuruyu Kaydet</button></div><div id="announcementAdminList" class="compact-list"></div></article></section>


      <section id="kurallar" class="sa-section panel-block"><div class="section-head"><div><span class="eyebrow">PLAYER CODEX</span><h2>Oyun Kuralları</h2><p>Oyuncuların gördüğü kurallar metnini buradan canlı olarak düzenleyin.</p></div><span id="rulesStatus" class="status-chip">—</span></div><div class="form-grid rules-admin-grid"><input id="rulesTitle" placeholder="Başlık"><textarea id="rulesSummary" placeholder="Kısa özet"></textarea><textarea id="rulesBody" placeholder="Kurallar metni — satır satır yazabilirsiniz."></textarea><label class="check-row"><input type="checkbox" id="rulesActive" checked> Kurallar yayında</label><button class="primary-btn" id="saveRules">Kuralları Kaydet</button></div></section>

      <section id="ayarlar" class="sa-section"><div class="section-head"><div><span class="eyebrow">SYSTEM</span><h2>Sistem Ayarları</h2><p>Yayın, bakım ve yönetim notları.</p></div></div><div class="system-settings-grid"><article class="panel-block setting-card"><span>Oyun sürümü</span><strong>5.7</strong><small>Weapon-only · server-authoritative combat · 60 Hz</small></article><article class="panel-block setting-card"><span>Destek merkezi</span><strong>Aktif</strong><small>Oyuncu + admin çift yönlü mesajlaşma</small></article><article class="panel-block setting-card"><span>Skor</span><strong>Authoritative</strong><small>Sunucu oyuncu kill toplamından hesaplar</small></article><article class="panel-block setting-card"><span>Ses</span><strong>WAV BANK + VOICE</strong><small>Silah sesleri + takım PTT WebRTC kanalı</small></article></div></section>
    </div>

    <footer class="sa-admin-footer"><div><strong>STICK ARENA</strong><span>Command Center 5.7</span></div><nav><a href="https://discord.com/" target="_blank" rel="noopener noreferrer">Discord</a><a href="https://x.com/" target="_blank" rel="noopener noreferrer">X</a><a href="https://instagram.com/" target="_blank" rel="noopener noreferrer">Instagram</a></nav><small>Yönetici işlemleri loglanır · © 2026</small></footer>
  </main>
</div>
<script src="../assets/js/admin-5.4.js?v=5.9"></script>
</body></html>
